package com.agon.app.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.data.EXPENSE_CATEGORIES
import com.agon.app.data.now
import com.agon.app.ui.components.*
import com.agon.app.ui.theme.Gold
import com.agon.app.ui.theme.SuccessGreen
import com.agon.app.viewmodel.*

@Composable fun FinanceScreen(vm:MiyarViewModel,nav:(String)->Unit,onVoice:()->Unit){
 val db by vm.db.collectAsState(); var tab by remember{mutableStateOf(0)}
 val d=db?:return
 val bizId=d.currentBusinessId
 val txns=d.cashTxns.filter{it.businessId==bizId}.sortedByDescending{it.date}
 val expenses=d.expenses.filter{it.businessId==bizId}.sortedByDescending{it.date}
 val income=txns.filter{it.amount>0}.sumOf{it.amount}; val out=txns.filter{it.amount<0}.sumOf{-it.amount}
 Column(Modifier.fillMaxSize()){
  MiyarTopBar("المالية والصندوق",actions={ IconButton(onClick=onVoice){Icon(Icons.Default.Mic,null,tint=Gold)} })
  Column(Modifier.padding(horizontal=16.dp)){
   Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){ Column(Modifier.padding(16.dp)){
    Text("رصيد الصندوق الحالي",fontSize=13.sp,color=MaterialTheme.colorScheme.onSurfaceVariant); MoneyText(vm,vm.cashBalance(),fontSize=28)
    Spacer(Modifier.height(10.dp)); Row{ StatCard("إيرادات",fmtMoney(income),Icons.Default.TrendingUp,Modifier.weight(1f),SuccessGreen); Spacer(Modifier.width(8.dp)); StatCard("مصروفات",fmtMoney(out),Icons.Default.TrendingDown,Modifier.weight(1f),MaterialTheme.colorScheme.error) }
   } }
   Spacer(Modifier.height(10.dp)); Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){
    GoldButton("إيداع",Icons.Default.Add,Modifier.weight(1f)){nav("cashbox")}; OutlinedButton(onClick={nav("expenses")},modifier=Modifier.weight(1f).height(50.dp),shape=RoundedCornerShape(14.dp)){Icon(Icons.Default.ReceiptLong,null,tint=Gold); Spacer(Modifier.width(6.dp)); Text("مصروف")}; OutlinedButton(onClick={nav("shifts")},modifier=Modifier.weight(1f).height(50.dp),shape=RoundedCornerShape(14.dp)){Icon(Icons.Default.Schedule,null,tint=Gold); Spacer(Modifier.width(6.dp)); Text("وردية")}
   }
  }
  TabRow(selectedTabIndex=tab,containerColor=Color.Transparent,modifier=Modifier.padding(top=6.dp)){ Tab(selected=tab==0,onClick={tab=0},text={Text("الصندوق")}); Tab(selected=tab==1,onClick={tab=1},text={Text("المصروفات")}); Tab(selected=tab==2,onClick={tab=2},text={Text("الإيرادات")}) }
  when(tab){
   0->{ if(txns.isEmpty()) EmptyState(Icons.Default.AccountBalanceWallet,"لا حركات صندوق","ستُسجل هنا كل المبيعات والمشتريات والإيداعات والسحوبات.") else LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){ items(txns.take(100)){t-> Card(shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth()){ Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){ Icon(if(t.amount>=0)Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,null,Modifier.size(18.dp),tint=if(t.amount>=0)SuccessGreen else MaterialTheme.colorScheme.error); Spacer(Modifier.width(9.dp)); Column(Modifier.weight(1f)){Text(t.type,fontWeight=FontWeight.Bold,fontSize=13.sp); Text("${fmtDateTime(t.date)} • ${t.userName}",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant); if(t.note.isNotBlank())Text(t.note,fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}; MoneyText(vm,t.amount,fontSize=14,color=if(t.amount>=0)SuccessGreen else MaterialTheme.colorScheme.error) } } }; item{Spacer(Modifier.height(80.dp))} } }
   1->{ if(expenses.isEmpty()) EmptyState(Icons.Default.ReceiptLong,"لا مصروفات","سجّل مصروفاتك الإيجار والكهرباء والرواتب.","تسجيل مصروف"){nav("expenses")} else LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){ items(expenses){e-> Card(shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth()){ Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){ Box(Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.error.copy(alpha=0.12f)),contentAlignment=Alignment.Center){Icon(Icons.Default.ReceiptLong,null,Modifier.size(18.dp),tint=MaterialTheme.colorScheme.error)}; Spacer(Modifier.width(9.dp)); Column(Modifier.weight(1f)){Text(e.title.ifBlank{e.category},fontWeight=FontWeight.Bold,fontSize=13.sp); Text("${e.category} • ${fmtDateTime(e.date)} • ${e.userName}",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}; MoneyText(vm,-e.amount,fontSize=14,color=MaterialTheme.colorScheme.error) } } }; item{Spacer(Modifier.height(80.dp))} } }
   else->{ val inc=txns.filter{it.amount>0}; if(inc.isEmpty()) EmptyState(Icons.Default.TrendingUp,"لا إيرادات","ستظهر هنا التحصيلات.") else LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){ items(inc){t-> Card(shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth()){ Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){ Column(Modifier.weight(1f)){Text(t.type,fontWeight=FontWeight.Bold,fontSize=13.sp); Text(fmtDateTime(t.date),fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}; MoneyText(vm,t.amount,fontSize=14,color=SuccessGreen) } } }; item{Spacer(Modifier.height(80.dp))} } }
  }
 }
}
@Composable fun ExpensesScreen(vm:MiyarViewModel,back:()->Unit,onVoice:()->Unit){
 val db by vm.db.collectAsState(); var cat by remember{mutableStateOf(EXPENSE_CATEGORIES.first())}; var title by remember{mutableStateOf("")}; var amount by remember{mutableStateOf("")}; var note by remember{mutableStateOf("")}
 val expenses=db?.expenses?.filter{it.businessId==vm.bid()}?.sortedByDescending{it.date}?:emptyList()
 Column(Modifier.fillMaxSize()){ MiyarTopBar("المصروفات",back,actions={ IconButton(onClick=onVoice){Icon(Icons.Default.Mic,null,tint=Gold)} })
  Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
   Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){ Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
    Text("تسجيل مصروف جديد",fontWeight=FontWeight.Bold,fontSize=15.sp)
    DropdownField("التصنيف",cat,EXPENSE_CATEGORIES){cat=it}
    MiyarTextField(title,{title=it},"بيان المصروف",icon=Icons.Default.Description,placeholder="فاتورة كهرباء — شهر نوفمبر")
    MiyarTextField(amount,{amount=it},"المبلغ",icon=Icons.Default.Payments,keyboardType=KeyboardType.Number)
    MiyarTextField(note,{note=it},"ملاحظة",icon=Icons.Default.Notes)
    GoldButton("تسجيل المصروف وخصمه من الصندوق",Icons.Default.CheckCircle,Modifier.fillMaxWidth()){ val v=amount.toDoubleOrNull()?:0.0; if(v<=0){ vm.showToast("أدخل مبلغاً صحيحاً") } else { vm.addExpense(cat,title.ifBlank{"مصروف $cat"},v,note); title="";amount="";note="" } }
   } }
   Text("سجل المصروفات",fontWeight=FontWeight.Bold,fontSize=16.sp)
   if(expenses.isEmpty()) Text("لا مصروفات مسجلة.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
   expenses.take(50).forEach{e-> Card(shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant),modifier=Modifier.fillMaxWidth()){ Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){ Column(Modifier.weight(1f)){Text(e.title,fontWeight=FontWeight.Bold,fontSize=13.sp); Text("${e.category} • ${fmtDate(e.date)}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}; MoneyText(vm,e.amount,fontSize=14,color=MaterialTheme.colorScheme.error) } } }
   Spacer(Modifier.height(90.dp))
  }
 }
}
@Composable fun CashboxScreen(vm:MiyarViewModel,back:()->Unit,onVoice:()->Unit){
 var amount by remember{mutableStateOf("")}; var note by remember{mutableStateOf("")}
 val db by vm.db.collectAsState(); val txns=db?.cashTxns?.filter{it.businessId==vm.bid()}?.sortedByDescending{it.date}?:emptyList()
 Column(Modifier.fillMaxSize()){ MiyarTopBar("الصندوق وحركاته",back,actions={ IconButton(onClick=onVoice){Icon(Icons.Default.Mic,null,tint=Gold)} })
  Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
   Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Gold.copy(alpha=0.1f))){ Column(Modifier.padding(16.dp)){ Text("الرصيد الحالي",fontSize=13.sp); MoneyText(vm,vm.cashBalance(),fontSize=26) } }
   MiyarTextField(amount,{amount=it},"المبلغ",icon=Icons.Default.Payments,keyboardType=KeyboardType.Number); MiyarTextField(note,{note=it},"السبب / المرجع",icon=Icons.Default.Notes)
   Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ GoldButton("إيداع",Icons.Default.Download,Modifier.weight(1f)){ val v=amount.toDoubleOrNull()?:0.0; if(v>0){vm.cashDeposit(v,note,true);amount="";note=""}else vm.showToast("أدخل مبلغاً صحيحاً") }; OutlinedButton(onClick={ val v=amount.toDoubleOrNull()?:0.0; if(v>0){vm.cashDeposit(v,note,false);amount="";note=""}else vm.showToast("أدخل مبلغاً صحيحاً") },modifier=Modifier.weight(1f).height(50.dp),shape=RoundedCornerShape(14.dp)){Icon(Icons.Default.Upload,null,tint=MaterialTheme.colorScheme.error); Spacer(Modifier.width(6.dp)); Text("سحب",color=MaterialTheme.colorScheme.error)} }
   Text("آخر الحركات",fontWeight=FontWeight.Bold,fontSize=16.sp)
   txns.take(40).forEach{t-> Row(Modifier.fillMaxWidth().padding(vertical=5.dp),verticalAlignment=Alignment.CenterVertically){ Icon(if(t.amount>=0)Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,null,modifier=Modifier.size(16.dp)); Spacer(Modifier.width(8.dp)); Column(Modifier.weight(1f)){Text(t.type,fontSize=13.sp);Text(fmtDateTime(t.date),fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}; MoneyText(vm,t.amount,fontSize=13,color=if(t.amount>=0)SuccessGreen else MaterialTheme.colorScheme.error) } }
   Spacer(Modifier.height(90.dp))
  }
 }
}
@Composable fun ShiftsScreen(vm:MiyarViewModel,back:()->Unit,onVoice:()->Unit){
 val db by vm.db.collectAsState(); var opening by remember{mutableStateOf("")}; var closeId by remember{mutableStateOf<String?>(null)}; var actual by remember{mutableStateOf("")}
 val shifts=db?.shifts?.filter{it.businessId==vm.bid()}?.sortedByDescending{it.openedAt}?:emptyList()
 Column(Modifier.fillMaxSize()){ MiyarTopBar("الورديات ومطابقة النقدية",back,actions={ IconButton(onClick=onVoice){Icon(Icons.Default.Mic,null,tint=Gold)} })
  Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
   Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){ Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){ Text("فتح وردية جديدة",fontWeight=FontWeight.Bold); MiyarTextField(opening,{opening=it},"الرصيد الافتتاحي",icon=Icons.Default.LockOpen,keyboardType=KeyboardType.Number); GoldButton("فتح الوردية",Icons.Default.PlayArrow,Modifier.fillMaxWidth()){ val v=opening.toDoubleOrNull()?:vm.cashBalance(); vm.openShift(v); opening="" } } }
   shifts.forEach{s-> Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth()){ Column(Modifier.padding(14.dp)){ Row(verticalAlignment=Alignment.CenterVertically){ Icon(if(s.status=="مفتوحة")Icons.Default.PlayCircle else Icons.Default.Lock,null,tint=if(s.status=="مفتوحة")SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.width(8.dp)); Column(Modifier.weight(1f)){Text(if(s.status=="مفتوحة")"وردية مفتوحة" else "وردية مغلقة",fontWeight=FontWeight.Bold,fontSize=14.sp); Text("${s.userName} • من ${fmtDateTime(s.openedAt)}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}; AlertChip(s.status,if(s.status=="مفتوحة")SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant) }
    Spacer(Modifier.height(8.dp)); Row{ Text("افتتاحي",Modifier.weight(1f),fontSize=12.sp); MoneyText(vm,s.openingCash,fontSize=12) }; if(s.status=="مغلقة"){ Row{ Text("المتوقع",Modifier.weight(1f),fontSize=12.sp); MoneyText(vm,s.expectedCash,fontSize=12) }; Row{ Text("الفعلية",Modifier.weight(1f),fontSize=12.sp); MoneyText(vm,s.actualCash,fontSize=12,color=if(kotlin.math.abs(s.expectedCash-s.actualCash)<1)SuccessGreen else MaterialTheme.colorScheme.error) }; Text("الفرق: ${fmtMoney(s.actualCash-s.expectedCash)}",fontSize=12.sp) } else OutlinedButton(onClick={closeId=s.id},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Lock,null,tint=Gold); Spacer(Modifier.width(6.dp)); Text("إغلاق الوردية ومطابقة النقدية")} } } }
   Spacer(Modifier.height(90.dp))
  }
 }
 if(closeId!=null) AlertDialog(onDismissRequest={closeId=null},title={Text("إغلاق الوردية")},text={ Column{ Text("أدخل المبلغ النقدي الفعلي في الصندوق:",fontSize=13.sp); Spacer(Modifier.height(8.dp)); MiyarTextField(actual,{actual=it},"المبلغ الفعلي",icon=Icons.Default.Payments,keyboardType=KeyboardType.Number) } },confirmButton={ TextButton(onClick={ vm.closeShift(closeId!!,actual.toDoubleOrNull()?:0.0); closeId=null; actual="" }){Text("إغلاق")} },dismissButton={TextButton(onClick={closeId=null}){Text("إلغاء")}})
}
@Composable fun ReportsScreen(vm:MiyarViewModel,back:()->Unit,nav:(String)->Unit,onVoice:()->Unit){
 val db by vm.db.collectAsState(); val d=db?:return; val ctx=LocalContext.current
 var period by remember{mutableStateOf("اليوم")}; var report by remember{mutableStateOf("تقرير المبيعات")}
 val bizId=d.currentBusinessId
 val (from,to)= when(period){ "اليوم"->dayStart(0) to (dayStart(0)+86400000L); "الأسبوع"->dayStart(6) to (dayStart(0)+86400000L); "الشهر"->dayStart(29) to (dayStart(0)+86400000L); "السنة"->dayStart(364) to (dayStart(0)+86400000L); else->dayStart(29) to (dayStart(0)+86400000L) }
 val sales=d.sales.filter{it.businessId==bizId&&it.status=="مكتملة"&&it.date in from until to}
 val purchases=d.purchases.filter{it.businessId==bizId&&it.date in from until to}
 val expenses=d.expenses.filter{it.businessId==bizId&&it.date in from until to}
 val cogs=sales.sumOf{s->s.items.sumOf{it.cost*it.qty}}
 val revenue=sales.sumOf{it.total}; val profit=revenue-cogs-expenses.sumOf{it.amount}
 Column(Modifier.fillMaxSize()){ MiyarTopBar("التقارير",back,actions={ IconButton(onClick=onVoice){Icon(Icons.Default.Mic,null,tint=Gold)} })
  Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
   LazyRowChips(listOf("اليوم","الأسبوع","الشهر","السنة"),period){period=it}
   LazyRowChips(listOf("تقرير المبيعات","الأرباح والخسائر","تقرير المشتريات","تقرير المصروفات","تقرير المخزون","الأكثر مبيعاً","ديون العملاء","مستحقات الموردين","تقرير الصندوق"),report){report=it}
   when(report){
    "تقرير المبيعات"->{ Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ StatCard("إجمالي المبيعات",fmtMoney(revenue),Icons.Default.TrendingUp,Modifier.weight(1f),SuccessGreen); StatCard("عدد الفواتير",sales.size.toString(),Icons.Default.ReceiptLong,Modifier.weight(1f)) }; Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){ Column(Modifier.padding(14.dp)){ Text("المبيعات اليومية",fontWeight=FontWeight.Bold); BarChart((6 downTo 0).map{off-> val st=dayStart(off); fmtDate(st).substringAfterLast("/") to d.sales.filter{it.businessId==bizId&&it.status=="مكتملة"&&it.date in st until (st+86400000L)}.sumOf{it.total}}) } } }
    "الأرباح والخسائر"->{ Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){ Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){ Text("قائمة الأرباح والخسائر — $period",fontWeight=FontWeight.ExtraBold,fontSize=16.sp); Row(Modifier.fillMaxWidth()){Text("إجمالي المبيعات",Modifier.weight(1f),fontSize=13.sp); MoneyText(vm,revenue,fontSize=13)}; Row(Modifier.fillMaxWidth()){Text("تكلفة البضاعة المباعة (COGS)",Modifier.weight(1f),fontSize=13.sp,color=MaterialTheme.colorScheme.error); MoneyText(vm,-cogs,fontSize=13,color=MaterialTheme.colorScheme.error)}; Row(Modifier.fillMaxWidth()){Text("المصروفات التشغيلية",Modifier.weight(1f),fontSize=13.sp,color=MaterialTheme.colorScheme.error); MoneyText(vm,-expenses.sumOf{it.amount},fontSize=13,color=MaterialTheme.colorScheme.error)}; HorizontalDivider(); Row(Modifier.fillMaxWidth()){Text("صافي الربح",Modifier.weight(1f),fontWeight=FontWeight.ExtraBold); MoneyText(vm,profit,fontSize=17,color=if(profit>=0)SuccessGreen else MaterialTheme.colorScheme.error)}; Text("محسوبة على أساس تكلفة البضاعة المباعة مع خصم المرتجعات من المبيعات.",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) } } }
    "تقرير المشتريات"->{ Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ StatCard("إجمالي المشتريات",fmtMoney(purchases.sumOf{it.total}),Icons.Default.ShoppingCart,Modifier.weight(1f)); StatCard("عدد الفواتير",purchases.size.toString(),Icons.Default.Receipt,Modifier.weight(1f)) }; purchases.take(30).forEach{p-> Row(Modifier.fillMaxWidth().padding(vertical=4.dp)){ Column(Modifier.weight(1f)){Text("${p.number} • ${p.supplierName}",fontSize=13.sp);Text(fmtDate(p.date),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}; MoneyText(vm,p.total,fontSize=13) } } }
    "تقرير المصروفات"->{ Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ StatCard("إجمالي المصروفات",fmtMoney(expenses.sumOf{it.amount}),Icons.Default.ReceiptLong,Modifier.weight(1f),MaterialTheme.colorScheme.error); StatCard("عدد القيود",expenses.size.toString(),Icons.Default.ListAlt,Modifier.weight(1f)) }; expenses.groupBy{it.category}.forEach{(cat,list)-> Row(Modifier.fillMaxWidth().padding(vertical=4.dp)){ Text(cat,Modifier.weight(1f),fontSize=13.sp); MoneyText(vm,list.sumOf{it.amount},fontSize=13,color=MaterialTheme.colorScheme.error) } } }
    "تقرير المخزون"->{ val prods=d.products.filter{it.businessId==bizId}; Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ StatCard("قيمة المخزون",fmtMoney(prods.sumOf{it.quantity*it.purchasePrice}),Icons.Default.Inventory,Modifier.weight(1f)); StatCard("عدد الأصناف",prods.size.toString(),Icons.Default.Category,Modifier.weight(1f)) }; prods.forEach{p-> Row(Modifier.fillMaxWidth().padding(vertical=4.dp)){ Column(Modifier.weight(1f)){Text(p.name,fontSize=13.sp);Text("الكمية ${p.quantity} ${p.unit}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}; MoneyText(vm,p.quantity*p.purchasePrice,fontSize=13) } } }
    "الأكثر مبيعاً"->{ val map=mutableMapOf<String,Pair<Int,Double>>(); sales.forEach{s->s.items.forEach{li-> val e=map[li.productName]; map[li.productName]=if(e==null) Pair(li.qty,li.price*li.qty) else Pair(e.first+li.qty,e.second+li.price*li.qty)}}; map.entries.sortedByDescending{it.value.first}.forEach{(n,v)-> Row(Modifier.fillMaxWidth().padding(vertical=5.dp)){ Text(n,Modifier.weight(1f),fontSize=13.sp); Text("${v.first} قطعة",fontSize=12.sp,color=Gold); Spacer(Modifier.width(10.dp)); MoneyText(vm,v.second,fontSize=13) } } }
    "ديون العملاء"->{ val cs=d.customers.filter{it.businessId==bizId&&it.balance>0}; Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ StatCard("إجمالي الديون",fmtMoney(cs.sumOf{it.balance}),Icons.Default.MoneyOff,Modifier.weight(1f),MaterialTheme.colorScheme.error); StatCard("عدد المدينين",cs.size.toString(),Icons.Default.People,Modifier.weight(1f)) }; cs.forEach{c-> Row(Modifier.fillMaxWidth().padding(vertical=4.dp)){ Text(c.name,Modifier.weight(1f),fontSize=13.sp); MoneyText(vm,c.balance,fontSize=13,color=MaterialTheme.colorScheme.error) } } }
    "مستحقات الموردين"->{ val sp=d.suppliers.filter{it.businessId==bizId&&it.balance>0}; Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ StatCard("إجمالي المستحقات",fmtMoney(sp.sumOf{it.balance}),Icons.Default.Payments,Modifier.weight(1f),MaterialTheme.colorScheme.error); StatCard("عدد الموردين",sp.size.toString(),Icons.Default.LocalShipping,Modifier.weight(1f)) }; sp.forEach{c-> Row(Modifier.fillMaxWidth().padding(vertical=4.dp)){ Text(c.name,Modifier.weight(1f),fontSize=13.sp); MoneyText(vm,c.balance,fontSize=13,color=MaterialTheme.colorScheme.error) } } }
    else->{ val txns=d.cashTxns.filter{it.businessId==bizId&&it.date in from until to}; Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ StatCard("إيرادات الفترة",fmtMoney(txns.filter{it.amount>0}.sumOf{it.amount}),Icons.Default.TrendingUp,Modifier.weight(1f),SuccessGreen); StatCard("مصروفات الفترة",fmtMoney(txns.filter{it.amount<0}.sumOf{-it.amount}),Icons.Default.TrendingDown,Modifier.weight(1f),MaterialTheme.colorScheme.error) } }
   }
   Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ OutlinedButton(onClick={ shareText(ctx,"تقرير مبيعات مِعيار",vm.salesCsv()) },modifier=Modifier.weight(1f)){Icon(Icons.Default.TableChart,null,tint=Gold); Spacer(Modifier.width(6.dp)); Text("تصدير CSV")}; OutlinedButton(onClick={ shareText(ctx,"تقرير $report — مِعيار",reportText(vm,report,period)) },modifier=Modifier.weight(1f)){Icon(Icons.Default.PictureAsPdf,null,tint=Gold); Spacer(Modifier.width(6.dp)); Text("مشاركة التقرير")} }
   Spacer(Modifier.height(90.dp))
  }
 }
}
fun reportText(vm:MiyarViewModel,report:String,period:String):String{ val d=vm.db.value; val biz=vm.curBusiness()?.name?:"مِعيار"; val sales=vm.bizSales(); val sb=StringBuilder(); sb.append("تقرير: $report\nالنشاط: $biz\nالفترة: $period\nالتاريخ: ${fmtDateTime(now())}\n--------------------\n")
 when(report){ "تقرير المبيعات"->{ sb.append("عدد الفواتير: ${sales.size}\nإجمالي المبيعات: ${fmtMoney(sales.sumOf{it.total})}\n") }; "ديون العملاء"->{ vm.bizCustomers().filter{it.balance>0}.forEach{sb.append("${it.name}: ${fmtMoney(it.balance)}\n")} }; else->{ sb.append("البيانات محفوظة في مِعيار MI'YAR — للمزيد افتح التطبيق.\n") } }
 sb.append("\nصاحب المشروع: المهندس مجد الماعطي"); return sb.toString() }
