package com.agon.app.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.data.*
import com.agon.app.ui.components.*
import com.agon.app.ui.theme.Gold
import com.agon.app.ui.theme.SuccessGreen
import com.agon.app.viewmodel.*

@Composable fun PurchasesScreen(vm:MiyarViewModel,back:()->Unit,nav:(String)->Unit,onVoice:()->Unit){
 val db by vm.db.collectAsState(); var q by remember{mutableStateOf("")}
 val purchases=db?.purchases?.filter{it.businessId==vm.bid()}?.sortedByDescending{it.date}?:emptyList()
 Column(Modifier.fillMaxSize()){ MiyarTopBar("المشتريات",back,actions={ IconButton(onClick=onVoice){Icon(Icons.Default.Mic,null,tint=Gold)}; IconButton(onClick={nav("purchase_new")}){Icon(Icons.Default.Add,null,tint=Gold)} })
  Column(Modifier.padding(16.dp)){ OutlinedTextField(q,{q=it},placeholder={Text("بحث برقم الفاتورة أو المورد")},leadingIcon={Icon(Icons.Default.Search,null)},modifier=Modifier.fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(14.dp)); Spacer(Modifier.height(8.dp)); Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ StatCard("إجمالي المشتريات",fmtMoney(purchases.sumOf{it.total}),Icons.Default.ShoppingCart,Modifier.weight(1f)); StatCard("مستحقات الموردين",fmtMoney(vm.bizSuppliers().sumOf{it.balance}),Icons.Default.Payments,Modifier.weight(1f),MaterialTheme.colorScheme.error) } }
  if(purchases.isEmpty()) EmptyState(Icons.Default.ShoppingCart,"لا فواتير شراء","أنشئ فاتورة شراء لتوريد المنتجات.","فاتورة شراء جديدة"){nav("purchase_new")}
  else LazyColumn(Modifier.padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){ items(purchases.filter{ q.isBlank()||it.number.contains(q)||it.supplierName.contains(q)}){p-> Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth().clickable{nav("purchase_detail/${p.id}")}){ Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){ Box(Modifier.size(42.dp).clip(RoundedCornerShape(11.dp)).background(Gold.copy(alpha=0.13f)),contentAlignment=Alignment.Center){Icon(Icons.Default.LocalShipping,null,tint=Gold)}; Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)){Text("${p.number} • ${p.supplierName}",fontWeight=FontWeight.Bold,fontSize=14.sp); Text("${fmtDateTime(p.date)} • ${p.items.sumOf{it.qty}} قطعة",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant); if(p.remaining>0) Text("متبقي للمورد: ${fmtMoney(p.remaining)}",fontSize=11.sp,color=MaterialTheme.colorScheme.error)}; MoneyText(vm,p.total,fontSize=14) } } }; item{Spacer(Modifier.height(80.dp))} }
 }
}
@Composable fun PurchaseNewScreen(vm:MiyarViewModel,back:()->Unit,onVoice:()->Unit){
 val cart by vm.purchaseCart.collectAsState(); val suppliers=vm.bizSuppliers(); val prods=vm.bizProducts()
 var supplier by remember{mutableStateOf(suppliers.firstOrNull()?.name?:"")}; var disc by remember{mutableStateOf("")}; var paid by remember{mutableStateOf("")}; var q by remember{mutableStateOf("")}; var showList by remember{mutableStateOf(false)}
 val sub=cart.sumOf{it.price*it.qty}; val total=(sub-(disc.toDoubleOrNull()?:0.0)).coerceAtLeast(0.0); val paidV=if(paid.isBlank())total else paid.toDoubleOrNull()?:0.0
 Column(Modifier.fillMaxSize()){ MiyarTopBar("فاتورة شراء جديدة",back,actions={ IconButton(onClick=onVoice){Icon(Icons.Default.Mic,null,tint=Gold)} })
  Column(Modifier.padding(16.dp).weight(1f),verticalArrangement=Arrangement.spacedBy(10.dp)){
   DropdownField("المورد",supplier,suppliers.map{it.name}){supplier=it}
   val s=suppliers.find{it.name==supplier}; if(s!=null) Text("مستحقات المورد الحالية: ${fmtMoney(s.balance)}",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
   Row(verticalAlignment=Alignment.CenterVertically){ OutlinedTextField(q,{q=it},placeholder={Text("ابحث منتج لإضافته")},leadingIcon={Icon(Icons.Default.Search,null)},modifier=Modifier.weight(1f),singleLine=true,shape=RoundedCornerShape(14.dp)); FilledIconButton(onClick={showList=!showList},colors=IconButtonDefaults.filledIconButtonColors(containerColor=Gold,contentColor=Color.Black)){Icon(if(showList)Icons.Default.ExpandLess else Icons.Default.ExpandMore,null)} }
   if(showList) Card(shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant)){ Column{ prods.filter{ q.isBlank()||it.name.contains(q)}.take(8).forEach{p-> Row(Modifier.fillMaxWidth().clickable{vm.addToPurchaseCart(p)}.padding(10.dp),verticalAlignment=Alignment.CenterVertically){ Text(p.name,Modifier.weight(1f),fontSize=13.sp); Text(fmtMoney(p.purchasePrice),fontSize=12.sp,color=Gold); Icon(Icons.Default.Add,null,modifier=Modifier.size(18.dp)) } } } }
   if(cart.isEmpty()) Text("السلة فارغة — اختر منتجات من القائمة أعلاه.",fontSize=13.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
   cart.forEach{item-> Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){ Text(item.productName,Modifier.weight(1f),fontSize=13.sp); IconButton(onClick={vm.setPurchaseQty(item.productId,item.qty-1)}){Icon(Icons.Default.RemoveCircleOutline,null,Modifier.size(18.dp))}; Text("${item.qty}",fontWeight=FontWeight.Bold); IconButton(onClick={vm.setPurchaseQty(item.productId,item.qty+1)}){Icon(Icons.Default.AddCircleOutline,null,Modifier.size(18.dp))}; Text(fmtMoney(item.price*item.qty),fontSize=12.sp) } }
   MiyarTextField(disc,{disc=it},"خصم",icon=Icons.Default.Discount,keyboardType=KeyboardType.Number)
   MiyarTextField(paid,{paid=it},"المدفوع للمورد (فارغ = كامل)",icon=Icons.Default.Payments,keyboardType=KeyboardType.Number)
   Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant)){ Column(Modifier.padding(14.dp)){ Row(Modifier.fillMaxWidth()){Text("الإجمالي",Modifier.weight(1f),fontWeight=FontWeight.Bold); MoneyText(vm,total,fontSize=16)}; Row(Modifier.fillMaxWidth()){Text("المتبقي للمورد",Modifier.weight(1f),fontSize=13.sp,color=MaterialTheme.colorScheme.error); MoneyText(vm,(total-paidV).coerceAtLeast(0.0),fontSize=13,color=MaterialTheme.colorScheme.error)} } }
   GoldButton("اعتماد فاتورة الشراء وتحديث المخزون",Icons.Default.CheckCircle,Modifier.fillMaxWidth(),enabled=cart.isNotEmpty()&&supplier.isNotBlank()){ vm.checkoutPurchase(suppliers.find{it.name==supplier},disc.toDoubleOrNull()?:0.0,paidV){ back() } }
   Spacer(Modifier.height(90.dp))
  }
 }
}
@Composable fun PurchaseDetailScreen(vm:MiyarViewModel,id:String,back:()->Unit){
 val db by vm.db.collectAsState(); val p=db?.purchases?.find{it.id==id}; val ctx=LocalContext.current
 Column(Modifier.fillMaxSize()){ MiyarTopBar("فاتورة شراء ${p?.number?:""}",back)
  if(p==null) EmptyState(Icons.Default.Receipt,"الفاتورة غير موجودة","")
  else Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
   Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Column(Modifier.padding(16.dp)){ Text(p.supplierName,fontWeight=FontWeight.ExtraBold,fontSize=17.sp); Text("${fmtDateTime(p.date)} • بواسطة ${p.userName}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant); HorizontalDivider(Modifier.padding(vertical=8.dp)); p.items.forEach{it-> Row(Modifier.fillMaxWidth().padding(vertical=4.dp)){ Text("${it.productName} × ${it.qty}",Modifier.weight(1f),fontSize=13.sp); Text(fmtMoney(it.price*it.qty),fontSize=13.sp) } }; HorizontalDivider(Modifier.padding(vertical=8.dp)); Row(Modifier.fillMaxWidth()){Text("الإجمالي",Modifier.weight(1f),fontWeight=FontWeight.Bold); MoneyText(vm,p.total,fontSize=16)}; Row(Modifier.fillMaxWidth()){Text("المدفوع",Modifier.weight(1f),fontSize=13.sp); MoneyText(vm,p.paid,fontSize=13)}; Row(Modifier.fillMaxWidth()){Text("المتبقي",Modifier.weight(1f),fontSize=13.sp,color=MaterialTheme.colorScheme.error); MoneyText(vm,p.remaining,fontSize=13,color=MaterialTheme.colorScheme.error)} } }
   OutlinedButton(onClick={shareText(ctx,"فاتورة شراء ${p.number}",buildString{append("فاتورة شراء ${p.number}\nالمورد: ${p.supplierName}\nالإجمالي: ${fmtMoney(p.total)}\nالمدفوع: ${fmtMoney(p.paid)}\nالمتبقي: ${fmtMoney(p.remaining)}")})},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Share,null); Spacer(Modifier.width(8.dp)); Text("مشاركة الفاتورة")}
   Spacer(Modifier.height(80.dp))
  }
 }
}
@Composable fun SuppliersScreen(vm:MiyarViewModel,back:()->Unit,nav:(String)->Unit,onVoice:()->Unit){
 val suppliers=vm.bizSuppliers(); var showAdd by remember{mutableStateOf(false)}
 var name by remember{mutableStateOf("")}; var phone by remember{mutableStateOf("")}; var address by remember{mutableStateOf("")}
 Column(Modifier.fillMaxSize()){ MiyarTopBar("الموردون",back,actions={ IconButton(onClick=onVoice){Icon(Icons.Default.Mic,null,tint=Gold)}; IconButton(onClick={showAdd=true}){Icon(Icons.Default.Add,null,tint=Gold)} })
  if(suppliers.isEmpty()&&!showAdd) EmptyState(Icons.Default.LocalShipping,"لا موردون","أضف مورداً لتسجيل فواتير الشراء والمستحقات.","إضافة مورد"){showAdd=true}
  if(showAdd) Card(Modifier.padding(16.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){ Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){ Text("مورد جديد",fontWeight=FontWeight.Bold); MiyarTextField(name,{name=it},"الاسم",icon=Icons.Default.Person); MiyarTextField(phone,{phone=it},"الهاتف",icon=Icons.Default.Phone,keyboardType=KeyboardType.Phone); MiyarTextField(address,{address=it},"العنوان",icon=Icons.Default.LocationOn); Row{ GoldButton("حفظ",Icons.Default.Save,Modifier.weight(1f)){ vm.saveSupplier(Supplier(businessId=vm.bid(),name=name.trim(),phone=phone.trim(),address=address.trim()),true); showAdd=false; name="";phone="";address="" }; Spacer(Modifier.width(8.dp)); OutlinedButton(onClick={showAdd=false},modifier=Modifier.weight(1f)){Text("إلغاء")} } } }
  LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
   items(suppliers){s-> Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth().clickable{nav("supplier_detail/${s.id}")}){ Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){ Box(Modifier.size(42.dp).clip(CircleShape).background(Gold.copy(alpha=0.13f)),contentAlignment=Alignment.Center){Text(s.name.take(1),fontWeight=FontWeight.Bold,color=Gold)}; Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)){Text(s.name,fontWeight=FontWeight.Bold,fontSize=14.sp); Text(s.phone.ifBlank{"بدون هاتف"},fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant); if(s.balance>0) Text("مستحق: ${fmtMoney(s.balance)}",fontSize=11.sp,color=MaterialTheme.colorScheme.error)}; Icon(Icons.Default.ChevronLeft,null,tint=MaterialTheme.colorScheme.onSurfaceVariant) } } }
   item{Spacer(Modifier.height(80.dp))}
  }
 }
}
@Composable fun SupplierDetailScreen(vm:MiyarViewModel,id:String,back:()->Unit){
 val db by vm.db.collectAsState(); val s=db?.suppliers?.find{it.id==id}; var pay by remember{mutableStateOf("")}; var note by remember{mutableStateOf("")}
 val purchases=db?.purchases?.filter{it.supplierId==id}?:emptyList(); val payments=db?.payments?.filter{it.personType=="مورد"&&it.personId==id}?:emptyList()
 Column(Modifier.fillMaxSize()){ MiyarTopBar("كشف حساب المورد",back)
  if(s==null) EmptyState(Icons.Default.LocalShipping,"المورد غير موجود","")
  else LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
   item{ Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){ Column(Modifier.padding(16.dp)){ Text(s.name,fontWeight=FontWeight.ExtraBold,fontSize=18.sp); Text("${s.phone} • ${s.address}",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(10.dp)); Row{ Text("الرصيد المستحق للمورد",Modifier.weight(1f),fontSize=13.sp); MoneyText(vm,s.balance,fontSize=17,color=if(s.balance>0)MaterialTheme.colorScheme.error else SuccessGreen) } } } }
   item{ Text("تسجيل دفعة للمورد",fontWeight=FontWeight.Bold,fontSize=15.sp); MiyarTextField(pay,{pay=it},"مبلغ الدفعة",icon=Icons.Default.Payments,keyboardType=KeyboardType.Number); MiyarTextField(note,{note=it},"ملاحظة / مرجع",icon=Icons.Default.Notes); GoldButton("تسجيل الدفعة",Icons.Default.CheckCircle,Modifier.fillMaxWidth()){ val v=pay.toDoubleOrNull()?:0.0; if(v>0){ vm.recordSupplierPayment(s.id,v,note); pay="";note="" } else vm.showToast("أدخل مبلغاً صحيحاً") } }
   item{ SectionTitle("فواتير الشراء") }
   item{ if(purchases.isEmpty()) Text("لا فواتير لهذا المورد.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) }
   items(purchases){p-> Card(shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant),modifier=Modifier.fillMaxWidth()){ Row(Modifier.padding(12.dp)){ Column(Modifier.weight(1f)){Text(p.number,fontWeight=FontWeight.Bold,fontSize=13.sp); Text(fmtDateTime(p.date),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}; MoneyText(vm,p.total,fontSize=13) } } }
   item{ SectionTitle("الدفعات") }
   item{ if(payments.isEmpty()) Text("لا دفعات مسجلة.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) }
   items(payments){pm-> Row(Modifier.fillMaxWidth().padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){ Icon(Icons.Default.ArrowDownward,null,Modifier.size(16.dp),tint=SuccessGreen); Spacer(Modifier.width(8.dp)); Column(Modifier.weight(1f)){Text(fmtMoney(pm.amount),fontWeight=FontWeight.Bold,fontSize=13.sp); Text("${fmtDateTime(pm.date)} ${pm.note}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)} } }
   item{Spacer(Modifier.height(90.dp))}
  }
 }
}
@Composable fun CustomersScreen(vm:MiyarViewModel,back:()->Unit,nav:(String)->Unit,onVoice:()->Unit){
 val customers=vm.bizCustomers(); var showAdd by remember{mutableStateOf(false)}; var q by remember{mutableStateOf("")}
 var name by remember{mutableStateOf("")}; var phone by remember{mutableStateOf("")}; var address by remember{mutableStateOf("")}; var notes by remember{mutableStateOf("")}
 val list=customers.filter{q.isBlank()||it.name.contains(q)||it.phone.contains(q)}
 Column(Modifier.fillMaxSize()){ MiyarTopBar("العملاء والديون",back,actions={ IconButton(onClick=onVoice){Icon(Icons.Default.Mic,null,tint=Gold)}; IconButton(onClick={showAdd=true}){Icon(Icons.Default.Add,null,tint=Gold)} })
  Column(Modifier.padding(16.dp)){ OutlinedTextField(q,{q=it},placeholder={Text("بحث بالاسم أو الهاتف")},leadingIcon={Icon(Icons.Default.Search,null)},modifier=Modifier.fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(14.dp)); Spacer(Modifier.height(8.dp)); Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ StatCard("إجمالي الديون",fmtMoney(customers.sumOf{it.balance}),Icons.Default.MoneyOff,Modifier.weight(1f),MaterialTheme.colorScheme.error); StatCard("عدد العملاء",customers.size.toString(),Icons.Default.People,Modifier.weight(1f)); StatCard("مدينون",customers.count{it.balance>0}.toString(),Icons.Default.Warning,Modifier.weight(1f)) } }
  if(showAdd) Card(Modifier.padding(horizontal=16.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){ Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){ Text("عميل جديد",fontWeight=FontWeight.Bold); MiyarTextField(name,{name=it},"الاسم *",icon=Icons.Default.Person); MiyarTextField(phone,{phone=it},"الهاتف",icon=Icons.Default.Phone,keyboardType=KeyboardType.Phone); MiyarTextField(address,{address=it},"العنوان",icon=Icons.Default.LocationOn); MiyarTextField(notes,{notes=it},"ملاحظات",icon=Icons.Default.Notes); Row{ GoldButton("حفظ",Icons.Default.Save,Modifier.weight(1f)){ if(name.isBlank()){vm.showToast("أدخل اسم العميل")}else{ vm.saveCustomer(Customer(businessId=vm.bid(),name=name.trim(),phone=phone.trim(),address=address.trim(),notes=notes.trim()),true); showAdd=false;name="";phone="";address="";notes="" } }; Spacer(Modifier.width(8.dp)); OutlinedButton(onClick={showAdd=false},modifier=Modifier.weight(1f)){Text("إلغاء")} } } }
  if(list.isEmpty()&&!showAdd) EmptyState(Icons.Default.People,"لا عملاء","أضف عميلاً لتتبع مبيعاته وديونه.","إضافة عميل"){showAdd=true}
  LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
   items(list){c-> Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth().clickable{nav("customer_detail/${c.id}")}){ Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){ Box(Modifier.size(42.dp).clip(CircleShape).background(Gold.copy(alpha=0.13f)),contentAlignment=Alignment.Center){Text(c.name.take(1),fontWeight=FontWeight.Bold,color=Gold)}; Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)){Text(c.name,fontWeight=FontWeight.Bold,fontSize=14.sp); Text(c.phone.ifBlank{"بدون هاتف"},fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant); if(c.balance>0) Text("دين: ${fmtMoney(c.balance)}",fontSize=11.sp,color=MaterialTheme.colorScheme.error,fontWeight=FontWeight.Bold)}; Icon(Icons.Default.ChevronLeft,null,tint=MaterialTheme.colorScheme.onSurfaceVariant) } } }
   item{Spacer(Modifier.height(80.dp))}
  }
 }
}
@Composable fun CustomerDetailScreen(vm:MiyarViewModel,id:String,back:()->Unit){
 val db by vm.db.collectAsState(); val c=db?.customers?.find{it.id==id}; var pay by remember{mutableStateOf("")}; var note by remember{mutableStateOf("")}
 val sales=db?.sales?.filter{it.customerId==id}?:emptyList(); val payments=db?.payments?.filter{it.personType=="عميل"&&it.personId==id}?:emptyList()
 Column(Modifier.fillMaxSize()){ MiyarTopBar("كشف حساب العميل",back)
  if(c==null) EmptyState(Icons.Default.Person,"العميل غير موجود","")
  else LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
   item{ Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){ Column(Modifier.padding(16.dp)){ Text(c.name,fontWeight=FontWeight.ExtraBold,fontSize=18.sp); Text("${c.phone} • ${c.address}",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(10.dp)); Row{ Text("الرصيد المتبقي",Modifier.weight(1f),fontSize=13.sp); MoneyText(vm,c.balance,fontSize=17,color=if(c.balance>0)MaterialTheme.colorScheme.error else SuccessGreen) } } } }
   item{ Text("تسجيل دفعة من العميل",fontWeight=FontWeight.Bold,fontSize=15.sp); MiyarTextField(pay,{pay=it},"مبلغ الدفعة",icon=Icons.Default.Payments,keyboardType=KeyboardType.Number); MiyarTextField(note,{note=it},"ملاحظة / رقم فاتورة",icon=Icons.Default.Notes); GoldButton("تسجيل الدفعة",Icons.Default.CheckCircle,Modifier.fillMaxWidth()){ val v=pay.toDoubleOrNull()?:0.0; if(v>0){ vm.recordCustomerPayment(id,v,note); pay="";note="" } else vm.showToast("أدخل مبلغاً صحيحاً") } }
   item{ SectionTitle("فواتير العميل") }
   item{ if(sales.isEmpty()) Text("لا مبيعات لهذا العميل.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) }
   items(sales){s-> Card(shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant),modifier=Modifier.fillMaxWidth()){ Row(Modifier.padding(12.dp)){ Column(Modifier.weight(1f)){Text(s.number,fontWeight=FontWeight.Bold,fontSize=13.sp); Text(fmtDateTime(s.date),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant); if(s.remaining>0)Text("متبقي ${fmtMoney(s.remaining)}",fontSize=11.sp,color=MaterialTheme.colorScheme.error)}; MoneyText(vm,s.total,fontSize=13) } } }
   item{ SectionTitle("الدفعات") }
   item{ if(payments.isEmpty()) Text("لا دفعات.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) }
   items(payments){pm-> Row(Modifier.fillMaxWidth().padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){ Icon(Icons.Default.ArrowDownward,null,Modifier.size(16.dp),tint=SuccessGreen); Spacer(Modifier.width(8.dp)); Column(Modifier.weight(1f)){Text(fmtMoney(pm.amount),fontWeight=FontWeight.Bold,fontSize=13.sp); Text("${fmtDateTime(pm.date)} ${pm.note}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)} } }
   item{Spacer(Modifier.height(90.dp))}
  }
 }
}
