package com.agon.app.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.data.*
import com.agon.app.ui.components.*
import com.agon.app.ui.theme.Gold
import com.agon.app.ui.theme.SuccessGreen
import com.agon.app.viewmodel.*

@Composable fun ProductsScreen(vm:MiyarViewModel,back:()->Unit,nav:(String)->Unit,onVoice:()->Unit){
 val db by vm.db.collectAsState(); var q by remember{mutableStateOf("")}; var cat by remember{mutableStateOf("الكل")}; var sort by remember{mutableStateOf("الاسم")}
 val cats=listOf("الكل")+(db?.categories?.filter{it.businessId==vm.bid()}?.map{it.name}?:emptyList())
 var list=vm.bizProducts().filter{it.active&&(cat=="الكل"||it.category==cat)&&(q.isBlank()||it.name.contains(q)||it.barcode.contains(q))}
 list= when(sort){"السعر الأعلى"->list.sortedByDescending{it.salePrice};"الأقل مخزون"->list.sortedBy{it.quantity};"الأحدث"->list.sortedByDescending{it.id};else->list.sortedBy{it.name}}
 Column(Modifier.fillMaxSize()){ MiyarTopBar("المنتجات",back,actions={ IconButton(onClick=onVoice){Icon(Icons.Default.Mic,null,tint=Gold)}; IconButton(onClick={nav("product_add")}){Icon(Icons.Default.Add,null,tint=Gold)} })
  Column(Modifier.padding(horizontal=16.dp)){
   OutlinedTextField(q,{q=it},placeholder={Text("بحث بالاسم أو الباركود")},leadingIcon={Icon(Icons.Default.Search,null)},modifier=Modifier.fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(14.dp))
   Spacer(Modifier.height(8.dp)); LazyRowChips(cats,cat){cat=it}
   Spacer(Modifier.height(6.dp)); LazyRowChips(listOf("الاسم","السعر الأعلى","الأقل مخزون","الأحدث"),sort){sort=it}
  }
  if(list.isEmpty()) EmptyState(Icons.Default.Inventory2,"لا منتجات","أضف منتجك الأول لبدء البيع والكاشير.","إضافة منتج"){nav("product_add")}
  else LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
   items(list){p-> Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth().clickable{nav("product_detail/${p.id}")}){ Row(Modifier.padding(11.dp),verticalAlignment=Alignment.CenterVertically){ ProductImage(p,Modifier.size(56.dp).clip(RoundedCornerShape(12.dp))); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Bold,fontSize=14.sp,maxLines=1,overflow=TextOverflow.Ellipsis); Text("${p.category} • ${p.unit}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant); Row(verticalAlignment=Alignment.CenterVertically){ Text("متوفر: ${p.quantity}",fontSize=11.sp,color=if(p.quantity<=p.minStock)MaterialTheme.colorScheme.error else SuccessGreen); if(p.quantity<=p.minStock){Spacer(Modifier.width(6.dp)); AlertChip("منخفض")} } }; Column(horizontalAlignment=Alignment.End){ MoneyText(vm,p.salePrice,fontSize=14); Text("شراء ${fmtMoney(p.purchasePrice)}",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) } } } }
   item{Spacer(Modifier.height(80.dp))}
  }
 }
}
@Composable fun LazyRowChips(options:List<String>,selected:String,onSelect:(String)->Unit){
 androidx.compose.foundation.lazy.LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){ items(options){o-> FilterChip(selected=selected==o,onClick={onSelect(o)},label={Text(o,fontSize=11.sp)}) } }
}
@Composable fun ProductFormScreen(vm:MiyarViewModel,productId:String?,back:()->Unit,onVoice:()->Unit){
 val db by vm.db.collectAsState()
 val existing= if(productId!=null) vm.bizProducts().find{it.id==productId} else null
 var name by remember{ mutableStateOf(existing?.name?:"")}; var desc by remember{mutableStateOf(existing?.description?:"")}
 var cat by remember{ mutableStateOf(existing?.category?:"عام")}; var barcode by remember{mutableStateOf(existing?.barcode?:"")}
 var buy by remember{ mutableStateOf(existing?.purchasePrice?.toString()?:"")}; var sell by remember{ mutableStateOf(existing?.salePrice?.toString()?:"")}
 var qty by remember{ mutableStateOf(existing?.quantity?.toString()?:"")}; var minS by remember{ mutableStateOf(existing?.minStock?.toString()?:"5")}
 var unit by remember{ mutableStateOf(existing?.unit?:"حبة")}; var expiry by remember{ mutableStateOf(existing?.expiryDate?:"")}; var img by remember{ mutableStateOf(existing?.imageName?:"")}
 val cats=(db?.categories?.filter{it.businessId==vm.bid()}?.map{it.name}?:listOf("عام"))
 Column(Modifier.fillMaxSize()){ MiyarTopBar(if(existing!=null)"تعديل منتج" else "إضافة منتج جديد",back,actions={ IconButton(onClick=onVoice){Icon(Icons.Default.Mic,null,tint=Gold)} })
  Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
   MiyarTextField(name,{name=it},"اسم المنتج *",icon=Icons.Default.Label); MiyarTextField(desc,{desc=it},"الوصف",icon=Icons.Default.Description,singleLine=false)
   DropdownField("التصنيف",cat,cats){cat=it}
   MiyarTextField(barcode,{barcode=it},"الباركود",icon=Icons.Default.QrCode,keyboardType=KeyboardType.Number)
   Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ MiyarTextField(buy,{buy=it},"سعر الشراء",icon=Icons.Default.ShoppingCart,keyboardType=KeyboardType.Number,modifier=Modifier.weight(1f)); MiyarTextField(sell,{sell=it},"سعر البيع",icon=Icons.Default.Sell,keyboardType=KeyboardType.Number,modifier=Modifier.weight(1f)) }
   Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ MiyarTextField(qty,{qty=it},"الكمية",icon=Icons.Default.Inventory,keyboardType=KeyboardType.Number,modifier=Modifier.weight(1f)); MiyarTextField(minS,{minS=it},"الحد الأدنى",icon=Icons.Default.LowPriority,keyboardType=KeyboardType.Number,modifier=Modifier.weight(1f)) }
   DropdownField("وحدة القياس",unit,UNITS){unit=it}
   MiyarTextField(expiry,{expiry=it},"تاريخ الصلاحية (مثال 2027/06/01)",icon=Icons.Default.Event)
   Text("صورة المنتج (مخزنة محلياً)",fontWeight=FontWeight.Bold,fontSize=13.sp)
   LazyRowChips(listOf("prod_rice","prod_oil","prod_sugar","prod_dates","prod_coffee","prod_milk",""),img){img=it}
   if(img.isNotBlank()) ProductImage(Product(id="t",name=name.ifBlank{"منتج"},imageName=img),Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(14.dp)))
   GoldButton(if(existing!=null)"حفظ التعديلات" else "إضافة المنتج",Icons.Default.Save,Modifier.fillMaxWidth()){ val p=Product(id=existing?.id?:newId(),businessId=vm.bid(),name=name.trim(),description=desc.trim(),barcode=barcode.trim(),category=cat,purchasePrice=buy.toDoubleOrNull()?:0.0,salePrice=sell.toDoubleOrNull()?:0.0,quantity=qty.toIntOrNull()?:0,minStock=minS.toIntOrNull()?:5,unit=unit,expiryDate=expiry.trim(),active=existing?.active?:true,supplierName=existing?.supplierName?:"",imageName=img); vm.saveProduct(p,existing==null); back() }
   Spacer(Modifier.height(90.dp))
  }
 }
}
@Composable fun ProductDetailScreen(vm:MiyarViewModel,productId:String,back:()->Unit,nav:(String)->Unit,onVoice:()->Unit){
 val db by vm.db.collectAsState(); val p=vm.bizProducts().find{it.id==productId}
 val moves=db?.movements?.filter{it.productId==productId}?.sortedByDescending{it.date}?:emptyList()
 var showStock by remember{mutableStateOf(false)}; var delta by remember{mutableStateOf("")}; var type by remember{mutableStateOf("إضافة")}; var reason by remember{mutableStateOf("")}
 Column(Modifier.fillMaxSize()){ MiyarTopBar(p?.name?:"تفاصيل المنتج",back,actions={ IconButton(onClick=onVoice){Icon(Icons.Default.Mic,null,tint=Gold)}; IconButton(onClick={if(p!=null){vm.toggleProduct(p.id); vm.showToast(if(p.active)"تم إيقاف المنتج" else "تم تفعيل المنتج")}}){Icon(if(p?.active==true)Icons.Default.PauseCircle else Icons.Default.PlayCircle,null)} })
  if(p==null) EmptyState(Icons.Default.Inventory2,"المنتج غير موجود","ربما تم حذفه.")
  else Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
   Row(verticalAlignment=Alignment.CenterVertically){ ProductImage(p,Modifier.size(84.dp).clip(RoundedCornerShape(16.dp))); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.ExtraBold,fontSize=17.sp); Text("${p.category} • ${p.unit}",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant); if(p.quantity<=p.minStock) AlertChip("مخزون منخفض: ${p.quantity}") } }
   Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ StatCard("سعر البيع",fmtMoney(p.salePrice),Icons.Default.Sell,Modifier.weight(1f)); StatCard("سعر الشراء",fmtMoney(p.purchasePrice),Icons.Default.ShoppingCart,Modifier.weight(1f)); StatCard("الربح/وحدة",fmtMoney(p.salePrice-p.purchasePrice),Icons.Default.TrendingUp,Modifier.weight(1f)) }
   Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ StatCard("المتوفر",p.quantity.toString(),Icons.Default.Inventory,Modifier.weight(1f)); StatCard("الحد الأدنى",p.minStock.toString(),Icons.Default.LowPriority,Modifier.weight(1f)); StatCard("الصلاحية",p.expiryDate.ifBlank{"—"},Icons.Default.Event,Modifier.weight(1f)) }
   if(p.description.isNotBlank()) Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Column(Modifier.padding(14.dp)){Text("الوصف",fontWeight=FontWeight.Bold,fontSize=13.sp);Text(p.description,fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}}
   Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ GoldButton("تعديل",Icons.Default.Edit,Modifier.weight(1f)){nav("product_add/${p.id}")}; OutlinedButton(onClick={showStock=true},modifier=Modifier.weight(1f).height(50.dp),shape=RoundedCornerShape(14.dp)){Icon(Icons.Default.SwapHoriz,null,tint=Gold); Spacer(Modifier.width(6.dp)); Text("حركة مخزون")} }
   SectionTitle("سجل حركات هذا المنتج")
   if(moves.isEmpty()) Text("لا حركات مسجلة بعد.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
   moves.take(12).forEach{m-> Card(shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant),modifier=Modifier.fillMaxWidth()){ Row(Modifier.padding(11.dp),verticalAlignment=Alignment.CenterVertically){ Icon(if(m.delta>0)Icons.Default.TrendingUp else Icons.Default.TrendingDown,null,tint=if(m.delta>0)SuccessGreen else MaterialTheme.colorScheme.error); Spacer(Modifier.width(9.dp)); Column(Modifier.weight(1f)){Text("${m.type} • ${m.reason}",fontSize=13.sp,fontWeight=FontWeight.Bold); Text("${m.userName} • ${fmtDateTime(m.date)} • قبل ${m.before} / بعد ${m.after}",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}; Text((if(m.delta>0) "+" else "")+m.delta,fontWeight=FontWeight.ExtraBold,color=if(m.delta>0)SuccessGreen else MaterialTheme.colorScheme.error) } } }
   Spacer(Modifier.height(90.dp))
  }
 }
 if(showStock&&p!=null) AlertDialog(onDismissRequest={showStock=false},title={Text("تسجيل حركة مخزون")},text={ Column{ Text("المتاح حالياً: ${p.quantity} ${p.unit}",fontSize=12.sp); Spacer(Modifier.height(8.dp)); DropdownField("نوع الحركة",type,listOf("إضافة","صرف","تلف","تسوية","نقل بين الفروع")){type=it}; Spacer(Modifier.height(8.dp)); MiyarTextField(delta,{delta=it},"الكمية (+/−)",icon=Icons.Default.Numbers,keyboardType=KeyboardType.Number); Spacer(Modifier.height(8.dp)); MiyarTextField(reason,{reason=it},"السبب",icon=Icons.Default.Notes) } },confirmButton={ TextButton(onClick={ val q=delta.toIntOrNull()?:0; val signed= if(type=="إضافة"||type=="نقل بين الفروع") q else -q; vm.adjustStock(p.id,signed,type,reason.ifBlank{"تسجيل يدوي"}); showStock=false }){Text("تنفيذ")} },dismissButton={TextButton(onClick={showStock=false}){Text("إلغاء")}})
}
@Composable fun CategoriesScreen(vm:MiyarViewModel,back:()->Unit){
 val db by vm.db.collectAsState(); var name by remember{mutableStateOf("")}
 val cats=db?.categories?.filter{it.businessId==vm.bid()}?:emptyList()
 Column(Modifier.fillMaxSize()){ MiyarTopBar("التصنيفات",back)
  Column(Modifier.padding(16.dp)){ Row(verticalAlignment=Alignment.CenterVertically){ MiyarTextField(name,{name=it},"تصنيف جديد",icon=Icons.Default.Category,modifier=Modifier.weight(1f)); Spacer(Modifier.width(8.dp)); FilledIconButton(onClick={if(name.isNotBlank()){vm.addCategory(name.trim());name=""}},modifier=Modifier.size(52.dp),colors=IconButtonDefaults.filledIconButtonColors(containerColor=Gold,contentColor=Color.Black)){Icon(Icons.Default.Add,null)} } }
  LazyColumn(Modifier.padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
   items(cats){c-> Card(shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth()){ Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){ Icon(Icons.Default.Category,null,tint=Gold); Spacer(Modifier.width(10.dp)); Text(c.name,Modifier.weight(1f),fontWeight=FontWeight.Bold); IconButton(onClick={vm.deleteCategory(c.id)}){Icon(Icons.Default.Delete,null,tint=MaterialTheme.colorScheme.error)} } } }
   item{Spacer(Modifier.height(80.dp))}
  }
 }
}
@Composable fun InventoryScreen(vm:MiyarViewModel,back:()->Unit,nav:(String)->Unit,onVoice:()->Unit){
 val db by vm.db.collectAsState(); var tab by remember{mutableStateOf(0)}; var q by remember{mutableStateOf("")}
 val prods=vm.bizProducts().filter{q.isBlank()||it.name.contains(q)}
 val moves=(db?.movements?.filter{it.businessId==vm.bid()}?.sortedByDescending{it.date}?:emptyList())
 Column(Modifier.fillMaxSize()){
  MiyarTopBar("المخزون والجرد",back,actions={ IconButton(onClick=onVoice){Icon(Icons.Default.Mic,null,tint=Gold)} })
  TabRow(selectedTabIndex=tab,containerColor=Color.Transparent){ Tab(selected=tab==0,onClick={tab=0},text={Text("المخزون")}); Tab(selected=tab==1,onClick={tab=1},text={Text("الحركات")}); Tab(selected=tab==2,onClick={tab=2},text={Text("الجرد")}) }
  when(tab){
   0-> Column(Modifier.fillMaxSize()){
     Column(Modifier.padding(16.dp)){ OutlinedTextField(q,{q=it},placeholder={Text("بحث في المخزون")},leadingIcon={Icon(Icons.Default.Search,null)},modifier=Modifier.fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(14.dp)); Spacer(Modifier.height(8.dp)); Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ StatCard("قيمة المخزون",fmtMoney(prods.sumOf{it.quantity*it.purchasePrice}),Icons.Default.Inventory,Modifier.weight(1f)); StatCard("منخفض",prods.count{it.quantity<=it.minStock}.toString(),Icons.Default.Warning,Modifier.weight(1f),MaterialTheme.colorScheme.error); StatCard("نفد",prods.count{it.quantity==0}.toString(),Icons.Default.ErrorOutline,Modifier.weight(1f),MaterialTheme.colorScheme.error) } }
     LazyColumn(Modifier.padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){ items(prods){p-> Card(shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth().clickable{nav("product_detail/${p.id}")}){ Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){ Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Bold,fontSize=13.sp); Text("الحد ${p.minStock} ${p.unit}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}; Text("${p.quantity}",fontSize=18.sp,fontWeight=FontWeight.ExtraBold,color=if(p.quantity<=p.minStock)MaterialTheme.colorScheme.error else SuccessGreen) } } }; item{Spacer(Modifier.height(80.dp))} }
    }
   1->{ if(moves.isEmpty()) EmptyState(Icons.Default.SwapHoriz,"لا حركات","كل إضافة أو صرف أو تلف سيُسجل هنا.") else LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){ items(moves.take(120)){m-> Card(shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth()){ Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){ Icon(if(m.delta>0)Icons.Default.AddCircle else Icons.Default.RemoveCircle,null,tint=if(m.delta>0)SuccessGreen else MaterialTheme.colorScheme.error); Spacer(Modifier.width(9.dp)); Column(Modifier.weight(1f)){Text(m.productName+" • "+m.type,fontWeight=FontWeight.Bold,fontSize=13.sp); Text(m.reason+" • "+m.userName+" • "+fmtDateTime(m.date),fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant); Text("الفرع: "+m.branchName+" • قبل "+m.before+" ← بعد "+m.after,fontSize=10.sp,color=Gold)}; Text((if(m.delta>0) "+" else "")+m.delta,fontWeight=FontWeight.ExtraBold,color=if(m.delta>0)SuccessGreen else MaterialTheme.colorScheme.error) } } }; item{Spacer(Modifier.height(80.dp))} } }
   else-> StocktakeScreen(vm)
  }
 }
}
@Composable fun StocktakeScreen(vm:MiyarViewModel){
 val prods=vm.bizProducts(); var counts=remember{ mutableStateMapOf<String,String>() }; var title by remember{mutableStateOf("جرد "+fmtDate(now()))}; var done by remember{mutableStateOf(false)}
 Column(Modifier.fillMaxSize()){
  Column(Modifier.padding(horizontal=16.dp)){
   MiyarTextField(title,{title=it},"عنوان الجرد",icon=Icons.Default.FactCheck)
   Spacer(Modifier.height(8.dp)); Text("عدّ الكمية الفعلية لكل منتج — أي فرق سيُسوّى ويُسجل كحركة «جرد» موثقة.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(8.dp))
  }
  LazyColumn(Modifier.weight(1f).padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
   items(prods){p-> Card(shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth()){ Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){ Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Bold,fontSize=13.sp); Text("الدفتري: ${p.quantity}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}; OutlinedTextField(value=counts[p.id]?:"",onValueChange={v->counts[p.id]=v},placeholder={Text("0")},singleLine=true,modifier=Modifier.width(88.dp),keyboardOptions=androidx.compose.foundation.text.KeyboardOptions(keyboardType=KeyboardType.Number)) } } }
   item{ Spacer(Modifier.height(8.dp)); GoldButton("اعتماد الجرد وتسوية الفروقات",Icons.Default.CheckCircle,Modifier.fillMaxWidth()){ val m=counts.mapNotNull{(k,v)-> v.toIntOrNull()?.let{k to it} }.toMap(); vm.createStocktake(title.ifBlank{"جرد يدوي"},m); done=true }; Spacer(Modifier.height(90.dp)) }
  }
  if(done) AlertDialog(onDismissRequest={done=false},title={Text("تم اعتماد الجرد")},text={Text("تمت تسوية الفروقات وتسجيل حركات مخزون موثقة لكل فرق. يمكنك مراجعة «المخزون ← الحركات».")},confirmButton={TextButton(onClick={done=false}){Text("حسناً")}})
 }
}
