package com.agon.app.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.data.ROLES
import com.agon.app.ui.components.*
import com.agon.app.ui.theme.Gold
import com.agon.app.viewmodel.MiyarViewModel

@Composable fun SplashScreen(){
 Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0A0D12),Color(0xFF171D28),Color(0xFF2A2210)))),contentAlignment=Alignment.Center){
  Column(horizontalAlignment=Alignment.CenterHorizontally){ MiyarLogo(92); Spacer(Modifier.height(22.dp)); LinearProgressIndicator(color=Gold,modifier=Modifier.width(140.dp)); Spacer(Modifier.height(14.dp)); Text("نظام ذكي لإدارة الأنشطة التجارية",color=Color.White.copy(alpha=0.75f),fontSize=13.sp); Text("مبيعات • مخازن • محاسبة • موظفون • ذكاء اصطناعي صوتي",color=Gold.copy(alpha=0.8f),fontSize=11.sp) }
 }
}
@Composable fun AuthFlow(vm:MiyarViewModel){
 var screen by remember{mutableStateOf("login")} // login/register/join
 val db by vm.db.collectAsState()
 // if logged in but no business -> create business screen handled from Main
 when(screen){
  "login"->LoginScreen(vm,onRegister={screen="register"},onJoin={screen="join"})
  "register"->RegisterScreen(vm,onBack={screen="login"})
  else->JoinScreen(vm,onBack={screen="login"})
 }
}
@Composable fun LoginScreen(vm:MiyarViewModel,onRegister:()->Unit,onJoin:()->Unit){
 var id by remember{mutableStateOf("")}; var pass by remember{mutableStateOf("")}; var err by remember{mutableStateOf<String?>(null)}; var showForgot by remember{mutableStateOf(false)}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally){
  Spacer(Modifier.height(36.dp)); MiyarLogo(78)
  Spacer(Modifier.height(10.dp)); Text("مرحباً بعودتك إلى تجارتك",fontSize=14.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
  Spacer(Modifier.height(26.dp))
  Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),elevation=CardDefaults.cardElevation(4.dp),modifier=Modifier.fillMaxWidth()){
   Column(Modifier.padding(18.dp)){
    Text("تسجيل الدخول",fontWeight=FontWeight.ExtraBold,fontSize=19.sp); Spacer(Modifier.height(14.dp))
    MiyarTextField(id,{id=it},"البريد أو الهاتف أو اسم الحساب",icon=Icons.Default.Person)
    Spacer(Modifier.height(12.dp)); MiyarTextField(pass,{pass=it},"كلمة المرور",icon=Icons.Default.Lock,isPassword=true)
    if(err!=null){Spacer(Modifier.height(10.dp)); Text(err!!,color=MaterialTheme.colorScheme.error,fontSize=13.sp)}
    Spacer(Modifier.height(16.dp)); GoldButton("دخول إلى مِعيار",Icons.Default.Login,Modifier.fillMaxWidth()){ vm.login(id.trim(),pass){e->err=e} }
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){ TextButton(onClick={showForgot=true}){Text("نسيت كلمة المرور؟")}; TextButton(onClick=onJoin){Text("طلب انضمام كموظف",color=Gold)} }
   }
  }
  Spacer(Modifier.height(16.dp))
  OutlinedButton(onClick={vm.ensureDemo()},modifier=Modifier.fillMaxWidth().height(50.dp),shape=RoundedCornerShape(14.dp)){ Icon(Icons.Default.PlayCircle,null,tint=Gold); Spacer(Modifier.width(8.dp)); Text("دخول تجريبي فوري — أسواق المِعيار (بيانات كاملة)",fontWeight=FontWeight.Bold) }
  Spacer(Modifier.height(10.dp)); Text("حساب تجريبي: demo@miyar.app / 123456",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
  Spacer(Modifier.height(14.dp)); Row{ Text("ليس لديك حساب؟ "); TextButton(onClick=onRegister){Text("إنشاء حساب ونشاط تجاري",fontWeight=FontWeight.Bold,color=Gold)} }
  Spacer(Modifier.height(8.dp)); Text("تسجيل Google / Firebase يتطلب إعداد google-services.json من مالك المشروع — الحساب المحلي المشفر (PBKDF2) يعمل الآن دون إنترنت.",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
 }
 if(showForgot) AlertDialog(onDismissRequest={showForgot=false},title={Text("استعادة كلمة المرور")},text={Text("في النسخة المحلية دون خادم، الاستعادة تتم عبر مدير النشاط من شاشة الموظفين، أو عبر Firebase Authentication بعد إعداد مشروع Firebase من المالك. لا يتم إرسال أي بريد وهمي.")},confirmButton={TextButton(onClick={showForgot=false}){Text("حسناً")}})
}
@Composable fun RegisterScreen(vm:MiyarViewModel,onBack:()->Unit){
 var name by remember{mutableStateOf("")}; var phone by remember{mutableStateOf("")}; var email by remember{mutableStateOf("")}; var pass by remember{mutableStateOf("")}; var err by remember{mutableStateOf<String?>(null)}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)){
  MiyarTopBar("إنشاء حساب جديد",onBack=onBack)
  MiyarLogo(56,false); Spacer(Modifier.height(8.dp)); Text("خطوة واحدة تفصلك عن إدارة تجارتك بذكاء",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=13.sp)
  Spacer(Modifier.height(18.dp))
  MiyarTextField(name,{name=it},"الاسم الكامل",icon=Icons.Default.Person); Spacer(Modifier.height(12.dp))
  MiyarTextField(phone,{phone=it},"رقم الهاتف",icon=Icons.Default.Phone,keyboardType=KeyboardType.Phone); Spacer(Modifier.height(12.dp))
  MiyarTextField(email,{email=it},"البريد الإلكتروني (اختياري)",icon=Icons.Default.Email,keyboardType=KeyboardType.Email); Spacer(Modifier.height(12.dp))
  MiyarTextField(pass,{pass=it},"كلمة المرور (6 أحرف فأكثر)",icon=Icons.Default.Lock,isPassword=true)
  if(err!=null){Spacer(Modifier.height(10.dp)); Text(err!!,color=MaterialTheme.colorScheme.error,fontSize=13.sp)}
  Spacer(Modifier.height(18.dp)); GoldButton("إنشاء الحساب والمتابعة",Icons.Default.PersonAdd,Modifier.fillMaxWidth()){ vm.register(name.trim(),phone.trim(),email.trim(),pass){e->err=e} }
  Spacer(Modifier.height(12.dp)); Text("تُحفظ كلمة المرور مجزّأة بخوارزمية PBKDF2-HMAC-SHA256 ولا تُخزن نصياً أبداً.",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
 }
}
@Composable fun CreateBusinessScreen(vm:MiyarViewModel){
 var name by remember{mutableStateOf("")}; var type by remember{mutableStateOf("تجارة مواد غذائية")}; var currency by remember{mutableStateOf("ر.ي")}; var branch by remember{mutableStateOf("الفرع الرئيسي")}
 val types=listOf("تجارة مواد غذائية","سوبر ماركت","صيدلية","ملابس","إلكترونيات","مواد بناء","مطعم / مقهى","تجارة عامة","أخرى")
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)){
  Spacer(Modifier.height(24.dp)); MiyarLogo(64); Spacer(Modifier.height(16.dp))
  Text("أنشئ نشاطك التجاري",fontWeight=FontWeight.ExtraBold,fontSize=22.sp); Text("سيكون لكل نشاط بيانات معزولة تماماً وفروع وموظفون ورمز انضمام خاص.",fontSize=13.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
  Spacer(Modifier.height(20.dp))
  MiyarTextField(name,{name=it},"اسم النشاط التجاري *",icon=Icons.Default.Store,placeholder="مثال: أسواق النور المركزية"); Spacer(Modifier.height(12.dp))
  DropdownField("نوع النشاط",type,types,{type=it}); Spacer(Modifier.height(12.dp))
  DropdownField("العملة",currency,listOf("ر.ي","ر.س","ج.م","د.ك","$","€"),{currency=it}); Spacer(Modifier.height(12.dp))
  MiyarTextField(branch,{branch=it},"اسم الفرع الأول",icon=Icons.Default.Business)
  Spacer(Modifier.height(20.dp)); GoldButton("إنشاء النشاط والبدء",Icons.Default.RocketLaunch,Modifier.fillMaxWidth(),enabled=name.isNotBlank()){ vm.createBusiness(name.trim(),type,currency,branch.trim()) }
  Spacer(Modifier.height(12.dp)); OutlinedButton(onClick={vm.logout()},modifier=Modifier.fillMaxWidth()){Text("تسجيل الخروج")}
 }
}
@Composable fun JoinScreen(vm:MiyarViewModel,onBack:()->Unit){
 var code by remember{mutableStateOf("")}; var name by remember{mutableStateOf("")}; var phone by remember{mutableStateOf("")}; var role by remember{mutableStateOf("الكاشير")}; var msg by remember{mutableStateOf<String?>(null)}; var done by remember{mutableStateOf(false)}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)){
  MiyarTopBar("طلب الانضمام إلى نشاط",onBack=onBack)
  Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Gold.copy(alpha=0.1f))){ Column(Modifier.padding(14.dp)){ Row{Icon(Icons.Default.QrCodeScanner,null,tint=Gold); Spacer(Modifier.width(8.dp)); Text("كيف تنضم؟",fontWeight=FontWeight.Bold)}; Text("اطلب رمز النشاط من المدير (يظهر في: المزيد ← الأنشطة التجارية، مثال MY-2026). سيصله طلبك ويقبله ويحدد صلاحياتك، ثم يفعّل حسابك.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)} }
  Spacer(Modifier.height(16.dp))
  MiyarTextField(code,{code=it},"رمز النشاط التجاري *",icon=Icons.Default.Key,placeholder="MY-0000"); Spacer(Modifier.height(12.dp))
  MiyarTextField(name,{name=it},"اسمك الكامل",icon=Icons.Default.Person); Spacer(Modifier.height(12.dp))
  MiyarTextField(phone,{phone=it},"رقم الهاتف",icon=Icons.Default.Phone,keyboardType=KeyboardType.Phone); Spacer(Modifier.height(12.dp))
  DropdownField("الدور المطلوب",role,ROLES.filter{it!="المالك"},{role=it})
  if(msg!=null){Spacer(Modifier.height(10.dp)); Text(msg!!,color=if(done)MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.error,fontSize=13.sp)}
  Spacer(Modifier.height(18.dp)); GoldButton("إرسال طلب الانضمام",Icons.Default.Send,Modifier.fillMaxWidth()){ vm.requestJoin(code,name,phone,role){e-> if(e==null){done=true;msg="✓ تم إرسال الطلب إلى مدير النشاط. انتظر القبول وتحديد الصلاحيات."}else{done=false;msg=e}} }
 }
}
@Composable fun LockScreen(vm:MiyarViewModel){
 var pass by remember{mutableStateOf("")}; var err by remember{mutableStateOf<String?>(null)}
 Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0A0D12),Color(0xFF171D28)))),contentAlignment=Alignment.Center){
  Column(Modifier.padding(24.dp).fillMaxWidth(),horizontalAlignment=Alignment.CenterHorizontally){
   MiyarLogo(72); Spacer(Modifier.height(16.dp))
   Text("التطبيق مقفل لحمايتك",fontWeight=FontWeight.Bold,fontSize=19.sp,color=Color.White); Text("تم القفل بعد فترة عدم نشاط. جلستك وسلة البيع محفوظتان.",fontSize=12.sp,color=Color.White.copy(alpha=0.7f))
   Spacer(Modifier.height(22.dp))
   OutlinedTextField(value=pass,onValueChange={pass=it},label={Text("كلمة المرور لفتح القفل")},singleLine=true,visualTransformation=androidx.compose.ui.text.input.PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),leadingIcon={Icon(Icons.Default.Lock,null,tint=Gold)})
   if(err!=null){Spacer(Modifier.height(8.dp)); Text(err!!,color=MaterialTheme.colorScheme.error,fontSize=13.sp)}
   Spacer(Modifier.height(16.dp)); GoldButton("فتح القفل والمتابعة",Icons.Default.Fingerprint,Modifier.fillMaxWidth()){ vm.unlock(pass){e->err=e} }
   Spacer(Modifier.height(10.dp)); Text("البصمة: فعّل قفل الجهاز الحيوي من إعدادات هاتفك — كلمة المرور هي البديل المعتمد هنا.",fontSize=11.sp,color=Color.White.copy(alpha=0.55f))
   TextButton(onClick={vm.logout()}){Text("تسجيل الخروج نهائياً",color=Color.White.copy(alpha=0.7f))}
  }
 }
}
