package com.agon.app.data
import kotlinx.serialization.Serializable
import java.util.UUID

fun newId(): String = UUID.randomUUID().toString()
fun now(): Long = System.currentTimeMillis()

@Serializable data class User(val id:String=newId(),val name:String="",val phone:String="",val email:String="",val passwordHash:String="",val salt:String="")
@Serializable data class Business(val id:String=newId(),val name:String="",val type:String="تجارة عامة",val ownerId:String="",val code:String="",val currency:String="ر.ي",val createdAt:Long=now())
@Serializable data class Branch(val id:String=newId(),val businessId:String="",val name:String="",val manager:String="",val address:String="")
@Serializable data class Product(val id:String=newId(),val businessId:String="",val name:String="",val description:String="",val barcode:String="",val category:String="عام",val purchasePrice:Double=0.0,val salePrice:Double=0.0,val quantity:Int=0,val minStock:Int=5,val unit:String="حبة",val expiryDate:String="",val active:Boolean=true,val supplierName:String="",val imageName:String="")
@Serializable data class CategoryItem(val id:String=newId(),val businessId:String="",val name:String="")
@Serializable data class StockMovement(val id:String=newId(),val businessId:String="",val productId:String="",val productName:String="",val delta:Int=0,val type:String="",val reason:String="",val userName:String="",val date:Long=now(),val before:Int=0,val after:Int=0,val branchName:String="")
@Serializable data class Stocktake(val id:String=newId(),val businessId:String="",val title:String="",val date:Long=now(),val items:Int=0,val discrepancies:Int=0,val note:String="")
@Serializable data class Customer(val id:String=newId(),val businessId:String="",val name:String="",val phone:String="",val address:String="",val balance:Double=0.0,val notes:String="")
@Serializable data class Supplier(val id:String=newId(),val businessId:String="",val name:String="",val phone:String="",val address:String="",val balance:Double=0.0,val notes:String="")
@Serializable data class LineItem(val productId:String="",val productName:String="",var qty:Int=1,val price:Double=0.0,val cost:Double=0.0)
@Serializable data class Sale(val id:String=newId(),val businessId:String="",val branchId:String="",val number:String="",val customerId:String="",val customerName:String="عميل نقدي",val items:List<LineItem> = emptyList(),val subtotal:Double=0.0,val discount:Double=0.0,val total:Double=0.0,val paid:Double=0.0,val remaining:Double=0.0,val paymentType:String="نقداً",val date:Long=now(),val userName:String="",val status:String="مكتملة")
@Serializable data class Purchase(val id:String=newId(),val businessId:String="",val branchId:String="",val number:String="",val supplierId:String="",val supplierName:String="",val items:List<LineItem> = emptyList(),val subtotal:Double=0.0,val discount:Double=0.0,val total:Double=0.0,val paid:Double=0.0,val remaining:Double=0.0,val date:Long=now(),val userName:String="",val status:String="مكتملة")
@Serializable data class Payment(val id:String=newId(),val businessId:String="",val personType:String="عميل",val personId:String="",val personName:String="",val amount:Double=0.0,val date:Long=now(),val note:String="",val relatedInvoice:String="")
@Serializable data class Expense(val id:String=newId(),val businessId:String="",val category:String="أخرى",val title:String="",val amount:Double=0.0,val date:Long=now(),val note:String="",val userName:String="")
@Serializable data class CashTxn(val id:String=newId(),val businessId:String="",val type:String="",val amount:Double=0.0,val note:String="",val date:Long=now(),val userName:String="")
@Serializable data class Shift(val id:String=newId(),val businessId:String="",val openedAt:Long=now(),val closedAt:Long=0L,val openingCash:Double=0.0,val expectedCash:Double=0.0,val actualCash:Double=0.0,val status:String="مفتوحة",val userName:String="")
@Serializable data class Employee(val id:String=newId(),val businessId:String="",val name:String="",val phone:String="",val role:String="كاشير",val active:Boolean=true,val branchName:String="",val permissions:List<String> = emptyList())
@Serializable data class JoinRequest(val id:String=newId(),val businessId:String="",val businessCode:String="",val name:String="",val phone:String="",val requestedRole:String="كاشير",val status:String="قيد الانتظار",val date:Long=now())
@Serializable data class AuditLog(val id:String=newId(),val businessId:String="",val action:String="",val userName:String="",val date:Long=now(),val details:String="")
@Serializable data class AppNotification(val id:String=newId(),val businessId:String="",val title:String="",val body:String="",val date:Long=now(),val type:String="عام",val read:Boolean=false)
@Serializable data class VoiceRecord(val id:String=newId(),val businessId:String="",val command:String="",val response:String="",val date:Long=now(),val executed:Boolean=false)
@Serializable data class AppSettings(val currency:String="ر.ي",val darkMode:Boolean=true,val hideAmounts:Boolean=false,val lockEnabled:Boolean=true,val lockSeconds:Int=60,val ttsEnabled:Boolean=true,val ttsSpeed:Float=1.0f,val notificationsEnabled:Boolean=true,val taxPercent:Double=0.0)

@Serializable data class MiyarDb(
 val users:List<User> = emptyList(),val businesses:List<Business> = emptyList(),val branches:List<Branch> = emptyList(),
 val products:List<Product> = emptyList(),val categories:List<CategoryItem> = emptyList(),val movements:List<StockMovement> = emptyList(),val stocktakes:List<Stocktake> = emptyList(),
 val customers:List<Customer> = emptyList(),val suppliers:List<Supplier> = emptyList(),val sales:List<Sale> = emptyList(),val purchases:List<Purchase> = emptyList(),
 val payments:List<Payment> = emptyList(),val expenses:List<Expense> = emptyList(),val cashTxns:List<CashTxn> = emptyList(),val shifts:List<Shift> = emptyList(),
 val employees:List<Employee> = emptyList(),val joinRequests:List<JoinRequest> = emptyList(),val audits:List<AuditLog> = emptyList(),
 val notifications:List<AppNotification> = emptyList(),val voiceHistory:List<VoiceRecord> = emptyList(),
 val sessionUserId:String="",val currentBusinessId:String="",val currentBranchId:String="",val settings:AppSettings=AppSettings()
)

val ALL_PERMISSIONS = listOf("عرض المنتجات","إضافة منتجات","تعديل المنتجات","حذف المنتجات","البيع","الشراء","إلغاء الفواتير","العملاء","الموردون","المخزون","الجرد","المصروفات","الصندوق","التقارير","الموظفون","الفروع","الإعدادات","التصدير","الطباعة","اعتماد العمليات")
val ROLES = listOf("المالك","المدير العام","مدير الفرع","الكاشير","أمين المخزن","المحاسب","موظف مخصص")
val UNITS = listOf("حبة","علبة","كرتون","كيس","كجم","جرام","لتر","متر","دستة","طقم")
val EXPENSE_CATEGORIES = listOf("إيجار","كهرباء","ماء","رواتب","نقل","صيانة","وقود","اتصالات","أخرى")
fun rolePermissions(role:String):List<String> = when(role){
 "المالك","المدير العام"->ALL_PERMISSIONS
 "الكاشير"->listOf("عرض المنتجات","البيع","العملاء","الطباعة")
 "أمين المخزن"->listOf("عرض المنتجات","إضافة منتجات","تعديل المنتجات","المخزون","الجرد","الشراء")
 "المحاسب"->listOf("عرض المنتجات","التقارير","المصروفات","الصندوق","العملاء","الموردون","التصدير")
 "مدير الفرع"->ALL_PERMISSIONS.filter{it!="حذف المنتجات"}
 else->listOf("عرض المنتجات","البيع")
}
