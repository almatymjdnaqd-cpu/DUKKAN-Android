package com.agon.app.ui.components
import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.R
import com.agon.app.data.Product
import com.agon.app.ui.theme.Gold
import com.agon.app.ui.theme.GoldDark
import com.agon.app.viewmodel.MiyarViewModel
import com.agon.app.viewmodel.fmtMoney
import java.util.Locale

@Composable fun rememberVoiceLauncher(onResult:(String)->Unit, onError:(String)->Unit={}):()->Unit{
 val launcher=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){ res->
   if(res.resultCode==Activity.RESULT_OK){ val list=res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS); val text=list?.firstOrNull(); if(!text.isNullOrBlank()) onResult(text) else onError("لم يتم التعرف على الصوت، جرّب مرة أخرى أو اكتب نصياً") } else onError("تم إلغاء التسجيل الصوتي")
 }
 return {
   try{ val intent=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{ putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ar-YE"); putExtra(RecognizerIntent.EXTRA_PROMPT,"تحدث الآن... مثال: بع لأحمد كيسين أرز") }; launcher.launch(intent) }catch(e:Exception){ onError("التعرف الصوتي غير متاح على هذا الجهاز. استخدم الإدخال النصي") }
 }
}
fun shareText(ctx:android.content.Context,title:String,text:String){ val i=Intent(Intent.ACTION_SEND).apply{type="text/plain"; putExtra(Intent.EXTRA_SUBJECT,title); putExtra(Intent.EXTRA_TEXT,text)}; ctx.startActivity(Intent.createChooser(i,title)) }

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun MiyarTopBar(title:String,onBack:(()->Unit)?=null,subtitle:String?=null,actions:@Composable RowScope.()->Unit={}){
 TopAppBar(title={ Column{ Text(title,fontWeight=FontWeight.Bold,fontSize=19.sp); if(subtitle!=null) Text(subtitle,fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)} },
 navigationIcon={ if(onBack!=null) IconButton(onClick=onBack){ Icon(Icons.AutoMirrored.Filled.ArrowBack,"رجوع")} },
 actions=actions, colors=TopAppBarDefaults.topAppBarColors(containerColor=MaterialTheme.colorScheme.background))
}
@Composable fun MoneyText(vm:MiyarViewModel,amount:Double,modifier:Modifier=Modifier,fontSize:Int=15,bold:Boolean=true,color:Color=Color.Unspecified){
 val db by vm.db.collectAsState(); val hide=db?.settings?.hideAmounts?:false; val cur=db?.settings?.currency?:"ر.ي"
 Text(if(hide)"•••••" else "${fmtMoney(amount)} $cur",modifier=modifier,fontSize=fontSize.sp,fontWeight=if(bold)FontWeight.Bold else FontWeight.Normal,color=color)
}
@Composable fun GoldButton(text:String,icon:ImageVector?=null,modifier:Modifier=Modifier,enabled:Boolean=true,onClick:()->Unit){
 Button(onClick=onClick,modifier=modifier.height(50.dp),enabled=enabled,shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Gold,contentColor=Color(0xFF1A1400))){ if(icon!=null){Icon(icon,null,modifier=Modifier.size(20.dp)); Spacer(Modifier.width(8.dp))}; Text(text,fontWeight=FontWeight.Bold,fontSize=15.sp)}
}
@Composable fun StatCard(title:String,value:String,icon:ImageVector,modifier:Modifier=Modifier,accent:Color=Gold,onClick:(()->Unit)?=null){
 Card(modifier=modifier.then(if(onClick!=null)Modifier.clickable{onClick()}else Modifier),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),elevation=CardDefaults.cardElevation(2.dp)){
  Column(Modifier.padding(14.dp)){ Row(verticalAlignment=Alignment.CenterVertically){ Box(Modifier.size(34.dp).clip(CircleShape).background(accent.copy(alpha=0.16f)),contentAlignment=Alignment.Center){Icon(icon,null,tint=accent,modifier=Modifier.size(19.dp))}; Spacer(Modifier.width(8.dp)); Text(title,fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1,overflow=TextOverflow.Ellipsis)}; Spacer(Modifier.height(8.dp)); Text(value,fontWeight=FontWeight.ExtraBold,fontSize=17.sp,maxLines=1,overflow=TextOverflow.Ellipsis)} }
}
@Composable fun SectionTitle(title:String,action:String?=null,onAction:(()->Unit)?=null){
 Row(Modifier.fillMaxWidth().padding(vertical=6.dp),verticalAlignment=Alignment.CenterVertically){ Text(title,fontWeight=FontWeight.Bold,fontSize=16.sp,modifier=Modifier.weight(1f)); if(action!=null&&onAction!=null) TextButton(onClick=onAction){Text(action,color=GoldDark)} }
}
@Composable fun EmptyState(icon:ImageVector,title:String,body:String,button:String?=null,onClick:(()->Unit)?=null){
 Column(Modifier.fillMaxWidth().padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally){ Box(Modifier.size(72.dp).clip(CircleShape).background(Gold.copy(alpha=0.13f)),contentAlignment=Alignment.Center){Icon(icon,null,tint=Gold,modifier=Modifier.size(34.dp))}; Spacer(Modifier.height(12.dp)); Text(title,fontWeight=FontWeight.Bold,fontSize=17.sp,textAlign=TextAlign.Center); Spacer(Modifier.height(6.dp)); Text(body,fontSize=13.sp,color=MaterialTheme.colorScheme.onSurfaceVariant,textAlign=TextAlign.Center); if(button!=null&&onClick!=null){Spacer(Modifier.height(14.dp)); GoldButton(button,onClick=onClick)} }
}
@Composable fun MiyarTextField(value:String,onChange:(String)->Unit,label:String,modifier:Modifier=Modifier,icon:ImageVector?=null,keyboardType:androidx.compose.ui.text.input.KeyboardType=androidx.compose.ui.text.input.KeyboardType.Text,isPassword:Boolean=false,singleLine:Boolean=true,placeholder:String=""){
 OutlinedTextField(value=value,onValueChange=onChange,label={Text(label)},placeholder={if(placeholder.isNotBlank())Text(placeholder)},modifier=modifier.fillMaxWidth(),singleLine=singleLine,leadingIcon=if(icon!=null){{Icon(icon,null,tint=GoldDark)}}else null,keyboardOptions=androidx.compose.foundation.text.KeyboardOptions(keyboardType=keyboardType),visualTransformation=if(isPassword)androidx.compose.ui.text.input.PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,shape=RoundedCornerShape(14.dp))
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun DropdownField(label:String,value:String,options:List<String>,onSelect:(String)->Unit){
 var exp by remember{mutableStateOf(false)}
 ExposedDropdownMenuBox(expanded=exp,onExpandedChange={exp=!exp},modifier=Modifier.fillMaxWidth()){ OutlinedTextField(value=value,onValueChange={},readOnly=true,label={Text(label)},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(exp)},modifier=Modifier.menuAnchor().fillMaxWidth(),shape=RoundedCornerShape(14.dp)); ExposedDropdownMenu(expanded=exp,onDismissRequest={exp=false}){ options.forEach{ DropdownMenuItem(text={Text(it)},onClick={onSelect(it);exp=false}) } } }
}
@Composable fun ProductImage(p:Product,modifier:Modifier=Modifier){
 val res=when(p.imageName){ "prod_rice"->R.drawable.prod_rice; "prod_oil"->R.drawable.prod_oil; "prod_sugar"->R.drawable.prod_sugar; "prod_dates"->R.drawable.prod_dates; "prod_coffee"->R.drawable.prod_coffee; "prod_milk"->R.drawable.prod_milk; else->null }
 if(res!=null) Image(painterResource(res),p.name,modifier=modifier,contentScale=ContentScale.Crop)
 else Box(modifier.background(Brush.linearGradient(listOf(Gold.copy(alpha=0.35f),Color(0xFF2A3348)))),contentAlignment=Alignment.Center){ Text(p.name.take(1),fontSize=26.sp,fontWeight=FontWeight.ExtraBold,color=Gold) }
}
@Composable fun BarChart(data:List<Pair<String,Double>>,modifier:Modifier=Modifier){
 val max=(data.maxOfOrNull{it.second}?:1.0).coerceAtLeast(1.0)
 Column(modifier){ Row(Modifier.fillMaxWidth().height(150.dp),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.Bottom){ data.forEach{(label,v)-> Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.weight(1f)){ Text(if(v>=1000)"${(v/1000).toInt()}k" else v.toInt().toString(),fontSize=9.sp,color=MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(4.dp)); Box(Modifier.width(24.dp).height((110*(v/max)).dp.coerceAtLeast(4.dp)).clip(RoundedCornerShape(topStart=7.dp,topEnd=7.dp)).background(Brush.verticalGradient(listOf(Gold,GoldDark)))) } } }; Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly){ data.forEach{(label,_)-> Text(label,fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.weight(1f),textAlign=TextAlign.Center,maxLines=1)} } }
}
@Composable fun BarcodeView(code:String,modifier:Modifier=Modifier){
 Column(modifier, horizontalAlignment=Alignment.CenterHorizontally){
  Canvas(Modifier.fillMaxWidth().height(64.dp).background(Color.White).padding(6.dp)){ val chars=code.ifBlank{"000000"}; var x=8f; chars.forEachIndexed{i,c-> val n=(c.code%7)+2; for(k in 0 until n){ val w= if((c.code+k)%2==0) 3f else 6f; drawRect(Color.Black,topLeft=Offset(x,4f),size=Size(w,size.height-18f)); x+=w+3f }; x+=5f } }
  Text(code,fontSize=12.sp,color=Color.Black,modifier=Modifier.background(Color.White).fillMaxWidth(),textAlign=TextAlign.Center)
 }
}
@Composable fun MiyarLogo(size:Int=64,showName:Boolean=true){
 Column(horizontalAlignment=Alignment.CenterHorizontally){
  Box(Modifier.size(size.dp).clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(listOf(Color(0xFF171D28),Color(0xFF2A2210)))),contentAlignment=Alignment.Center){ Icon(Icons.Default.Scale,null,tint=Gold,modifier=Modifier.size((size*0.55).dp)) }
  if(showName){ Spacer(Modifier.height(10.dp)); Text("مِعيار  MI'YAR",fontWeight=FontWeight.ExtraBold,fontSize=24.sp,color=Gold); Text("الدقة معيارُ تجارتك",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) }
 }
}
@Composable fun AlertChip(text:String,color:Color=MaterialTheme.colorScheme.error){ Surface(shape=RoundedCornerShape(20.dp),color=color.copy(alpha=0.13f)){ Text(text,fontSize=11.sp,color=color,modifier=Modifier.padding(horizontal=8.dp,vertical=3.dp),fontWeight=FontWeight.Bold)} }
