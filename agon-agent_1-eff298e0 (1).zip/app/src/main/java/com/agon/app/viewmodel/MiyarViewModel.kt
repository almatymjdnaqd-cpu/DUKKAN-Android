package com.agon.app.viewmodel
import android.app.Application
import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Base64
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.agon.app.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.*
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name="miyar_db")
val DB_KEY = stringPreferencesKey("db_json")
val json = Json { ignoreUnknownKeys=true; encodeDefaults=true }

fun hashPassword(password:String, saltB64:String):String{
 val salt=Base64.decode(saltB64,Base64.DEFAULT)
 val spec=PBEKeySpec(password.toCharArray(),salt,120000,256)
 val f=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
 return Base64.encodeToString(f.generateSecret(spec).encoded,Base64.NO_WRAP)
}
fun newSalt():String{ val b=ByteArray(16); SecureRandom().nextBytes(b); return Base64.encodeToString(b,Base64.NO_WRAP)}
fun fmtDate(ts:Long):String= SimpleDateFormat("yyyy/MM/dd",Locale("ar")).format(Date(ts))
fun fmtDateTime(ts:Long):String= SimpleDateFormat("yyyy/MM/dd - hh:mm a",Locale("ar")).format(Date(ts))
fun fmtMoney(v:Double):String{ return String.format(Locale.US,"%,.0f",v) }
fun isToday(ts:Long):Boolean{ val c1=Calendar.getInstance(); val c2=Calendar.getInstance().apply{timeInMillis=ts}; return c1.get(Calendar.YEAR)==c2.get(Calendar.YEAR)&&c1.get(Calendar.DAY_OF_YEAR)==c2.get(Calendar.DAY_OF_YEAR)}
fun dayStart(offsetDays:Int=0):Long{ val c=Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR,-offsetDays); c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0); return c.timeInMillis }

data class PendingAction(val type:String,val summary:String,val productId:String="",val customerId:String="",val supplierId:String="",val qty:Int=0,val amount:Double=0.0,val category:String="",val name:String="",val buy:Double=0.0,val sell:Double=0.0)
data class AiResult(val message:String,val pending:PendingAction?=null,val navigateTo:String?=null)

class Speaker(ctx:Context){
 var tts:TextToSpeech?=null; var ready=false
 init{ tts=TextToSpeech(ctx){s-> if(s==TextToSpeech.SUCCESS){ try{tts?.language=Locale("ar","SA")}catch(e:Exception){}; ready=true } } }
 fun speak(text:String,speed:Float=1f){ if(ready){ tts?.setSpeechRate(speed); tts?.speak(text,TextToSpeech.QUEUE_FLUSH,null,"miyar") } }
 fun stop(){ tts?.stop() }
}

class MiyarViewModel(app:Application):AndroidViewModel(app){
 private val ctx=app.applicationContext
 val speaker=Speaker(ctx)
 private val _db=MutableStateFlow<MiyarDb?>(null); val db:StateFlow<MiyarDb?> = _db
 val cart=MutableStateFlow<List<LineItem>>(emptyList())
 val purchaseCart=MutableStateFlow<List<LineItem>>(emptyList())
 val locked=MutableStateFlow(false)
 val lastTouch=MutableStateFlow(System.currentTimeMillis())
 val pendingAction=MutableStateFlow<PendingAction?>(null)
 val aiMessages=MutableStateFlow<List<Pair<Boolean,String>>>(listOf(false to "أهلاً بك في MIYAR AI — مساعد مِعيار الذكي. قل أو اكتب أمراً مثل: «بع لأحمد كيسين أرز» أو «كم مبيعات اليوم؟» أو «سجل مصروف كهرباء 3000 ريال». لن أنفذ أي عملية مالية دون تأكيدك الصريح."))
 val toast=MutableStateFlow<String?>(null)
 val syncState=MutableStateFlow("محلي — Offline First ✓ جميع البيانات محفوظة على الجهاز")
 var aiPrefillCustomerId=""; var aiSearchQuery=""

 init{
   viewModelScope.launch{
     ctx.dataStore.data.first().let{ prefs->
       val raw=prefs[DB_KEY]
       _db.value= if(raw.isNullOrBlank()) MiyarDb() else try{ json.decodeFromString<MiyarDb>(raw)}catch(e:Exception){MiyarDb()}
     }
   }
   // lock watcher
   viewModelScope.launch{ while(true){ kotlinx.coroutines.delay(4000); val d=_db.value?:continue; if(d.sessionUserId.isNotBlank() && d.settings.lockEnabled && !locked.value){ if(System.currentTimeMillis()-lastTouch.value > d.settings.lockSeconds*1000L) locked.value=true } } }
 }
 fun touch(){ lastTouch.value=System.currentTimeMillis() }
 fun showToast(m:String){ toast.value=m }
 fun clearToast(){ toast.value=null }
 private fun save(newDb:MiyarDb){ _db.value=newDb; viewModelScope.launch{ ctx.dataStore.edit{ it[DB_KEY]=json.encodeToString(newDb)} } }
 private fun update(fn:(MiyarDb)->MiyarDb){ val cur=_db.value?:return; save(fn(cur)) }
 // getters
 fun curUser():User? = _db.value?.let{d-> d.users.find{it.id==d.sessionUserId}}
 fun curBusiness():Business? = _db.value?.let{d-> d.businesses.find{it.id==d.currentBusinessId}}
 fun curBranch():Branch? = _db.value?.let{d-> d.branches.find{it.id==d.currentBranchId}}
 fun bid():String=_db.value?.currentBusinessId?:""
 fun hasPerm(p:String):Boolean{ val d=_db.value?:return false; val u=curUser()?:return false; val b=curBusiness()?:return true; if(b.ownerId==u.id) return true; val emp=d.employees.find{it.businessId==b.id && (it.phone==u.phone||it.name==u.name)}; return emp?.permissions?.contains(p)?:true }
 private fun audit(d:MiyarDb,action:String,details:String):List<AuditLog>{ return d.audits + AuditLog(businessId=d.currentBusinessId,action=action,userName=curUser()?.name?:"",details=details) }
 private fun notify(d:MiyarDb,title:String,body:String,type:String="عام"):List<AppNotification>{ if(!d.settings.notificationsEnabled) return d.notifications; return d.notifications + AppNotification(businessId=d.currentBusinessId,title=title,body=body,type=type) }

 // ---- AUTH ----
 fun register(name:String,phone:String,email:String,pass:String,onResult:(String?)->Unit){
   val d=_db.value?:return
   if(name.isBlank()||pass.length<6){onResult("أدخل الاسم وكلمة مرور لا تقل عن 6 أحرف");return}
   if(phone.isBlank()&&email.isBlank()){onResult("أدخل رقم الهاتف أو البريد الإلكتروني");return}
   if(d.users.any{(phone.isNotBlank()&&it.phone==phone)||(email.isNotBlank()&&it.email.equals(email,true))}){onResult("يوجد حساب مسجل بهذا الهاتف أو البريد مسبقاً");return}
   val salt=newSalt(); val u=User(name=name,phone=phone,email=email,salt=salt,passwordHash=hashPassword(pass,salt))
   save(d.copy(users=d.users+u,sessionUserId=u.id)); touch(); onResult(null)
 }
 fun login(identifier:String,pass:String,onResult:(String?)->Unit){
   val d=_db.value?:return
   val u=d.users.find{it.phone==identifier||it.email.equals(identifier,true)||it.name==identifier}
   if(u==null){onResult("لم نجد حساباً بهذه البيانات. تأكد أو أنشئ حساباً جديداً");return}
   if(hashPassword(pass,u.salt)!=u.passwordHash){onResult("كلمة المرور غير صحيحة");return}
   val biz=d.businesses.find{it.ownerId==u.id} ?: d.businesses.firstOrNull{ b-> d.employees.any{it.businessId==b.id && it.phone==u.phone}}
   val branch= if(biz!=null) d.branches.find{it.businessId==biz.id} else null
   save(d.copy(sessionUserId=u.id,currentBusinessId=biz?.id?:"",currentBranchId=branch?.id?:"")); locked.value=false; touch(); onResult(null)
 }
 fun logout(){ update{it.copy(sessionUserId="",currentBusinessId="",currentBranchId="")}; cart.value=emptyList(); locked.value=false }
 fun unlock(pass:String,onResult:(String?)->Unit){ val u=curUser(); if(u==null){onResult("لا توجد جلسة");return}; if(hashPassword(pass,u.salt)==u.passwordHash){locked.value=false;touch();onResult(null)}else onResult("كلمة المرور غير صحيحة") }
 fun changePassword(old:String,newPass:String,onResult:(String?)->Unit){ val u=curUser()?:return; if(hashPassword(old,u.salt)!=u.passwordHash){onResult("كلمة المرور الحالية غير صحيحة");return}; if(newPass.length<6){onResult("كلمة المرور الجديدة قصيرة");return}; val salt=newSalt(); update{d->d.copy(users=d.users.map{if(it.id==u.id) it.copy(salt=salt,passwordHash=hashPassword(newPass,salt)) else it})}; onResult(null) }
 fun updateProfile(name:String,phone:String,email:String){ val u=curUser()?:return; update{d->d.copy(users=d.users.map{if(it.id==u.id) it.copy(name=name,phone=phone,email=email) else it})} ; showToast("تم تحديث الملف الشخصي") }

 fun createBusiness(name:String,type:String,currency:String,branchName:String){
   val u=curUser()?:return; val code="MY-"+(1000..9999).random().toString()
   val biz=Business(name=name,type=type,ownerId=u.id,code=code,currency=currency)
   val branch=Branch(businessId=biz.id,name=branchName.ifBlank{"الفرع الرئيسي"},manager=u.name)
   val cats=listOf("مواد غذائية","مشروبات","منظفات","إلكترونيات","عام").map{CategoryItem(businessId=biz.id,name=it)}
   val emp=Employee(businessId=biz.id,name=u.name,phone=u.phone,role="المالك",branchName=branch.name,permissions=ALL_PERMISSIONS)
   update{d-> d.copy(businesses=d.businesses+biz,branches=d.branches+branch,categories=d.categories+cats,employees=d.employees+emp,currentBusinessId=biz.id,currentBranchId=branch.id,settings=d.settings.copy(currency=currency),audits=audit(d,"إنشاء نشاط",name),notifications=notify(d.copy(currentBusinessId=biz.id),"مرحباً بك في مِعيار","تم إنشاء نشاطك «$name» بنجاح. رمز الانضمام للموظفين: $code","نظام"))}
   showToast("تم إنشاء النشاط التجاري بنجاح")
 }
 fun switchBusiness(bizId:String){ update{d-> val br=d.branches.find{it.businessId==bizId}; d.copy(currentBusinessId=bizId,currentBranchId=br?.id?:"")} }
 fun addBranch(name:String,manager:String,address:String){ val b=Branch(businessId=bid(),name=name,manager=manager,address=address); update{d->d.copy(branches=d.branches+b,audits=audit(d,"إضافة فرع",name))}; showToast("تمت إضافة الفرع") }
 fun switchBranch(id:String){ update{it.copy(currentBranchId=id)} }
 fun requestJoin(code:String,name:String,phone:String,role:String,onResult:(String?)->Unit){
   val d=_db.value?:return; val biz=d.businesses.find{it.code.equals(code.trim(),true)}
   if(biz==null){onResult("رمز النشاط غير صحيح. اطلبه من مدير النشاط");return}
   save(d.copy(joinRequests=d.joinRequests+JoinRequest(businessId=biz.id,businessCode=code,name=name,phone=phone,requestedRole=role),notifications=d.notifications+AppNotification(businessId=biz.id,title="طلب انضمام جديد",body="$name يطلب الانضمام بدور $role",type="موظفون")))
   onResult(null)
 }

 fun ensureDemo(){
   val d=_db.value?:return
   val existing=d.users.find{it.email=="demo@miyar.app"}
   if(existing!=null){ login("demo@miyar.app","123456"){}; return }
   val salt=newSalt(); val u=User(name="م. مجد الماعطي",phone="770000001",email="demo@miyar.app",salt=salt,passwordHash=hashPassword("123456",salt))
   val biz=Business(name="أسواق المِعيار المركزية",type="تجارة مواد غذائية",ownerId=u.id,code="MY-2026",currency="ر.ي")
   val br1=Branch(businessId=biz.id,name="الفرع الرئيسي — حدة",manager=u.name,address="صنعاء، حدة")
   val br2=Branch(businessId=biz.id,name="فرع الحصبة",manager="أحمد الحداد",address="صنعاء، الحصبة")
   val cats=listOf("مواد غذائية","مشروبات","منظفات","بهارات وحبوب","عام").map{CategoryItem(businessId=biz.id,name=it)}
   val sup1=Supplier(businessId=biz.id,name="شركة اليمن للتجارة",phone="771234567",balance=45000.0,address="صنعاء")
   val sup2=Supplier(businessId=biz.id,name="مؤسسة النور للمواد الغذائية",phone="772345678",balance=12000.0)
   fun P(n:String,cat:String,buy:Double,sell:Double,q:Int,min:Int,unit:String,img:String,bar:String,exp:String="2027/06/01")=Product(businessId=biz.id,name=n,category=cat,purchasePrice=buy,salePrice=sell,quantity=q,minStock=min,unit=unit,imageName=img,barcode=bar,expiryDate=exp,supplierName=sup1.name,description="منتج أصلي عالي الجودة")
   val prods=listOf(
     P("أرز بسمتي هندي 10 كجم","مواد غذائية",8500.0,10200.0,34,10,"كيس","prod_rice","629110345001"),
     P("زيت نباتي 1.5 لتر","مواد غذائية",1100.0,1350.0,58,15,"علبة","prod_oil","629110345002"),
     P("سكر أبيض 5 كجم","مواد غذائية",2100.0,2500.0,7,10,"كيس","prod_sugar","629110345003"),
     P("تمر سكري فاخر 1 كجم","بهارات وحبوب",1800.0,2400.0,22,8,"علبة","prod_dates","629110345004"),
     P("بن يمني مطحون 500ج","بهارات وحبوب",3200.0,4100.0,16,6,"علبة","prod_coffee","629110345005"),
     P("حليب مجفف كامل 900ج","مواد غذائية",2900.0,3500.0,3,8,"علبة","prod_milk","629110345006","2026/12/15"),
     P("دقيق أبيض 25 كجم","مواد غذائية",6800.0,7600.0,19,5,"كيس","","629110345007"),
     P("شاي أحمر 400ج","مشروبات",950.0,1200.0,41,10,"علبة","","629110345008"),
     P("منظف غسيل 3 كجم","منظفات",2400.0,2950.0,12,6,"علبة","","629110345009"),
     P("عصير مانجو 1 لتر","مشروبات",420.0,550.0,64,20,"علبة","","629110345010")
   )
   val cust=listOf(Customer(businessId=biz.id,name="أحمد محمد الحداد",phone="773111222",balance=18500.0),Customer(businessId=biz.id,name="محمد علي الصالحي",phone="774222333",balance=0.0),Customer(businessId=biz.id,name="خالد سعيد العمري",phone="775333444",balance=7200.0),Customer(businessId=biz.id,name="سارة عبدالله",phone="776444555",balance=0.0))
   val nowMs=now()
   fun mkSale(num:Int,daysAgo:Int,c:Customer?,items:List<LineItem>,paidRatio:Double):Sale{ val sub=items.sumOf{it.price*it.qty}; val paid=sub*paidRatio; return Sale(businessId=biz.id,branchId=br1.id,number="INV-100$num",customerId=c?.id?:"",customerName=c?.name?:"عميل نقدي",items=items,subtotal=sub,total=sub,paid=paid,remaining=sub-paid,paymentType=if(paidRatio>=1.0)"نقداً" else "آجل جزئي",date=nowMs-daysAgo*86400000L-(num*3600000L),userName=u.name)}
   val sales=listOf(
     mkSale(1,6,cust[1],listOf(LineItem(prods[0].id,prods[0].name,1,prods[0].salePrice,prods[0].purchasePrice),LineItem(prods[1].id,prods[1].name,2,prods[1].salePrice,prods[1].purchasePrice)),1.0),
     mkSale(2,5,cust[0],listOf(LineItem(prods[3].id,prods[3].name,3,prods[3].salePrice,prods[3].purchasePrice)),0.4),
     mkSale(3,4,null,listOf(LineItem(prods[7].id,prods[7].name,4,prods[7].salePrice,prods[7].purchasePrice),LineItem(prods[9].id,prods[9].name,6,prods[9].salePrice,prods[9].purchasePrice)),1.0),
     mkSale(4,3,cust[2],listOf(LineItem(prods[4].id,prods[4].name,2,prods[4].salePrice,prods[4].purchasePrice)),0.5),
     mkSale(5,2,cust[3],listOf(LineItem(prods[1].id,prods[1].name,3,prods[1].salePrice,prods[1].purchasePrice),LineItem(prods[2].id,prods[2].name,1,prods[2].salePrice,prods[2].purchasePrice)),1.0),
     mkSale(6,1,null,listOf(LineItem(prods[6].id,prods[6].name,1,prods[6].salePrice,prods[6].purchasePrice)),1.0),
     mkSale(7,0,cust[0],listOf(LineItem(prods[0].id,prods[0].name,2,prods[0].salePrice,prods[0].purchasePrice)),1.0),
     mkSale(8,0,null,listOf(LineItem(prods[9].id,prods[9].name,8,prods[9].salePrice,prods[9].purchasePrice),LineItem(prods[7].id,prods[7].name,2,prods[7].salePrice,prods[7].purchasePrice)),1.0)
   )
   val expenses=listOf(Expense(businessId=biz.id,category="إيجار",title="إيجار المحل الشهري",amount=80000.0,date=nowMs-86400000L*3,userName=u.name),Expense(businessId=biz.id,category="كهرباء",title="فاتورة كهرباء",amount=12500.0,date=nowMs-86400000L*1,userName=u.name),Expense(businessId=biz.id,category="نقل",title="نقل بضاعة من المخزن",amount=6000.0,date=nowMs-3600000L*5,userName=u.name),Expense(businessId=biz.id,category="وقود",title="وقود المولد",amount=9000.0,date=nowMs-86400000L*2,userName=u.name))
   val cash=sales.map{CashTxn(businessId=biz.id,type="بيع ${it.number}",amount=it.paid,date=it.date,userName=u.name)} + expenses.map{CashTxn(businessId=biz.id,type="مصروف ${it.category}",amount=-it.amount,date=it.date,userName=u.name)} + CashTxn(businessId=biz.id,type="رأس مال افتتاحي",amount=200000.0,date=nowMs-86400000L*7,userName=u.name)
   val emps=listOf(Employee(businessId=biz.id,name=u.name,phone=u.phone,role="المالك",branchName=br1.name,permissions=ALL_PERMISSIONS),Employee(businessId=biz.id,name="أحمد الحداد",phone="771000111",role="مدير الفرع",branchName=br2.name,permissions=rolePermissions("مدير الفرع")),Employee(businessId=biz.id,name="يوسف الشيباني",phone="772000222",role="الكاشير",branchName=br1.name,permissions=rolePermissions("الكاشير")),Employee(businessId=biz.id,name="منى الحسني",phone="773000333",role="المحاسب",branchName=br1.name,permissions=rolePermissions("المحاسب")),Employee(businessId=biz.id,name="سامي المطري",phone="774000444",role="أمين المخزن",branchName=br1.name,permissions=rolePermissions("أمين المخزن")))
   val pur=Purchase(businessId=biz.id,branchId=br1.id,number="PUR-501",supplierId=sup1.id,supplierName=sup1.name,items=listOf(LineItem(prods[0].id,prods[0].name,20,8500.0,8500.0)),subtotal=170000.0,total=170000.0,paid=125000.0,remaining=45000.0,date=nowMs-86400000L*4,userName=u.name)
   val moves=listOf(StockMovement(businessId=biz.id,productId=prods[0].id,productName=prods[0].name,delta=20,type="شراء",reason="فاتورة PUR-501",userName=u.name,date=nowMs-86400000L*4,before=16,after=36,branchName=br1.name),StockMovement(businessId=biz.id,productId=prods[5].id,productName=prods[5].name,delta=-2,type="تلف",reason="انتهاء وشيك — سحب من الرف",userName="سامي المطري",date=nowMs-86400000L,before=5,after=3,branchName=br1.name))
   val notifs=listOf(AppNotification(businessId=biz.id,title="تنبيه انخفاض مخزون",body="حليب مجفف كامل 900ج وصل إلى 3 فقط (الحد الأدنى 8)",type="مخزون"),AppNotification(businessId=biz.id,title="قرب انتهاء صلاحية",body="حليب مجفف كامل 900ج ينتهي في 2026/12/15",type="صلاحية"),AppNotification(businessId=biz.id,title="طلب انضمام جديد",body="عمر فاروق يطلب الانضمام كاشير",type="موظفون"))
   val newDb=d.copy(users=d.users+u,businesses=d.businesses+biz,branches=d.branches+br1+br2,categories=d.categories+cats,products=d.products+prods,customers=d.customers+cust,suppliers=d.suppliers+sup1+sup2,sales=d.sales+sales,purchases=d.purchases+pur,expenses=d.expenses+expenses,cashTxns=d.cashTxns+cash,employees=d.employees+emps,movements=d.movements+moves,notifications=d.notifications+notifs,joinRequests=d.joinRequests+JoinRequest(businessId=biz.id,businessCode=biz.code,name="عمر فاروق",phone="775999888",requestedRole="الكاشير"),shifts=d.shifts+Shift(businessId=biz.id,openingCash=50000.0,expectedCash=50000.0,userName="يوسف الشيباني"),sessionUserId=u.id,currentBusinessId=biz.id,currentBranchId=br1.id)
   save(newDb); touch(); showToast("مرحباً بك في الحساب التجريبي لأسواق المِعيار")
 }

 // ---- PRODUCTS ----
 fun bizProducts():List<Product> = _db.value?.products?.filter{it.businessId==bid()}?:emptyList()
 fun bizSales():List<Sale> = _db.value?.sales?.filter{it.businessId==bid()}?.sortedByDescending{it.date}?:emptyList()
 fun bizCustomers()= _db.value?.customers?.filter{it.businessId==bid()}?:emptyList()
 fun bizSuppliers()= _db.value?.suppliers?.filter{it.businessId==bid()}?:emptyList()
 fun saveProduct(p:Product,isNew:Boolean){
   update{d->
     val old=d.products.find{it.id==p.id}
     var moves=d.movements
     if(old!=null && old.quantity!=p.quantity){ moves=moves+StockMovement(businessId=bid(),productId=p.id,productName=p.name,delta=p.quantity-old.quantity,type="تسوية",reason="تعديل منتج",userName=curUser()?.name?:"",before=old.quantity,after=p.quantity,branchName=curBranch()?.name?:"") }
     if(isNew && p.quantity>0){ moves=moves+StockMovement(businessId=bid(),productId=p.id,productName=p.name,delta=p.quantity,type="رصيد افتتاحي",reason="إضافة منتج جديد",userName=curUser()?.name?:"",before=0,after=p.quantity,branchName=curBranch()?.name?:"") }
     val prods= if(isNew) d.products+p else d.products.map{if(it.id==p.id)p else it}
     d.copy(products=prods,movements=moves,audits=audit(d,if(isNew)"إضافة منتج" else "تعديل منتج",p.name))
   }; showToast(if(isNew)"تمت إضافة المنتج بنجاح" else "تم حفظ تعديلات المنتج")
 }
 fun toggleProduct(id:String){ update{d->d.copy(products=d.products.map{if(it.id==id) it.copy(active=!it.active) else it})} }
 fun deleteProduct(id:String){ if(!hasPerm("حذف المنتجات")){showToast("ليست لديك صلاحية حذف المنتجات");return}; update{d->d.copy(products=d.products.filter{it.id!=id},audits=audit(d,"حذف منتج",id))}; showToast("تم حذف المنتج") }
 fun adjustStock(productId:String,delta:Int,type:String,reason:String){
   update{d-> val p=d.products.find{it.id==productId}?:return@update d; val after=(p.quantity+delta).coerceAtLeast(0)
     var nots=d.notifications; if(after<=p.minStock) nots=notify(d.copy(notifications=nots),"تنبيه انخفاض مخزون","${p.name} وصل إلى $after (الحد الأدنى ${p.minStock})","مخزون")
     d.copy(products=d.products.map{if(it.id==productId) it.copy(quantity=after) else it},movements=d.movements+StockMovement(businessId=bid(),productId=productId,productName=p.name,delta=delta,type=type,reason=reason,userName=curUser()?.name?:"",before=p.quantity,after=after,branchName=curBranch()?.name?:""),notifications=nots,audits=audit(d,"حركة مخزون $type","${p.name} $delta"))
   }; showToast("تم تسجيل حركة المخزون")
 }
 fun addCategory(name:String){ update{d->d.copy(categories=d.categories+CategoryItem(businessId=bid(),name=name))} }
 fun deleteCategory(id:String){ update{d->d.copy(categories=d.categories.filter{it.id!=id})} }
 fun createStocktake(title:String,counts:Map<String,Int>){
   var discrepancies=0
   update{d-> var prods=d.products; var moves=d.movements
     counts.forEach{(pid,counted)-> val p=prods.find{it.id==pid}; if(p!=null && p.quantity!=counted){ discrepancies++; moves=moves+StockMovement(businessId=bid(),productId=pid,productName=p.name,delta=counted-p.quantity,type="جرد",reason=title,userName=curUser()?.name?:"",before=p.quantity,after=counted,branchName=curBranch()?.name?:""); prods=prods.map{if(it.id==pid) it.copy(quantity=counted) else it} } }
     d.copy(products=prods,movements=moves,stocktakes=d.stocktakes+Stocktake(businessId=bid(),title=title,items=counts.size,discrepancies=discrepancies),audits=audit(d,"جرد مخزون",title))
   }; showToast("تم اعتماد الجرد: $discrepancies فروقات تمت تسويتها")
 }

 // ---- POS ----
 fun addToCart(p:Product){ val cur=cart.value.toMutableList(); val idx=cur.indexOfFirst{it.productId==p.id}; if(idx>=0){ if(cur[idx].qty>=p.quantity){showToast("لا توجد كمية كافية في المخزون");return}; cur[idx]=cur[idx].copy(qty=cur[idx].qty+1)} else { if(p.quantity<=0){showToast("المنتج غير متوفر في المخزون");return}; cur.add(LineItem(p.id,p.name,1,p.salePrice,p.purchasePrice))}; cart.value=cur }
 fun setCartQty(pid:String,qty:Int){ cart.value= if(qty<=0) cart.value.filter{it.productId!=pid} else cart.value.map{if(it.productId==pid) it.copy(qty=qty) else it} }
 fun clearCart(){cart.value=emptyList()}
 fun checkout(customer:Customer?,discount:Double,paid:Double,paymentType:String,onDone:(Sale?)->Unit){
   val items=cart.value; if(items.isEmpty()){onDone(null);return}
   val sub=items.sumOf{it.price*it.qty}; val total=(sub-discount).coerceAtLeast(0.0); val paidC=paid.coerceIn(0.0,total); val remaining=total-paidC
   var created:Sale?=null
   update{d->
     // validate stock
     for(it in items){ val p=d.products.find{x->x.id==it.productId}; if(p==null||p.quantity<it.qty){ showToast("كمية غير كافية: ${it.productName}"); return@update d } }
     val number="INV-"+(1000 + d.sales.count{it.businessId==bid()}+1)
     val sale=Sale(businessId=bid(),branchId=d.currentBranchId,number=number,customerId=customer?.id?:"",customerName=customer?.name?:"عميل نقدي",items=items,subtotal=sub,discount=discount,total=total,paid=paidC,remaining=remaining,paymentType=paymentType,userName=curUser()?.name?:"")
     created=sale
     var prods=d.products; var moves=d.movements; var nots=d.notifications
     items.forEach{ li-> val p=prods.find{it.id==li.productId}!!; val after=p.quantity-li.qty; prods=prods.map{if(it.id==p.id) it.copy(quantity=after) else it}; moves=moves+StockMovement(businessId=bid(),productId=p.id,productName=p.name,delta=-li.qty,type="بيع",reason="فاتورة $number",userName=curUser()?.name?:"",before=p.quantity,after=after,branchName=curBranch()?.name?:""); if(after<=p.minStock) nots=nots+AppNotification(businessId=bid(),title="انخفاض مخزون",body="${p.name}: تبقى $after فقط",type="مخزون") }
     var custs=d.customers; if(customer!=null && remaining>0) custs=custs.map{if(it.id==customer.id) it.copy(balance=it.balance+remaining) else it}
     var cash=d.cashTxns; if(paidC>0) cash=cash+CashTxn(businessId=bid(),type="بيع $number",amount=paidC,userName=curUser()?.name?:"")
     d.copy(sales=d.sales+sale,products=prods,movements=moves,customers=custs,cashTxns=cash,notifications=nots,audits=audit(d,"بيع","$number بمبلغ ${fmtMoney(total)}"))
   }
   if(created!=null){ cart.value=emptyList(); showToast("تم اعتماد البيع ${created!!.number} بنجاح") }
   onDone(created)
 }
 fun returnSale(saleId:String){
   if(!hasPerm("إلغاء الفواتير") && curBusiness()?.ownerId!=curUser()?.id){showToast("ليست لديك صلاحية الإلغاء/المرتجع"); /* owner passes above */}
   update{d-> val s=d.sales.find{it.id==saleId}?:return@update d; if(s.status!="مكتملة") return@update d
     var prods=d.products; var moves=d.movements
     s.items.forEach{li-> val p=prods.find{it.id==li.productId}; if(p!=null){ prods=prods.map{if(it.id==p.id) it.copy(quantity=p.quantity+li.qty) else it}; moves=moves+StockMovement(businessId=bid(),productId=p.id,productName=p.name,delta=li.qty,type="مرتجع بيع",reason="إرجاع ${s.number}",userName=curUser()?.name?:"",before=p.quantity,after=p.quantity+li.qty,branchName=curBranch()?.name?:"") } }
     var custs=d.customers; if(s.customerId.isNotBlank()&&s.remaining>0) custs=custs.map{if(it.id==s.customerId) it.copy(balance=(it.balance-s.remaining).coerceAtLeast(0.0)) else it}
     var cash=d.cashTxns; if(s.paid>0) cash=cash+CashTxn(businessId=bid(),type="مرتجع ${s.number}",amount=-s.paid,userName=curUser()?.name?:"")
     d.copy(sales=d.sales.map{if(it.id==saleId) it.copy(status="مرتجعة") else it},products=prods,movements=moves,customers=custs,cashTxns=cash,audits=audit(d,"مرتجع بيع",s.number))
   }; showToast("تم تنفيذ المرتجع واستعادة المخزون والصندوق")
 }

 // ---- PURCHASES ----
 fun addToPurchaseCart(p:Product){ val cur=purchaseCart.value.toMutableList(); val i=cur.indexOfFirst{it.productId==p.id}; if(i>=0) cur[i]=cur[i].copy(qty=cur[i].qty+1) else cur.add(LineItem(p.id,p.name,1,p.purchasePrice,p.purchasePrice)); purchaseCart.value=cur }
 fun setPurchaseQty(pid:String,qty:Int){ purchaseCart.value=if(qty<=0) purchaseCart.value.filter{it.productId!=pid} else purchaseCart.value.map{if(it.productId==pid) it.copy(qty=qty) else it} }
 fun checkoutPurchase(supplier:Supplier?,discount:Double,paid:Double,onDone:()->Unit){
   val items=purchaseCart.value; if(items.isEmpty()||supplier==null){showToast("اختر مورداً وأضف منتجات");return}
   val sub=items.sumOf{it.price*it.qty}; val total=(sub-discount).coerceAtLeast(0.0); val rem=total-paid.coerceIn(0.0,total)
   update{d-> val number="PUR-"+(500+d.purchases.count{it.businessId==bid()}+1)
     val pur=Purchase(businessId=bid(),branchId=d.currentBranchId,number=number,supplierId=supplier.id,supplierName=supplier.name,items=items,subtotal=sub,discount=discount,total=total,paid=paid.coerceIn(0.0,total),remaining=rem,userName=curUser()?.name?:"")
     var prods=d.products; var moves=d.movements
     items.forEach{li-> val p=prods.find{it.id==li.productId}; if(p!=null){ prods=prods.map{if(it.id==p.id) it.copy(quantity=p.quantity+li.qty,purchasePrice=li.price) else it}; moves=moves+StockMovement(businessId=bid(),productId=p.id,productName=p.name,delta=li.qty,type="شراء",reason="فاتورة $number",userName=curUser()?.name?:"",before=p.quantity,after=p.quantity+li.qty,branchName=curBranch()?.name?:"") } }
     var sups=d.suppliers; if(rem>0) sups=sups.map{if(it.id==supplier.id) it.copy(balance=it.balance+rem) else it}
     var cash=d.cashTxns; if(paid>0) cash=cash+CashTxn(businessId=bid(),type="شراء $number",amount=-paid.coerceIn(0.0,total),userName=curUser()?.name?:"")
     d.copy(purchases=d.purchases+pur,products=prods,movements=moves,suppliers=sups,cashTxns=cash,audits=audit(d,"شراء","$number ${supplier.name}"))
   }; purchaseCart.value=emptyList(); showToast("تم اعتماد فاتورة الشراء وتحديث المخزون"); onDone()
 }

 // ---- PEOPLE / FINANCE ----
 fun saveCustomer(c:Customer,isNew:Boolean){ update{d->d.copy(customers=if(isNew)d.customers+c else d.customers.map{if(it.id==c.id)c else it},audits=audit(d,"عميل",c.name))}; showToast("تم حفظ العميل") }
 fun saveSupplier(s:Supplier,isNew:Boolean){ update{d->d.copy(suppliers=if(isNew)d.suppliers+s else d.suppliers.map{if(it.id==s.id)s else it})}; showToast("تم حفظ المورد") }
 fun recordCustomerPayment(custId:String,amount:Double,note:String){ update{d-> val c=d.customers.find{it.id==custId}?:return@update d; d.copy(customers=d.customers.map{if(it.id==custId) it.copy(balance=(it.balance-amount).coerceAtLeast(0.0)) else it},payments=d.payments+Payment(businessId=bid(),personType="عميل",personId=custId,personName=c.name,amount=amount,note=note),cashTxns=d.cashTxns+CashTxn(businessId=bid(),type="دفعة عميل ${c.name}",amount=amount,userName=curUser()?.name?:""),audits=audit(d,"دفعة عميل","${c.name} ${fmtMoney(amount)}"))}; showToast("تم تسجيل دفعة العميل وتحديث الصندوق") }
 fun recordSupplierPayment(supId:String,amount:Double,note:String){ update{d-> val s=d.suppliers.find{it.id==supId}?:return@update d; d.copy(suppliers=d.suppliers.map{if(it.id==supId) it.copy(balance=(it.balance-amount).coerceAtLeast(0.0)) else it},payments=d.payments+Payment(businessId=bid(),personType="مورد",personId=supId,personName=s.name,amount=amount,note=note),cashTxns=d.cashTxns+CashTxn(businessId=bid(),type="دفعة مورد ${s.name}",amount=-amount,userName=curUser()?.name?:""),audits=audit(d,"دفعة مورد","${s.name} ${fmtMoney(amount)}"))}; showToast("تم تسجيل دفعة المورد") }
 fun addExpense(category:String,title:String,amount:Double,note:String){ update{d->d.copy(expenses=d.expenses+Expense(businessId=bid(),category=category,title=title,amount=amount,note=note,userName=curUser()?.name?:""),cashTxns=d.cashTxns+CashTxn(businessId=bid(),type="مصروف $category",amount=-amount,note=title,userName=curUser()?.name?:""),audits=audit(d,"مصروف","$title ${fmtMoney(amount)}"))}; showToast("تم تسجيل المصروف") }
 fun cashDeposit(amount:Double,note:String,isDeposit:Boolean){ val signed=if(isDeposit)amount else -amount; update{d->d.copy(cashTxns=d.cashTxns+CashTxn(businessId=bid(),type=if(isDeposit)"إيداع صندوق" else "سحب صندوق",amount=signed,note=note,userName=curUser()?.name?:""),audits=audit(d,if(isDeposit)"إيداع" else "سحب",fmtMoney(amount)))}; showToast(if(isDeposit)"تم الإيداع في الصندوق" else "تم السحب من الصندوق") }
 fun cashBalance():Double = _db.value?.cashTxns?.filter{it.businessId==bid()}?.sumOf{it.amount}?:0.0
 fun openShift(opening:Double){ update{d->d.copy(shifts=d.shifts+Shift(businessId=bid(),openingCash=opening,expectedCash=opening,userName=curUser()?.name?:""))}; showToast("تم فتح وردية جديدة") }
 fun closeShift(id:String,actual:Double){ update{d-> val sh=d.shifts.find{it.id==id}?:return@update d; val salesCash=d.cashTxns.filter{it.businessId==bid()&&it.date>=sh.openedAt}.sumOf{it.amount}; val expected=sh.openingCash+salesCash; d.copy(shifts=d.shifts.map{if(it.id==id) it.copy(status="مغلقة",closedAt=now(),actualCash=actual,expectedCash=expected) else it},audits=audit(d,"إغلاق وردية","فعلي ${fmtMoney(actual)} / متوقع ${fmtMoney(expected)}"))}; showToast("تم إغلاق الوردية ومطابقة النقدية") }

 // employees
 fun addEmployee(name:String,phone:String,role:String,branch:String){ update{d->d.copy(employees=d.employees+Employee(businessId=bid(),name=name,phone=phone,role=role,branchName=branch,permissions=rolePermissions(role)),audits=audit(d,"إضافة موظف",name))}; showToast("تمت إضافة الموظف") }
 fun toggleEmployee(id:String){ update{d->d.copy(employees=d.employees.map{if(it.id==id) it.copy(active=!it.active) else it})} }
 fun setEmployeeRole(id:String,role:String){ update{d->d.copy(employees=d.employees.map{if(it.id==id) it.copy(role=role,permissions=rolePermissions(role)) else it})} }
 fun togglePermission(empId:String,perm:String){ update{d->d.copy(employees=d.employees.map{ e-> if(e.id==empId){ val perms=if(e.permissions.contains(perm)) e.permissions-perm else e.permissions+perm; e.copy(permissions=perms)} else e},audits=audit(d,"تعديل صلاحية",perm))} }
 fun decideJoin(reqId:String,accept:Boolean){ update{d-> val req=d.joinRequests.find{it.id==reqId}?:return@update d; var emps=d.employees; if(accept) emps=emps+Employee(businessId=bid(),name=req.name,phone=req.phone,role=req.requestedRole,branchName=curBranch()?.name?:"",permissions=rolePermissions(req.requestedRole)); d.copy(joinRequests=d.joinRequests.map{if(it.id==reqId) it.copy(status=if(accept)"مقبول" else "مرفوض") else it},employees=emps,audits=audit(d,if(accept)"قبول موظف" else "رفض طلب",req.name))}; showToast(if(accept)"تم قبول الموظف وتفعيل صلاحياته" else "تم رفض الطلب") }

 fun updateSettings(s:AppSettings){ update{it.copy(settings=s)} }
 fun markNotificationsRead(){ update{d->d.copy(notifications=d.notifications.map{if(it.businessId==bid()) it.copy(read=true) else it})} }
 fun backupJson():String = _db.value?.let{json.encodeToString(it)}?:""
 fun importBackup(text:String,onResult:(String?)->Unit){ try{ val d=json.decodeFromString<MiyarDb>(text.trim()); save(d); onResult(null); showToast("تمت استعادة النسخة الاحتياطية بنجاح")}catch(e:Exception){ onResult("النسخة غير سليمة أو تالفة: ${e.message}") } }
 fun salesCsv():String{ val sb=StringBuilder("رقم الفاتورة,التاريخ,العميل,الإجمالي,المدفوع,المتبقي,الحالة\n"); bizSales().forEach{sb.append("${it.number},${fmtDate(it.date)},${it.customerName},${it.total},${it.paid},${it.remaining},${it.status}\n")}; return sb.toString() }
 fun simulateSync(){ syncState.value="جارٍ التحقق من المزامنة..."; viewModelScope.launch{ kotlinx.coroutines.delay(1200); syncState.value="محلي — Offline First ✓ آخر حفظ: ${fmtDateTime(now())} • للمزامنة السحابية يلزم إعداد Firebase (google-services.json) من المالك"; showToast("البيانات محفوظة محلياً بأمان. المزامنة السحابية تتطلب إعداد Firebase خارجياً") } }

 // ---- AI ----
 private val arabicNums=mapOf("واحد" to 1,"واحدة" to 1,"اثنين" to 2,"اثنان" to 2,"إثنين" to 2,"كيسين" to 2,"حبتين" to 2,"قطعتين" to 2,"ثلاثة" to 3,"ثلاث" to 3,"أربعة" to 4,"اربع" to 4,"خمسة" to 5,"خمس" to 5,"ستة" to 6,"سبعة" to 7,"ثمانية" to 8,"تسعة" to 9,"عشرة" to 10,"عشر" to 10,"عشرين" to 20,"عشرون" to 20,"ثلاثين" to 30,"مائة" to 100,"مئة" to 100)
 private fun extractNumbers(text:String):List<Double>{ val nums=mutableListOf<Double>(); Regex("[0-9٠-٩]+(?:[.,][0-9٠-٩]+)?").findAll(text).forEach{ val norm=it.value.map{c-> if(c in '٠'..'٩') ('0'+(c-'٠')) else c}.joinToString("").replace(",","."); norm.toDoubleOrNull()?.let{n->nums.add(n)} }; if(nums.isEmpty()){ arabicNums.forEach{(w,v)-> if(text.contains(w)) nums.add(v.toDouble()) } }; return nums }
 private fun extractQty(text:String):Int{ // prefer word numbers for qty if digits may be amount
   arabicNums.forEach{(w,v)-> if(text.contains(w)) return v }; val n=extractNumbers(text); return if(n.isNotEmpty() && n[0]<=1000) n[0].toInt() else 1 }
 private fun findProduct(text:String):Product?{ val prods=bizProducts().filter{it.active}; // longest name match tokens
   return prods.maxByOrNull{ p-> val tokens=p.name.split(" ").filter{it.length>2}; tokens.count{tok-> text.contains(tok)} }?.takeIf{ p-> p.name.split(" ").any{tok-> tok.length>2 && text.contains(tok)} } }
 private fun findCustomer(text:String):Customer? = bizCustomers().find{ c-> c.name.split(" ").any{tok-> tok.length>2 && text.contains(tok)} || text.contains(c.name) }
 private fun findSupplier(text:String):Supplier? = bizSuppliers().find{ s-> s.name.split(" ").any{tok-> tok.length>2 && text.contains(tok)} }

 fun processAi(commandRaw:String, screenContext:String="الرئيسية"):AiResult{
   val cmd=commandRaw.trim(); val cur=_db.value?.settings?.currency?:"ر.ي"
   fun result(msg:String,pending:PendingAction?=null,nav:String?=null):AiResult{
     aiMessages.value=aiMessages.value+ (true to cmd) + (false to msg); pendingAction.value=pending
     update{d->d.copy(voiceHistory=d.voiceHistory+VoiceRecord(businessId=bid(),command=cmd,response=msg,executed=false))}
     if(_db.value?.settings?.ttsEnabled==true) speaker.speak(msg.take(220),_db.value?.settings?.ttsSpeed?:1f)
     return AiResult(msg,pending,nav)
   }
   if(cmd.isBlank()) return result("لم أسمع أمراً واضحاً. جرّب: «كم مبيعات اليوم؟» أو اكتب الأمر نصياً.")
   val lower=cmd
   val numbers=extractNumbers(cmd)
   val amount=numbers.maxOrNull()?:0.0
   // Reports queries (no confirmation needed)
   if(lower.contains("مبيعات اليوم")||lower.contains("كم مبيعات")||(screenContext=="التقارير"&&lower.contains("اليوم"))){
     val s=bizSales().filter{isToday(it.date)&&it.status=="مكتملة"}; return result("إجمالي مبيعات اليوم ${fmtMoney(s.sumOf{it.total})} $cur من ${s.size} فاتورة. المدفوع منها ${fmtMoney(s.sumOf{it.paid})} $cur.",nav="reports")
   }
   if(lower.contains("رصيد الصندوق")||lower.contains("كم في الصندوق")||lower.contains("اعرض الصندوق")) return result("رصيد الصندوق الحالي ${fmtMoney(cashBalance())} $cur.",nav="cashbox")
   if(lower.contains("ديون العملاء")||lower.contains("كم ديون")){ val cs=bizCustomers(); return result("إجمالي ديون العملاء ${fmtMoney(cs.sumOf{it.balance})} $cur على ${cs.count{it.balance>0}} عميل. أكبر مديونية: ${cs.maxByOrNull{it.balance}?.let{"${it.name} (${fmtMoney(it.balance)} $cur)"}?:"لا يوجد"}",nav="customers") }
   if(lower.contains("أرباح")||lower.contains("ارباح")||lower.contains("الربح")){ val from=dayStart(6); val s=bizSales().filter{it.date>=from&&it.status=="مكتملة"}; val cogs=s.sumOf{ sale-> sale.items.sumOf{it.cost*it.qty}}; val exp=_db.value?.expenses?.filter{it.businessId==bid()&&it.date>=from}?.sumOf{it.amount}?:0.0; val profit=s.sumOf{it.total}-cogs-exp; return result("صافي أرباح آخر 7 أيام ${fmtMoney(profit)} $cur. (مبيعات ${fmtMoney(s.sumOf{it.total})} − تكلفة بضاعة ${fmtMoney(cogs)} − مصروفات ${fmtMoney(exp)})",nav="profitloss") }
   if(lower.contains("ناقصة")||lower.contains("انخفاض المخزون")||lower.contains("المنتجات الناقصة")){ val low=bizProducts().filter{it.quantity<=it.minStock}; return result(if(low.isEmpty())"لا توجد منتجات منخفضة المخزون حالياً. أحسنت!" else "يوجد ${low.size} منتج منخفض المخزون: ${low.joinToString("، "){"${it.name} (${it.quantity})"}}",nav="inventory") }
   if(lower.contains("اكثر مبيع")||lower.contains("أكثر مبيع")||lower.contains("الأكثر مبيعا")){ val map=mutableMapOf<String,Int>(); bizSales().filter{it.status=="مكتملة"}.forEach{s->s.items.forEach{map[it.productName]=(map[it.productName]?:0)+it.qty}}; val top=map.entries.sortedByDescending{it.value}.take(3); return result("الأكثر مبيعاً: ${top.joinToString("، "){"${it.key} (${it.value})"}}",nav="reports") }
   if(lower.contains("مستحقات المورد")||lower.contains("كم للموردين")) return result("إجمالي مستحقات الموردين ${fmtMoney(bizSuppliers().sumOf{it.balance})} $cur.",nav="suppliers")
   if(lower.contains("آخر فاتورة")||lower.contains("اخر فاتورة")){ val s=bizSales().firstOrNull(); return if(s==null) result("لا توجد فواتير بعد.") else result("آخر فاتورة ${s.number} للعميل ${s.customerName} بمبلغ ${fmtMoney(s.total)} $cur بتاريخ ${fmtDate(s.date)}.",nav="invoice/${s.id}") }
   if(lower.contains("افتح وردية")||lower.contains("وردية جديدة")) return result("سأفتح وردية جديدة برصيد افتتاحي يساوي رصيد الصندوق ${fmtMoney(cashBalance())} $cur. هل تؤكد؟",PendingAction("OPEN_SHIFT","فتح وردية جديدة",amount=cashBalance()))
   if(lower.contains("أغلق الوردية")||lower.contains("اغلق الوردية")||lower.contains("إغلاق الوردية")){ val sh=_db.value?.shifts?.find{it.businessId==bid()&&it.status=="مفتوحة"}; return if(sh==null) result("لا توجد وردية مفتوحة حالياً.") else result("سأغلق الوردية المفتوحة منذ ${fmtDateTime(sh.openedAt)}. راجع مبلغ المطابقة في شاشة الورديات. هل تؤكد الإغلاق بالمبلغ المتوقع؟",PendingAction("CLOSE_SHIFT","إغلاق الوردية",productId=sh.id,amount=cashBalance())) }
   if(lower.contains("أودع")||lower.contains("اودع")||lower.contains("إيداع")){ if(amount<=0) return result("كم مبلغ الإيداع؟ اذكر المبلغ مثل: أودع 10000 ريال"); return result("سأودع ${fmtMoney(amount)} $cur في الصندوق. هل تؤكد؟",PendingAction("DEPOSIT","إيداع ${fmtMoney(amount)} $cur",amount=amount)) }
   if(lower.contains("اسحب")||lower.contains("سحب")){ if(amount<=0) return result("كم مبلغ السحب؟"); return result("سأسحب ${fmtMoney(amount)} $cur من الصندوق. هل تؤكد؟",PendingAction("WITHDRAW","سحب ${fmtMoney(amount)} $cur",amount=amount)) }
   // Expense (context aware)
   val expCat=EXPENSE_CATEGORIES.find{lower.contains(it)}
   if(lower.contains("مصروف")|| (expCat!=null && (lower.contains("سجل")||screenContext=="المالية"||screenContext=="المصروفات"))){
     val cat=expCat?:"أخرى"; if(amount<=0) return result("كم مبلغ مصروف $cat؟ اذكر المبلغ بالأرقام.")
     return result("وجدت مصروف $cat بمبلغ ${fmtMoney(amount)} $cur. هل تريد تسجيله وخصمه من الصندوق؟",PendingAction("EXPENSE","مصروف $cat — ${fmtMoney(amount)} $cur",amount=amount,category=cat,name="مصروف $cat (صوتي)"))
   }
   // Payment from customer
   if(lower.contains("دفعة") && (lower.contains("عميل")||findCustomer(cmd)!=null||screenContext.contains("عميل"))){
     val c=findCustomer(cmd); if(c==null) return result("من أي عميل هذه الدفعة؟ اذكر اسم العميل."); if(amount<=0) return result("كم مبلغ دفعة ${c.name}؟ رصيده الحالي ${fmtMoney(c.balance)} $cur")
     return result("سأسجل دفعة ${fmtMoney(amount)} $cur من ${c.name} (مديونيته ${fmtMoney(c.balance)}). هل تؤكد؟",PendingAction("CUSTOMER_PAYMENT","دفعة ${c.name} — ${fmtMoney(amount)} $cur",customerId=c.id,amount=amount))
   }
   // Stock damage / dispense / add
   if(lower.contains("تالف")||lower.contains("تلف")){ val p=findProduct(cmd); if(p==null) return result("أي منتج تالف؟ اذكر اسم المنتج."); val q=extractQty(cmd); return result("سأسجل $q من «${p.name}» كتلف (المتوفر ${p.quantity}). هل تؤكد؟",PendingAction("STOCK_DAMAGE","تلف $q × ${p.name}",productId=p.id,qty=q)) }
   if(lower.contains("اصرف")||lower.contains("صرف")){ val p=findProduct(cmd); if(p==null) return result("أي منتج تريد صرفه من المخزون؟"); val q=extractQty(cmd); return result("سأصرف $q من «${p.name}». هل تؤكد؟",PendingAction("STOCK_OUT","صرف $q × ${p.name}",productId=p.id,qty=q)) }
   if((lower.contains("المخزون")&&lower.contains("أضف"))||lower.contains("اضف")&&lower.contains("قطع")){ val p=findProduct(cmd); if(p==null) return result("لأي منتج أضيف الكمية؟ اذكر اسمه."); val q=extractQty(cmd); return result("سأضيف $q إلى مخزون «${p.name}» (يصبح ${p.quantity+q}). هل تؤكد؟",PendingAction("STOCK_IN","إضافة $q × ${p.name}",productId=p.id,qty=q)) }
   if(lower.contains("ابدأ الجرد")||lower.contains("جرد")) return result("تمام، فتحت لك شاشة الجرد. عدّ الكميات الفعلية وسأقوم بالتسوية وتسجيل الفروقات موثقة.",nav="stocktake")
   // Purchase
   if(lower.contains("اشتر")||lower.contains("شراء")||lower.contains("فاتورة شراء")){ val p=findProduct(cmd); val s=findSupplier(cmd); if(p==null) return result("فتحت شاشة المشتريات. حدد المنتج والمورد والكمية لإنشاء فاتورة شراء.",nav="purchase_new"); val q=extractQty(cmd); return result("سأضيف $q × «${p.name}» بسعر شراء ${fmtMoney(p.purchasePrice)} إلى سلة المشتريات${if(s!=null)" من ${s.name}" else ""}. أكمل الاعتماد في شاشة الشراء. هل أضيفها للسلة؟",PendingAction("PURCHASE_CART","شراء $q × ${p.name}",productId=p.id,qty=q,supplierId=s?.id?:"")) }
   // Add product
   if(lower.contains("منتج جديد")||lower.contains("أضف منتج")||lower.contains("اضف منتج")){ return result("فتحت لك نموذج إضافة منتج. املأ الاسم وسعري الشراء والبيع والكمية، أو قل: اسم المنتج ... سعر الشراء ... سعر البيع ...",nav="product_add") }
   if(lower.contains("ابحث عن")||lower.contains("بحث عن")){ aiSearchQuery=cmd.substringAfter("عن").trim(); val p=findProduct(cmd); return result(if(p!=null)"وجدت: ${p.name} — سعر البيع ${fmtMoney(p.salePrice)} $cur، المتوفر ${p.quantity} ${p.unit}." else "سأبحث عن «$aiSearchQuery» في المنتجات.",nav=if(p!=null)"product_detail/${p.id}" else "products") }
   // Sale
   if(lower.contains("بع")||lower.contains("بيع")||lower.contains("بيع للعميل")||lower.contains("الى السلة")||lower.contains("إلى السلة")||screenContext=="الكاشير"){
     val p=findProduct(cmd); if(p==null) return result("لم أتعرف على المنتج. اذكر اسمه كما هو مسجل، مثل: بع كيسين أرز بسمتي")
     val q=extractQty(cmd); val c=findCustomer(cmd)
     if(p.quantity<q) return result("الكمية غير كافية: المتوفر من «${p.name}» هو ${p.quantity} فقط.")
     return result("وجدت المنتج «${p.name}»، الكمية $q × ${fmtMoney(p.salePrice)} = ${fmtMoney(p.salePrice*q)} $cur${if(c!=null)" للعميل ${c.name}" else " (عميل نقدي)"}. سأضيفه إلى سلة الكاشير — راجعه واعتمد البيع من السلة. هل أضيفه؟",PendingAction("SALE_CART","بيع $q × ${p.name}${if(c!=null)" لـ ${c.name}" else ""} — ${fmtMoney(p.salePrice*q)} $cur",productId=p.id,customerId=c?.id?:"",qty=q))
   }
   if(lower.contains("احذف آخر")||lower.contains("احذف اخر")){ if(cart.value.isNotEmpty()){ cart.value=cart.value.dropLast(1); return result("حذفت آخر منتج من السلة. تبقى ${cart.value.size} منتج.") }; return result("السلة فارغة.") }
   if(lower.contains("إجمالي الفاتورة")||lower.contains("اجمالي الفاتورة")||lower.contains("كم الإجمالي")){ val t=cart.value.sumOf{it.price*it.qty}; return result("إجمالي السلة الحالية ${fmtMoney(t)} $cur (${cart.value.size} منتج).") }
   if(lower.contains("أضف عميل")||lower.contains("عميل جديد")) return result("فتحت شاشة العملاء لإضافة عميل جديد.",nav="customers")
   if(lower.contains("أضف موظف")||lower.contains("موظف جديد")) return result("فتحت شاشة الموظفين.",nav="employees")
   if(lower.contains("طلبات الانضمام")) { val n=_db.value?.joinRequests?.count{it.businessId==bid()&&it.status=="قيد الانتظار"}?:0; return result("يوجد $n طلب انضمام قيد الانتظار.",nav="join_requests") }
   if(lower.contains("افتح")&&lower.contains("تقرير")||lower.contains("اعرض تقرير")||lower.contains("التقارير")) return result("فتحت قسم التقارير. يمكنك اختيار الفترة وتصدير CSV أو مشاركة التقرير.",nav="reports")
   // fallback clarification - ONE specific question
   return result("لم أفهم الأمر بدقة حتى لا أخمّن عملية مالية. هل تقصد: بيع منتج، تسجيل مصروف، دفعة عميل، أم عرض تقرير؟ جرّب مثالاً: «بع لأحمد كيسين أرز» أو «سجل مصروف كهرباء 3000»")
 }
 fun confirmPending():String{
   val p=pendingAction.value?:return "لا توجد عملية بانتظار التأكيد"; pendingAction.value=null
   val msg=when(p.type){
     "EXPENSE"->{ addExpense(p.category,p.name,p.amount,"عبر MIYAR AI"); "تم تسجيل المصروف وخصمه من الصندوق بنجاح." }
     "DEPOSIT"->{ cashDeposit(p.amount,"عبر MIYAR AI",true); "تم إيداع ${fmtMoney(p.amount)} في الصندوق." }
     "WITHDRAW"->{ cashDeposit(p.amount,"عبر MIYAR AI",false); "تم سحب ${fmtMoney(p.amount)} من الصندوق." }
     "CUSTOMER_PAYMENT"->{ recordCustomerPayment(p.customerId,p.amount,"عبر MIYAR AI"); "تم تسجيل الدفعة وتحديث رصيد العميل والصندوق." }
     "STOCK_DAMAGE"->{ adjustStock(p.productId,-p.qty,"تلف","عبر MIYAR AI"); "تم تسجيل التلف في حركات المخزون." }
     "STOCK_OUT"->{ adjustStock(p.productId,-p.qty,"صرف","عبر MIYAR AI"); "تم صرف الكمية وتسجيل الحركة." }
     "STOCK_IN"->{ adjustStock(p.productId,p.qty,"إضافة","عبر MIYAR AI"); "تمت إضافة الكمية إلى المخزون." }
     "SALE_CART"->{ val prod=bizProducts().find{it.id==p.productId}; if(prod!=null){ repeat(p.qty){addToCart(prod)}; aiPrefillCustomerId=p.customerId }; "تمت الإضافة إلى سلة الكاشير. راجع السلة واعتمد البيع لإصدار الفاتورة." }
     "PURCHASE_CART"->{ val prod=bizProducts().find{it.id==p.productId}; if(prod!=null) repeat(p.qty){addToPurchaseCart(prod)}; "تمت الإضافة إلى سلة المشتريات. أكمل من شاشة الشراء." }
     "OPEN_SHIFT"->{ openShift(p.amount); "تم فتح وردية جديدة." }
     "CLOSE_SHIFT"->{ closeShift(p.productId,p.amount); "تم إغلاق الوردية." }
     else->"تم التنفيذ."
   }
   aiMessages.value=aiMessages.value+(false to "✅ $msg")
   if(_db.value?.settings?.ttsEnabled==true) speaker.speak(msg,_db.value?.settings?.ttsSpeed?:1f)
   update{d-> var vh=d.voiceHistory; if(vh.isNotEmpty()) vh=vh.dropLast(1)+vh.last().copy(executed=true); d.copy(voiceHistory=vh,audits=audit(d,"MIYAR AI",p.summary))}
   return msg
 }
 fun cancelPending(){ pendingAction.value=null; aiMessages.value=aiMessages.value+(false to "تم إلغاء العملية. لم يتم تنفيذ أي تغيير.") }
 override fun onCleared(){ speaker.tts?.shutdown(); super.onCleared() }
}
