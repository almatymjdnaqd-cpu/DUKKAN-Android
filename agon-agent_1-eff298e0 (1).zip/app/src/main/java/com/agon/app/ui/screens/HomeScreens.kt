package com.agon.app.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.data.now
import com.agon.app.ui.components.*
import com.agon.app.ui.theme.Gold
import com.agon.app.ui.theme.SuccessGreen
import com.agon.app.viewmodel.*

data class QuickOp(val title:String,val icon:ImageVector,val route:String,val color:Color)

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun DashboardScreen(vm:MiyarViewModel,nav:(String)->Unit,onVoice:()->Unit){
 val db by vm.db.collectAsState(); val d=db?:return
 val biz=vm.curBusiness(); val branch=vm.curBranch(); val user=vm.curUser()
 val todaySales=d.sales.filter{it.businessId==d.currentBusinessId && isToday(it.date)&&it.status=="مكتملة"}
 val todayTotal=todaySales.sumOf{it.total}; val cogs=todaySales.sumOf{s->s.items.sumOf{it.cost*it.qty}}; val profit=todayTotal-cogs
 val low=d.products.filter{it.businessId==d.currentBusinessId&&it.active&&it.quantity<=it.minStock}
 val weekData=(6 downTo 0).map{off-> val start=dayStart(off); val end=start+86400000L; val label=when(off){0->"اليوم";1->"أمس";else->fmtDate(start).substringAfterLast("/").let{"$it"}}; label to d.sales.filter{it.businessId==d.currentBusinessId&&it.status=="مكتملة"&&it.date in start until end}.sumOf{it.total}}
 var showOps by remember{mutableStateOf(false)}
 val unread=d.notifications.count{it.businessId==d.currentBusinessId&&!it.read}
 LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{
   Spacer(Modifier.height(8.dp))
   Row(verticalAlignment=Alignment.CenterVertically){
     Box(Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Color(0xFF171D28),Color(0xFF2A2210)))),contentAlignment=Alignment.Center){Icon(Icons.Default.Scale,null,tint=Gold)}
     Spacer(Modifier.width(10.dp))
     Column(Modifier.weight(1f)){ Text(biz?.name?:"نشاطي التجاري",fontWeight=FontWeight.ExtraBold,fontSize=17.sp,maxLines=1); Text("${branch?.name?:""} • ${fmtDate(now())}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) }
     IconButton(onClick={vm.updateSettings(d.settings.copy(hideAmounts=!d.settings.hideAmounts))}){Icon(if(d.settings.hideAmounts)Icons.Default.VisibilityOff else Icons.Default.Visibility,null)}
     BadgedBox(badge={if(unread>0)Badge{Text(unread.toString())}}){ IconButton(onClick={nav("notifications")}){Icon(Icons.Default.Notifications,null)} }
     IconButton(onClick={nav("profile")}){ Box(Modifier.size(36.dp).clip(CircleShape).background(Gold.copy(alpha=0.2f)),contentAlignment=Alignment.Center){Text(user?.name?.take(1)?:"م",fontWeight=FontWeight.Bold,color=Gold)} }
   }
   val firstName=user?.name?.trim()?.split(" ")?.lastOrNull().orEmpty()
   Text("أهلاً $firstName 👋",fontSize=13.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
  }
  item{
   Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.Transparent)){
    Box(Modifier.background(Brush.linearGradient(listOf(Color(0xFF171D28),Color(0xFF2C2410))))){
     Column(Modifier.padding(18.dp)){
      Row{ Column(Modifier.weight(1f)){ Text("مبيعات اليوم",color=Color.White.copy(alpha=0.65f),fontSize=12.sp); Text(if(d.settings.hideAmounts)"•••••" else "${fmtMoney(todayTotal)} ${d.settings.currency}",color=Gold,fontWeight=FontWeight.ExtraBold,fontSize=26.sp); Text("${todaySales.size} فاتورة • ربح تقريبي ${if(d.settings.hideAmounts)"•••" else fmtMoney(profit)}",color=Color.White.copy(alpha=0.7f),fontSize=12.sp)}; Icon(Icons.Default.TrendingUp,null,tint=SuccessGreen,modifier=Modifier.size(36.dp)) }
      Spacer(Modifier.height(12.dp)); HorizontalDivider(color=Color.White.copy(alpha=0.12f)); Spacer(Modifier.height(12.dp))
      Row(horizontalArrangement=Arrangement.SpaceBetween,modifier=Modifier.fillMaxWidth()){
        Column{Text("رصيد الصندوق",color=Color.White.copy(alpha=0.6f),fontSize=11.sp); Text(if(d.settings.hideAmounts)"•••" else fmtMoney(vm.cashBalance()),color=Color.White,fontWeight=FontWeight.Bold)}
        Column{Text("ديون عملاء",color=Color.White.copy(alpha=0.6f),fontSize=11.sp); Text(if(d.settings.hideAmounts)"•••" else fmtMoney(vm.bizCustomers().sumOf{it.balance}),color=Color.White,fontWeight=FontWeight.Bold)}
        Column{Text("منتجات",color=Color.White.copy(alpha=0.6f),fontSize=11.sp); Text("${vm.bizProducts().count{it.active}}",color=Color.White,fontWeight=FontWeight.Bold)}
        Column{Text("تنبيهات مخزون",color=Color.White.copy(alpha=0.6f),fontSize=11.sp); Text("${low.size}",color=if(low.isEmpty())SuccessGreen else Color(0xFFFF8A80),fontWeight=FontWeight.Bold)}
      }
     }
    }
   }
  }
  item{
   Row(horizontalArrangement=Arrangement.spacedBy(10.dp),modifier=Modifier.fillMaxWidth()){
     GoldButton("عملية جديدة",Icons.Default.Add,Modifier.weight(1f)){showOps=true}
     OutlinedButton(onClick=onVoice,modifier=Modifier.weight(1f).height(50.dp),shape=RoundedCornerShape(14.dp)){Icon(Icons.Default.Mic,null,tint=Gold); Spacer(Modifier.width(6.dp)); Text("MIYAR AI صوتي",fontWeight=FontWeight.Bold)}
   }
  }
  item{ SectionTitle("اختصارات سريعة") }
  item{
   val shorts=listOf(Triple("الكاشير",Icons.Default.PointOfSale,"pos"),Triple("المنتجات",Icons.Default.Inventory2,"products"),Triple("العملاء",Icons.Default.People,"customers"),Triple("التقارير",Icons.Default.BarChart,"reports"),Triple("المخزون",Icons.Default.Warehouse,"inventory"),Triple("المشتريات",Icons.Default.ShoppingCart,"purchases"),Triple("المصروفات",Icons.Default.ReceiptLong,"expenses"),Triple("المساعد الذكي",Icons.Default.AutoAwesome,"ai"))
   Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
    shorts.chunked(4).forEach{ row ->
     Row(horizontalArrangement=Arrangement.spacedBy(10.dp),modifier=Modifier.fillMaxWidth()){
      row.forEach{ (t,ic,r) ->
       Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.weight(1f).clickable{nav(r)}){
        Box(Modifier.size(54.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant),contentAlignment=Alignment.Center){Icon(ic,null,tint=Gold)}
        Spacer(Modifier.height(4.dp)); Text(t,fontSize=11.sp)
       }
      }
     }
    }
   }
  }
  item{
   Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){ Column(Modifier.padding(16.dp)){ SectionTitle("مبيعات آخر 7 أيام","التقارير"){nav("reports")}; BarChart(weekData) } }
  }
  if(low.isNotEmpty()){
   item{ SectionTitle("تنبيهات المخزون","عرض الكل"){nav("inventory")} }
   items(low.take(3)){p-> Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.error.copy(alpha=0.08f)),modifier=Modifier.fillMaxWidth().clickable{nav("product_detail/${p.id}")}){ Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){ Icon(Icons.Default.Warning,null,tint=MaterialTheme.colorScheme.error); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Bold,fontSize=14.sp); Text("تبقى ${p.quantity} ${p.unit} — الحد الأدنى ${p.minStock}",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}; AlertChip("منخفض") } } }
  }
  item{ SectionTitle("آخر النشاطات","سجل التدقيق"){nav("reports")} }
  val recent=d.audits.filter{it.businessId==d.currentBusinessId}.takeLast(5).reversed()
  if(recent.isEmpty()) item{ Text("لا توجد نشاطات بعد — ابدأ بأول عملية بيع من الكاشير.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) }
  items(recent){a-> Row(Modifier.fillMaxWidth().padding(vertical=4.dp),verticalAlignment=Alignment.CenterVertically){ Box(Modifier.size(8.dp).clip(CircleShape).background(Gold)); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)){Text("${a.action}: ${a.details}",fontSize=13.sp); Text("${a.userName} • ${fmtDateTime(a.date)}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)} } }
  item{ Spacer(Modifier.height(90.dp)) }
 }
 if(showOps){
   val ops=listOf(QuickOp("بيع جديد",Icons.Default.PointOfSale,"pos",SuccessGreen),QuickOp("شراء جديد",Icons.Default.ShoppingCart,"purchase_new",Color(0xFF5B8DEF)),QuickOp("إضافة منتج",Icons.Default.AddBox,"product_add",Gold),QuickOp("تسجيل مصروف",Icons.Default.ReceiptLong,"expenses",Color(0xFFD94848)),QuickOp("تسجيل دفعة عميل",Icons.Default.Payments,"customers",SuccessGreen),QuickOp("إضافة عميل",Icons.Default.PersonAdd,"customers",Gold),QuickOp("إضافة مورد",Icons.Default.LocalShipping,"suppliers",Color(0xFF5B8DEF)),QuickOp("إضافة موظف",Icons.Default.GroupAdd,"employees",Gold),QuickOp("حركة مخزون",Icons.Default.SwapHoriz,"inventory",Color(0xFF9B7EDE)),QuickOp("جرد المخزون",Icons.Default.FactCheck,"stocktake",Color(0xFF9B7EDE)))
   ModalBottomSheet(onDismissRequest={showOps=false}){ Column(Modifier.padding(18.dp)){ Text("عملية جديدة",fontWeight=FontWeight.ExtraBold,fontSize=19.sp); Spacer(Modifier.height(14.dp)); ops.chunked(2).forEach{row-> Row(horizontalArrangement=Arrangement.spacedBy(10.dp),modifier=Modifier.fillMaxWidth().padding(bottom=10.dp)){ row.forEach{op-> Card(modifier=Modifier.weight(1f).clickable{showOps=false;nav(op.route)},shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant)){ Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Icon(op.icon,null,tint=op.color); Spacer(Modifier.width(8.dp)); Text(op.title,fontWeight=FontWeight.Bold,fontSize=13.sp)}} }; if(row.size==1)Spacer(Modifier.weight(1f)) } }; Spacer(Modifier.height(20.dp)) } }
 }
}
@Composable fun MoreScreen(vm:MiyarViewModel,nav:(String)->Unit){
 val db by vm.db.collectAsState(); val biz=vm.curBusiness()
 val items=listOf(
  Triple("المخزون والجرد",Icons.Default.Warehouse,"inventory"),Triple("المشتريات",Icons.Default.ShoppingCart,"purchases"),Triple("العملاء والديون",Icons.Default.People,"customers"),Triple("الموردون",Icons.Default.LocalShipping,"suppliers"),Triple("التقارير والأرباح",Icons.Default.BarChart,"reports"),Triple("الموظفون",Icons.Default.Badge,"employees"),Triple("طلبات الانضمام",Icons.Default.GroupAdd,"join_requests"),Triple("الصلاحيات",Icons.Default.AdminPanelSettings,"permissions"),Triple("الفروع",Icons.Default.Business,"branches"),Triple("الأنشطة التجارية",Icons.Default.Store,"businesses"),Triple("المساعد الذكي MIYAR AI",Icons.Default.AutoAwesome,"ai"),Triple("سجل الأوامر الصوتية",Icons.Default.History,"voice_history"),Triple("الإشعارات",Icons.Default.Notifications,"notifications"),Triple("النسخ الاحتياطي",Icons.Default.Backup,"backup"),Triple("الإعدادات",Icons.Default.Settings,"settings"),Triple("الملف الشخصي",Icons.Default.AccountCircle,"profile"),Triple("حول التطبيق",Icons.Default.Info,"about"))
 LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
  item{ Spacer(Modifier.height(10.dp)); Text("المزيد",fontWeight=FontWeight.ExtraBold,fontSize=24.sp); Text("${biz?.name?:""} • رمز انضمام الموظفين: ${biz?.code?:""}",fontSize=12.sp,color=Gold); Spacer(Modifier.height(8.dp)) }
  items(items){(t,ic,r)-> Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth().clickable{nav(r)}){ Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){ Box(Modifier.size(40.dp).clip(RoundedCornerShape(11.dp)).background(Gold.copy(alpha=0.13f)),contentAlignment=Alignment.Center){Icon(ic,null,tint=Gold)}; Spacer(Modifier.width(12.dp)); Text(t,fontWeight=FontWeight.Bold,fontSize=15.sp,modifier=Modifier.weight(1f)); Icon(Icons.Default.ChevronLeft,null,tint=MaterialTheme.colorScheme.onSurfaceVariant) } } }
  item{ Spacer(Modifier.height(10.dp)); OutlinedButton(onClick={vm.locked.value=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Lock,null); Spacer(Modifier.width(8.dp)); Text("قفل التطبيق الآن")}; Spacer(Modifier.height(8.dp)); Button(onClick={vm.logout()},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=MaterialTheme.colorScheme.error)){Icon(Icons.Default.Logout,null); Spacer(Modifier.width(8.dp)); Text("تسجيل الخروج")}; Spacer(Modifier.height(90.dp)) }
 }
}
@Composable fun NotificationsScreen(vm:MiyarViewModel,back:()->Unit){
 val db by vm.db.collectAsState(); val list=db?.notifications?.filter{it.businessId==db?.currentBusinessId}?.reversed()?:emptyList()
 LaunchedEffect(Unit){ kotlinx.coroutines.delay(600); vm.markNotificationsRead() }
 Column(Modifier.fillMaxSize()){ MiyarTopBar("الإشعارات والتنبيهات",back)
  if(list.isEmpty()) EmptyState(Icons.Default.NotificationsNone,"لا إشعارات","ستظهر هنا تنبيهات المخزون والصلاحية وطلبات الانضمام والمزامنة.")
  else LazyColumn(Modifier.padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){ items(list){n-> Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth()){ Row(Modifier.padding(14.dp)){ Icon(when(n.type){"مخزون"->Icons.Default.Warning;"موظفون"->Icons.Default.GroupAdd;"صلاحية"->Icons.Default.EventBusy;else->Icons.Default.Notifications},null,tint=Gold); Spacer(Modifier.width(10.dp)); Column{ Text(n.title,fontWeight=FontWeight.Bold,fontSize=14.sp); Text(n.body,fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant); Text(fmtDateTime(n.date),fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)} } } }; item{Spacer(Modifier.height(80.dp))} }
 }
}
@Composable fun AboutScreen(vm:MiyarViewModel,back:()->Unit){
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())){ MiyarTopBar("حول التطبيق",back)
  Column(Modifier.padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally){
   MiyarLogo(84); Spacer(Modifier.height(14.dp))
   Text("نظام ذكي لإدارة الأنشطة التجارية والمبيعات والمخازن والمحاسبة والموظفين، يجمع الإدارة المالية والتشغيلية والمساعد الذكي في تطبيق واحد.",fontSize=13.sp,color=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.padding(horizontal=8.dp))
   Spacer(Modifier.height(20.dp))
   Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.Transparent),modifier=Modifier.fillMaxWidth()){ Box(Modifier.background(Brush.linearGradient(listOf(Color(0xFF171D28),Color(0xFF2A2210))))){ Column(Modifier.padding(20.dp).fillMaxWidth(),horizontalAlignment=Alignment.CenterHorizontally){ Icon(Icons.Default.Engineering,null,tint=Gold,modifier=Modifier.size(34.dp)); Spacer(Modifier.height(8.dp)); Text("صاحب المشروع والمطوّر",color=Color.White.copy(alpha=0.65f),fontSize=12.sp); Text("المهندس مجد الماعطي",color=Gold,fontWeight=FontWeight.ExtraBold,fontSize=22.sp); Text("Eng. Majd Al-Maati",color=Color.White.copy(alpha=0.6f),fontSize=12.sp) } } }
   Spacer(Modifier.height(16.dp))
   listOf("إصدار التطبيق" to "1.0.0","نوع التطبيق" to "Android أصلي — Kotlin + Jetpack Compose + Material 3","قاعدة البيانات" to "محلية Offline-First (DataStore) مع علاقات مترابطة","المساعد الذكي" to "MIYAR AI — صوت عربي + تأكيد قبل أي عملية مالية","الأمان" to "PBKDF2 + قفل تلقائي + سجل تدقيق + صلاحيات","خدمات تحتاج إعداداً خارجياً" to "Firebase Auth / Firestore / AI Logic وطباعة حرارية — تتطلب مفاتيح المالك (google-services.json) ولا يتم اختراعها").forEach{(k,v)-> Card(shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth().padding(bottom=8.dp)){ Column(Modifier.padding(12.dp)){Text(k,fontWeight=FontWeight.Bold,fontSize=13.sp,color=Gold); Text(v,fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}} }
   Spacer(Modifier.height(10.dp)); Text("© 2026 مِعيار MI'YAR — جميع الحقوق محفوظة للمهندس مجد الماعطي. سياسة الخصوصية وشروط الاستخدام تُنشر من المالك عند الإطلاق الرسمي.",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(80.dp))
  }
 }
}
@Composable fun SettingsScreen2(vm:MiyarViewModel,back:()->Unit){
 val db by vm.db.collectAsState(); val s=db?.settings?:return
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())){ MiyarTopBar("الإعدادات",back)
  Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
   Text("المظهر والعملة",fontWeight=FontWeight.Bold,color=Gold)
   Row(verticalAlignment=Alignment.CenterVertically){ Icon(Icons.Default.DarkMode,null,tint=Gold); Spacer(Modifier.width(10.dp)); Text("الوضع الداكن الفاخر",Modifier.weight(1f)); Switch(s.darkMode,{vm.updateSettings(s.copy(darkMode=it))}) }
   DropdownField("العملة الافتراضية",s.currency,listOf("ر.ي","ر.س","ج.م","د.ك","$","€"),{vm.updateSettings(s.copy(currency=it))})
   Row(verticalAlignment=Alignment.CenterVertically){ Icon(Icons.Default.VisibilityOff,null,tint=Gold); Spacer(Modifier.width(10.dp)); Text("إخفاء المبالغ المالية",Modifier.weight(1f)); Switch(s.hideAmounts,{vm.updateSettings(s.copy(hideAmounts=it))}) }
   HorizontalDivider(); Text("الأمان والقفل",fontWeight=FontWeight.Bold,color=Gold)
   Row(verticalAlignment=Alignment.CenterVertically){ Icon(Icons.Default.Timer,null,tint=Gold); Spacer(Modifier.width(10.dp)); Text("قفل تلقائي بعد ${s.lockSeconds} ثانية خمول",Modifier.weight(1f)); Switch(s.lockEnabled,{vm.updateSettings(s.copy(lockEnabled=it))}) }
   Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ listOf(30,60,120,300).forEach{sec-> FilterChip(selected=s.lockSeconds==sec,onClick={vm.updateSettings(s.copy(lockSeconds=sec))},label={Text("${sec}ث")}) } }
   HorizontalDivider(); Text("MIYAR AI الصوتي",fontWeight=FontWeight.Bold,color=Gold)
   Row(verticalAlignment=Alignment.CenterVertically){ Icon(Icons.Default.RecordVoiceOver,null,tint=Gold); Spacer(Modifier.width(10.dp)); Text("الرد الصوتي (TTS عربي)",Modifier.weight(1f)); Switch(s.ttsEnabled,{vm.updateSettings(s.copy(ttsEnabled=it))}) }
   Text("سرعة الصوت: ${String.format("%.1f",s.ttsSpeed)}×",fontSize=13.sp); Slider(s.ttsSpeed,{vm.updateSettings(s.copy(ttsSpeed=it))},valueRange=0.5f..1.8f,steps=12)
   HorizontalDivider(); Text("الإشعارات والمزامنة",fontWeight=FontWeight.Bold,color=Gold)
   Row(verticalAlignment=Alignment.CenterVertically){ Icon(Icons.Default.Notifications,null,tint=Gold); Spacer(Modifier.width(10.dp)); Text("تفعيل التنبيهات الداخلية",Modifier.weight(1f)); Switch(s.notificationsEnabled,{vm.updateSettings(s.copy(notificationsEnabled=it))}) }
   val sync by vm.syncState.collectAsState(); Card(shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant)){Column(Modifier.padding(12.dp)){Text(sync,fontSize=12.sp); Spacer(Modifier.height(8.dp)); OutlinedButton(onClick={vm.simulateSync()}){Icon(Icons.Default.Sync,null); Spacer(Modifier.width(6.dp)); Text("فحص حالة الحفظ/المزامنة")}}}
   Spacer(Modifier.height(80.dp))
  }
 }
}
@Composable fun ProfileScreen(vm:MiyarViewModel,back:()->Unit,nav:(String)->Unit){
 val db by vm.db.collectAsState(); val u=vm.curUser()?:return
 var name by remember(u.id){mutableStateOf(u.name)}; var phone by remember(u.id){mutableStateOf(u.phone)}; var email by remember(u.id){mutableStateOf(u.email)}
 var old by remember{mutableStateOf("")}; var newp by remember{mutableStateOf("")}; var err by remember{mutableStateOf<String?>(null)}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())){ MiyarTopBar("الملف الشخصي",back)
  Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp),horizontalAlignment=Alignment.CenterHorizontally){
   Box(Modifier.size(76.dp).clip(CircleShape).background(Gold.copy(alpha=0.18f)),contentAlignment=Alignment.Center){Text(u.name.take(1),fontSize=30.sp,fontWeight=FontWeight.ExtraBold,color=Gold)}
   Text(u.name,fontWeight=FontWeight.Bold,fontSize=18.sp); Text("${vm.curBusiness()?.name?:""} • ${if(vm.curBusiness()?.ownerId==u.id)"المالك" else "موظف"}",fontSize=12.sp,color=Gold)
   MiyarTextField(name,{name=it},"الاسم",icon=Icons.Default.Person); MiyarTextField(phone,{phone=it},"الهاتف",icon=Icons.Default.Phone); MiyarTextField(email,{email=it},"البريد",icon=Icons.Default.Email)
   GoldButton("حفظ البيانات",Icons.Default.Save,Modifier.fillMaxWidth()){vm.updateProfile(name,phone,email)}
   HorizontalDivider(Modifier.padding(vertical=8.dp)); Text("تغيير كلمة المرور",fontWeight=FontWeight.Bold,modifier=Modifier.align(Alignment.Start))
   MiyarTextField(old,{old=it},"الحالية",icon=Icons.Default.Lock,isPassword=true); MiyarTextField(newp,{newp=it},"الجديدة",icon=Icons.Default.LockOpen,isPassword=true)
   if(err!=null)Text(err!!,color=MaterialTheme.colorScheme.error,fontSize=12.sp)
   OutlinedButton(onClick={vm.changePassword(old,newp){e->err=e?:null; if(e==null) vm.showToast("تم تغيير كلمة المرور بنجاح")}},modifier=Modifier.fillMaxWidth()){Text("تغيير كلمة المرور")}
   Spacer(Modifier.height(80.dp))
  }
 }
}
@Composable fun BackupScreen(vm:MiyarViewModel,back:()->Unit){
 val ctx=LocalContext.current; var importText by remember{mutableStateOf("")}; var msg by remember{mutableStateOf<String?>(null)}; var showExport by remember{mutableStateOf(false)}
 val backup=remember{ vm.backupJson() }
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())){ MiyarTopBar("النسخ الاحتياطي والاستعادة",back)
  Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
   Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Gold.copy(alpha=0.09f))){ Column(Modifier.padding(14.dp)){ Row{Icon(Icons.Default.Shield,null,tint=Gold); Spacer(Modifier.width(8.dp)); Text("نسخة كاملة من قاعدة بيانات مِعيار",fontWeight=FontWeight.Bold)}; Text("تشمل جميع الأنشطة والمنتجات والمبيعات والمشتريات والعملاء والموظفين وسجل التدقيق. احفظها في مكان آمن. التشفير AES-256-GCM بعبارة مرور يتطلب تفعيله عند ربط خدمة التخزين السحابي — لا تستخدم كلمة ثابتة أبداً.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)} }
   GoldButton("مشاركة / تصدير النسخة الاحتياطية (JSON)",Icons.Default.Share,Modifier.fillMaxWidth()){ shareText(ctx,"نسخة مِعيار الاحتياطية",vm.backupJson()) }
   OutlinedButton(onClick={showExport=!showExport},modifier=Modifier.fillMaxWidth()){Text(if(showExport)"إخفاء نص النسخة" else "عرض نص النسخة للنسخ اليدوي")}
   if(showExport) OutlinedTextField(value=vm.backupJson(),onValueChange={},readOnly=true,modifier=Modifier.fillMaxWidth().height(160.dp),label={Text("نص النسخة الاحتياطية")})
   HorizontalDivider(); Text("استعادة نسخة",fontWeight=FontWeight.Bold,fontSize=16.sp)
   OutlinedTextField(value=importText,onValueChange={importText=it},label={Text("الصق نص النسخة الاحتياطية هنا")},modifier=Modifier.fillMaxWidth().height(150.dp))
   if(msg!=null)Text(msg!!,color=MaterialTheme.colorScheme.error,fontSize=12.sp)
   Button(onClick={vm.importBackup(importText){e->msg=e}},modifier=Modifier.fillMaxWidth(),enabled=importText.length>20,colors=ButtonDefaults.buttonColors(containerColor=MaterialTheme.colorScheme.error)){Icon(Icons.Default.Restore,null); Spacer(Modifier.width(8.dp)); Text("استعادة (ستستبدل البيانات الحالية)")}
   HorizontalDivider(); Text("تصدير التقارير",fontWeight=FontWeight.Bold)
   OutlinedButton(onClick={shareText(ctx,"تقرير مبيعات مِعيار CSV",vm.salesCsv())},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.TableChart,null); Spacer(Modifier.width(8.dp)); Text("تصدير المبيعات CSV / Excel")}
   Spacer(Modifier.height(80.dp))
  }
 }
}
