package com.agon.app.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.data.Customer
import com.agon.app.data.Sale
import com.agon.app.ui.components.*
import com.agon.app.ui.theme.Gold
import com.agon.app.ui.theme.SuccessGreen
import com.agon.app.viewmodel.*

@Composable fun PosScreen(vm:MiyarViewModel,nav:(String)->Unit,onVoice:()->Unit){
 val db by vm.db.collectAsState(); val cart by vm.cart.collectAsState()
 var query by remember{mutableStateOf(vm.aiSearchQuery)}; var cat by remember{mutableStateOf("الكل")}; var showBarcode by remember{mutableStateOf(false)}; var barcodeInput by remember{mutableStateOf("")}
 val prods=vm.bizProducts().filter{it.active && (cat=="الكل"||it.category==cat) && (query.isBlank()||it.name.contains(query)||it.barcode.contains(query))}
 val cats=listOf("الكل")+(db?.categories?.filter{it.businessId==vm.bid()}?.map{it.name}?:emptyList())
 val total=cart.sumOf{it.price*it.qty}
 Column(Modifier.fillMaxSize()){
  MiyarTopBar("الكاشير — نقطة البيع",subtitle=vm.curBranch()?.name,actions={ IconButton(onClick=onVoice){Icon(Icons.Default.Mic,null,tint=Gold)}; IconButton(onClick={nav("sales")}){Icon(Icons.Default.ReceiptLong,null)} })
  Column(Modifier.padding(horizontal=16.dp)){
   Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){
     OutlinedTextField(value=query,onValueChange={query=it},placeholder={Text("ابحث باسم المنتج أو الباركود...")},leadingIcon={Icon(Icons.Default.Search,null)},modifier=Modifier.weight(1f),singleLine=true,shape=RoundedCornerShape(14.dp))
     FilledIconButton(onClick={showBarcode=true},colors=IconButtonDefaults.filledIconButtonColors(containerColor=Gold,contentColor=Color.Black)){Icon(Icons.Default.QrCodeScanner,null)}
   }
   Spacer(Modifier.height(10.dp))
   Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.fillMaxWidth()){ cats.take(5).forEach{c-> FilterChip(selected=cat==c,onClick={cat=c},label={Text(c,fontSize=11.sp)}) } }
  }
  if(prods.isEmpty()){ EmptyState(Icons.Default.PointOfSale,"لا منتجات للبيع","أضف منتجات أولاً أو غيّر البحث/التصنيف.","إضافة منتج"){nav("product_add")} }
  else LazyVerticalGrid(GridCells.Fixed(2),Modifier.weight(1f).padding(12.dp),horizontalArrangement=Arrangement.spacedBy(10.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
   items(prods){p->
    val inCart=cart.find{it.productId==p.id}?.qty?:0
    Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth()){
     Column{
      Box{ ProductImage(p,Modifier.fillMaxWidth().height(86.dp)); if(inCart>0) Box(Modifier.align(Alignment.TopEnd).padding(6.dp).clip(CircleShape).background(Gold).padding(horizontal=8.dp,vertical=2.dp)){Text("في السلة: $inCart",fontSize=10.sp,fontWeight=FontWeight.Bold,color=Color.Black)}; if(p.quantity<=p.minStock) Box(Modifier.align(Alignment.TopStart).padding(6.dp)){AlertChip(if(p.quantity==0)"نفد" else "منخفض: ${p.quantity}")} }
      Column(Modifier.padding(10.dp)){ Text(p.name,fontWeight=FontWeight.Bold,fontSize=13.sp,maxLines=2,overflow=TextOverflow.Ellipsis); Text("${p.category} • متوفر ${p.quantity}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant); Row(verticalAlignment=Alignment.CenterVertically){ MoneyText(vm,p.salePrice,Modifier.weight(1f),14); FilledIconButton(onClick={vm.addToCart(p)},modifier=Modifier.size(34.dp),colors=IconButtonDefaults.filledIconButtonColors(containerColor=Gold,contentColor=Color.Black)){Icon(Icons.Default.Add,null,Modifier.size(18.dp))} } }
     }
    }
   }
  }
  if(cart.isNotEmpty()){
   Card(shape=RoundedCornerShape(topStart=20.dp,topEnd=20.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant),modifier=Modifier.fillMaxWidth()){
    Column(Modifier.padding(14.dp)){
     cart.take(3).forEach{item-> Row(verticalAlignment=Alignment.CenterVertically){ Text(item.productName,Modifier.weight(1f),fontSize=12.sp,maxLines=1,overflow=TextOverflow.Ellipsis); IconButton(onClick={vm.setCartQty(item.productId,item.qty-1)},Modifier.size(28.dp)){Icon(Icons.Default.Remove,null,Modifier.size(16.dp))}; Text("${item.qty}",fontWeight=FontWeight.Bold); IconButton(onClick={vm.setCartQty(item.productId,item.qty+1)},Modifier.size(28.dp)){Icon(Icons.Default.Add,null,Modifier.size(16.dp))}; MoneyText(vm,item.price*item.qty,fontSize=12) } }
     if(cart.size>3) Text("+ ${cart.size-3} منتجات أخرى في السلة",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
     Spacer(Modifier.height(8.dp)); Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ OutlinedButton(onClick={vm.clearCart()}){Text("تفريغ")}; GoldButton("السلة والدفع • ${fmtMoney(total)}",Icons.Default.ShoppingBasket,Modifier.weight(1f)){nav("checkout")} }
     Spacer(Modifier.height(70.dp))
    }
   }
  } else Spacer(Modifier.height(80.dp))
 }
 if(showBarcode) AlertDialog(onDismissRequest={showBarcode=false},title={Text("قارئ الباركود")},text={ Column{ Text("وجّه الكاميرا في النسخة المرتبطة بـ ML Kit، أو أدخل رقم الباركود يدوياً الآن للبحث الفوري وإضافة المنتج للسلة:",fontSize=12.sp); Spacer(Modifier.height(10.dp)); MiyarTextField(barcodeInput,{barcodeInput=it},"رقم الباركود",icon=Icons.Default.QrCode,keyboardType=KeyboardType.Number); Spacer(Modifier.height(8.dp)); Text("جرّب التجريبي: 629110345001 (أرز بسمتي)",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) } },confirmButton={ TextButton(onClick={ val p=vm.bizProducts().find{it.barcode==barcodeInput.trim()}; if(p!=null){vm.addToCart(p); vm.showToast("أُضيف ${p.name} إلى السلة")}else vm.showToast("لم يُعثر على منتج بهذا الباركود"); showBarcode=false }){Text("بحث وإضافة")} },dismissButton={TextButton(onClick={showBarcode=false}){Text("إلغاء")}})
}
@Composable fun CheckoutScreen(vm:MiyarViewModel,back:()->Unit,nav:(String)->Unit){
 val db by vm.db.collectAsState(); val cart by vm.cart.collectAsState()
 val customers=vm.bizCustomers()
 var custName by remember{mutableStateOf( customers.find{it.id==vm.aiPrefillCustomerId}?.name ?: "عميل نقدي")}
 var discount by remember{mutableStateOf("")}; var paidTxt by remember{mutableStateOf("")}; var payType by remember{mutableStateOf("نقداً")}; var processing by remember{mutableStateOf(false)}
 val sub=cart.sumOf{it.price*it.qty}; val disc=discount.toDoubleOrNull()?:0.0; val total=(sub-disc).coerceAtLeast(0.0); val paid= if(paidTxt.isBlank()) total else (paidTxt.toDoubleOrNull()?:0.0); val remaining=(total-paid.coerceIn(0.0,total))
 Column(Modifier.fillMaxSize()){
  MiyarTopBar("سلة المبيعات والدفع",back)
  if(cart.isEmpty()) EmptyState(Icons.Default.ShoppingBasket,"السلة فارغة","ارجع إلى الكاشير وأضف منتجات للبيع.","إلى الكاشير"){nav("pos")}
  else LazyColumn(Modifier.padding(horizontal=16.dp).weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp)){
   items(cart){item-> Card(shape=RoundedCornerShape(13.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth()){ Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){ Column(Modifier.weight(1f)){Text(item.productName,fontWeight=FontWeight.Bold,fontSize=13.sp); MoneyText(vm,item.price,fontSize=11,bold=false)}; IconButton(onClick={vm.setCartQty(item.productId,item.qty-1)}){Icon(Icons.Default.RemoveCircleOutline,null)}; Text("${item.qty}",fontWeight=FontWeight.ExtraBold); IconButton(onClick={vm.setCartQty(item.productId,item.qty+1)}){Icon(Icons.Default.AddCircleOutline,null)}; MoneyText(vm,item.price*item.qty,fontSize=13); IconButton(onClick={vm.setCartQty(item.productId,0)}){Icon(Icons.Default.Delete,null,tint=MaterialTheme.colorScheme.error)} } } }
   item{
    Spacer(Modifier.height(6.dp)); Text("العميل وطريقة الدفع",fontWeight=FontWeight.Bold,fontSize=16.sp); Spacer(Modifier.height(8.dp))
    DropdownField("العميل",custName,listOf("عميل نقدي")+customers.map{it.name},{custName=it})
    if(custName!="عميل نقدي"){ val c=customers.find{it.name==custName}; if(c!=null) Text("مديونية حالية: ${fmtMoney(c.balance)} ${db?.settings?.currency}",fontSize=12.sp,color=if(c.balance>0)MaterialTheme.colorScheme.error else SuccessGreen) }
    Spacer(Modifier.height(10.dp)); Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){ listOf("نقداً","آجل","دفع جزئي","حوالة","بطاقة").forEach{t-> FilterChip(selected=payType==t,onClick={payType=t; if(t=="آجل")paidTxt="0"; if(t=="نقداً")paidTxt=""},label={Text(t,fontSize=11.sp)}) } }
    Spacer(Modifier.height(10.dp)); MiyarTextField(discount,{discount=it},"خصم (اختياري)",icon=Icons.Default.Discount,keyboardType=KeyboardType.Number)
    Spacer(Modifier.height(10.dp)); MiyarTextField(paidTxt,{paidTxt=it},"المبلغ المدفوع الآن (اتركه فارغاً = كامل)",icon=Icons.Default.Payments,keyboardType=KeyboardType.Number,placeholder=fmtMoney(total))
    Spacer(Modifier.height(14.dp))
    Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant)){ Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
      Row(Modifier.fillMaxWidth()){Text("المجموع الفرعي",Modifier.weight(1f),fontSize=13.sp); MoneyText(vm,sub,fontSize=13)}
      if(disc>0) Row(Modifier.fillMaxWidth()){Text("الخصم",Modifier.weight(1f),fontSize=13.sp,color=SuccessGreen); MoneyText(vm,-disc,fontSize=13,color=SuccessGreen)}
      HorizontalDivider(); Row(Modifier.fillMaxWidth()){Text("الإجمالي المستحق",Modifier.weight(1f),fontWeight=FontWeight.ExtraBold); MoneyText(vm,total,fontSize=17)}
      Row(Modifier.fillMaxWidth()){Text("المدفوع",Modifier.weight(1f),fontSize=13.sp); MoneyText(vm,paid.coerceIn(0.0,total),fontSize=13)}
      Row(Modifier.fillMaxWidth()){Text(if(remaining>0)"المتبقي (دين على العميل)" else "المتبقي",Modifier.weight(1f),fontSize=13.sp,color=if(remaining>0)MaterialTheme.colorScheme.error else SuccessGreen); MoneyText(vm,remaining,fontSize=13,color=if(remaining>0)MaterialTheme.colorScheme.error else SuccessGreen)}
      if(remaining>0 && custName=="عميل نقدي") Text("⚠️ البيع الآجل يحتاج اختيار عميل مسجل ليُسجل الدين على حسابه.",fontSize=11.sp,color=MaterialTheme.colorScheme.error)
    } }
    Spacer(Modifier.height(14.dp))
    GoldButton(if(processing)"جارٍ الاعتماد..." else "اعتماد البيع وإصدار الفاتورة",Icons.Default.CheckCircle,Modifier.fillMaxWidth(),enabled=!processing && !(remaining>0&&custName=="عميل نقدي")){
      processing=true; val cust=customers.find{it.name==custName}; vm.checkout(cust,disc,paid,payType){sale-> processing=false; if(sale!=null) nav("invoice/${sale.id}") }
    }
    Spacer(Modifier.height(90.dp))
   }
  }
 }
}
fun saleToText(vm:MiyarViewModel,s:Sale):String{ val cur=vm.db.value?.settings?.currency?:"ر.ي"; val biz=vm.curBusiness()?.name?:"مِعيار"; val sb=StringBuilder(); sb.append("🧾 فاتورة $biz\nرقم: ${s.number} | ${fmtDateTime(s.date)}\nالعميل: ${s.customerName}\n----------------\n"); s.items.forEach{sb.append("${it.productName} × ${it.qty} = ${fmtMoney(it.price*it.qty)} $cur\n")}; sb.append("----------------\nالإجمالي: ${fmtMoney(s.total)} $cur\nالمدفوع: ${fmtMoney(s.paid)} | المتبقي: ${fmtMoney(s.remaining)}\nطريقة الدفع: ${s.paymentType}\nشكراً لتعاملكم معنا — مِعيار MI'YAR"); return sb.toString() }
@Composable fun InvoiceScreen(vm:MiyarViewModel,saleId:String,back:()->Unit,nav:(String)->Unit){
 val db by vm.db.collectAsState(); val s=db?.sales?.find{it.id==saleId}; val ctx=LocalContext.current
 var confirmReturn by remember{mutableStateOf(false)}
 Column(Modifier.fillMaxSize()){ MiyarTopBar("الفاتورة ${s?.number?:""}",back,actions={ if(s!=null){ IconButton(onClick={shareText(ctx,"فاتورة ${s.number}",saleToText(vm,s))}){Icon(Icons.Default.Share,null)}; IconButton(onClick={shareText(ctx,"فاتورة ${s.number} (PDF نصي)",saleToText(vm,s)); vm.showToast("لمشاركة PDF رسمي اربط طابعة/مولد PDF — تمت مشاركة نص الفاتورة الآن")}){Icon(Icons.Default.Print,null)} } })
  if(s==null) EmptyState(Icons.Default.Receipt,"فاتورة غير موجودة","قد تكون حُذفت.")
  else LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
   item{ Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFFAF8F3))){ Column(Modifier.padding(18.dp)){
     Row{ Column(Modifier.weight(1f)){Text(vm.curBusiness()?.name?:"",fontWeight=FontWeight.ExtraBold,fontSize=17.sp,color=Color.Black); Text(vm.curBranch()?.name?:"",fontSize=12.sp,color=Color.DarkGray)}; Text("فاتورة مبيعات",fontWeight=FontWeight.Bold,color=Color(0xFF8A6D1B)) }
     Spacer(Modifier.height(8.dp)); Text("${s.number} • ${fmtDateTime(s.date)}",fontSize=12.sp,color=Color.DarkGray); Text("العميل: ${s.customerName} • الكاشير: ${s.userName}",fontSize=12.sp,color=Color.DarkGray); if(s.status!="مكتملة") AlertChip(s.status)
     Spacer(Modifier.height(10.dp)); HorizontalDivider(color=Color.LightGray)
     s.items.forEach{it-> Row(Modifier.fillMaxWidth().padding(vertical=5.dp)){ Column(Modifier.weight(1f)){Text(it.productName,fontSize=13.sp,color=Color.Black); Text("${it.qty} × ${fmtMoney(it.price)}",fontSize=11.sp,color=Color.Gray)}; Text(fmtMoney(it.price*it.qty),fontWeight=FontWeight.Bold,color=Color.Black) } }
     HorizontalDivider(color=Color.LightGray); Spacer(Modifier.height(8.dp))
     Row(Modifier.fillMaxWidth()){Text("الإجمالي",fontWeight=FontWeight.ExtraBold,color=Color.Black,modifier=Modifier.weight(1f)); MoneyText(vm,s.total,fontSize=16,color=Color.Black)}
     Row(Modifier.fillMaxWidth()){Text("المدفوع (${s.paymentType})",color=Color.DarkGray,fontSize=12.sp,modifier=Modifier.weight(1f)); MoneyText(vm,s.paid,fontSize=12,color=Color.DarkGray)}
     Row(Modifier.fillMaxWidth()){Text("المتبقي",color=if(s.remaining>0)Color.Red else Color(0xFF26A269),fontSize=12.sp,modifier=Modifier.weight(1f)); MoneyText(vm,s.remaining,fontSize=12,color=if(s.remaining>0)Color.Red else Color(0xFF26A269))}
     Spacer(Modifier.height(14.dp)); BarcodeView(s.number.filter{it.isDigit()}.ifBlank{"1000"},Modifier.fillMaxWidth())
     Text("شكراً لتعاملكم معنا — مِعيار MI'YAR",fontSize=11.sp,color=Color.Gray,modifier=Modifier.align(Alignment.CenterHorizontally))
   } } }
   item{ Row(horizontalArrangement=Arrangement.spacedBy(10.dp),modifier=Modifier.fillMaxWidth()){ GoldButton("مشاركة الفاتورة",Icons.Default.Share,Modifier.weight(1f)){shareText(ctx,"فاتورة ${s.number}",saleToText(vm,s))}; OutlinedButton(onClick={nav("pos")},modifier=Modifier.weight(1f).height(50.dp),shape=RoundedCornerShape(14.dp)){Text("بيع جديد")} } }
   if(s.status=="مكتملة") item{ Button(onClick={confirmReturn=true},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=MaterialTheme.colorScheme.error)){Icon(Icons.Default.AssignmentReturn,null); Spacer(Modifier.width(8.dp)); Text("مرتجع / إلغاء الفاتورة (يستعيد المخزون والصندوق)")} }
   item{Spacer(Modifier.height(80.dp))}
  }
 }
 if(confirmReturn&&s!=null) AlertDialog(onDismissRequest={confirmReturn=false},title={Text("تأكيد المرتجع")},text={Text("سيتم إرجاع منتجات ${s.number} للمخزون، وعكس أثرها على الصندوق وحساب العميل، مع تسجيل سجل تدقيق. متابعة؟")},confirmButton={TextButton(onClick={vm.returnSale(s.id);confirmReturn=false}){Text("تنفيذ المرتجع")}},dismissButton={TextButton(onClick={confirmReturn=false}){Text("تراجع")}})
}
@Composable fun SalesScreen(vm:MiyarViewModel,back:()->Unit,nav:(String)->Unit){
 val db by vm.db.collectAsState(); var q by remember{mutableStateOf("")}; var filter by remember{mutableStateOf("الكل")}
 val sales=vm.bizSales().filter{(filter=="الكل"||it.status==filter)&&(q.isBlank()||it.number.contains(q)||it.customerName.contains(q))}
 Column(Modifier.fillMaxSize()){ MiyarTopBar("سجل المبيعات والمرتجعات",back)
  Column(Modifier.padding(horizontal=16.dp)){ OutlinedTextField(q,{q=it},placeholder={Text("بحث برقم الفاتورة أو العميل")},leadingIcon={Icon(Icons.Default.Search,null)},modifier=Modifier.fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(14.dp)); Spacer(Modifier.height(8.dp)); Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("الكل","مكتملة","مرتجعة").forEach{f->FilterChip(selected=filter==f,onClick={filter=f},label={Text(f)})}} }
  if(sales.isEmpty()) EmptyState(Icons.Default.ReceiptLong,"لا فواتير","ستظهر هنا فواتير البيع من الكاشير.","بيع جديد"){nav("pos")}
  else LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){ items(sales){s-> Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth().clickable{nav("invoice/${s.id}")}){ Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){ Box(Modifier.size(42.dp).clip(RoundedCornerShape(11.dp)).background(if(s.status=="مكتملة")SuccessGreen.copy(alpha=0.13f) else MaterialTheme.colorScheme.error.copy(alpha=0.13f)),contentAlignment=Alignment.Center){Icon(Icons.Default.Receipt,null,tint=if(s.status=="مكتملة")SuccessGreen else MaterialTheme.colorScheme.error)}; Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)){Text("${s.number} • ${s.customerName}",fontWeight=FontWeight.Bold,fontSize=14.sp); Text("${fmtDateTime(s.date)} • ${s.items.sumOf{it.qty}} منتج • ${s.status}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}; Column(horizontalAlignment=Alignment.End){MoneyText(vm,s.total,fontSize=14); if(s.remaining>0)Text("متبقي ${fmtMoney(s.remaining)}",fontSize=10.sp,color=MaterialTheme.colorScheme.error)} } } }; item{Spacer(Modifier.height(80.dp))} }
 }
}
