package com.agon.app.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.data.*
import com.agon.app.ui.components.*
import com.agon.app.ui.theme.Gold
import com.agon.app.ui.theme.SuccessGreen
import com.agon.app.viewmodel.*

@Composable fun EmployeesScreen(vm:MiyarViewModel,back:()->Unit,nav:(String)->Unit){
 val db by vm.db.collectAsState(); val emps=db?.employees?.filter{it.businessId==vm.bid()}?:emptyList()
 var showAdd by remember{mutableStateOf(false)}
 var name by remember{mutableStateOf("")}; var phone by remember{mutableStateOf("")}; var role by remember{mutableStateOf("كاشير")}; var branch by remember{mutableStateOf(vm.curBranch()?.name?:"")}
 Column(Modifier.fillMaxSize()){ MiyarTopBar("الموظفون",back,actions={ IconButton(onClick={nav("join_requests")}){Icon(Icons.Default.GroupAdd,null,tint=Gold)}; IconButton(onClick={showAdd=true}){Icon(Icons.Default.Add,null,tint=Gold)} })
  if(showAdd) Card(Modifier.padding(16.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){ Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){ Text("إضافة موظف",fontWeight=FontWeight.Bold); MiyarTextField(name,{name=it},"الاسم",icon=Icons.Default.Person); MiyarTextField(phone,{phone=it},"الهاتف",icon=Icons.Default.Phone,keyboardType=KeyboardType.Phone); DropdownField("الدور",role,ROLES){role=it}; DropdownField("الفرع",branch,(db?.branches?.filter{it.businessId==vm.bid()}?.map{it.name}?:listOf("الفرع الرئيسي"))){branch=it}; Row{ GoldButton("حفظ",Icons.Default.Save,Modifier.weight(1f)){ if(name.isBlank()) vm.showToast("أدخل اسم الموظف") else { vm.addEmployee(name.trim(),phone.trim(),role,branch); showAdd=false;name="";phone="" } }; Spacer(Modifier.width(8.dp)); OutlinedButton(onClick={showAdd=false},modifier=Modifier.weight(1f)){Text("إلغاء")} } } }
  LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
   items(emps){e-> Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth().clickable{nav("permissions/${e.id}")}){ Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){ Box(Modifier.size(42.dp).clip(CircleShape).background(Gold.copy(alpha=0.13f)),contentAlignment=Alignment.Center){Text(e.name.take(1),fontWeight=FontWeight.Bold,color=Gold)}; Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)){Text(e.name,fontWeight=FontWeight.Bold,fontSize=14.sp); Text("${e.role} • ${e.branchName}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant); Text(if(e.active)"نشط" else "موقوف",fontSize=10.sp,color=if(e.active)SuccessGreen else MaterialTheme.colorScheme.error)}; IconButton(onClick={vm.toggleEmployee(e.id)}){Icon(if(e.active)Icons.Default.Block else Icons.Default.PlayCircle,null,tint=if(e.active)MaterialTheme.colorScheme.error else SuccessGreen)}; Icon(Icons.Default.ChevronLeft,null,tint=MaterialTheme.colorScheme.onSurfaceVariant) } } }
   item{Spacer(Modifier.height(80.dp))}
  }
 }
}
@Composable fun JoinRequestsScreen(vm:MiyarViewModel,back:()->Unit){
 val db by vm.db.collectAsState(); val reqs=db?.joinRequests?.filter{it.businessId==vm.bid()}?.sortedByDescending{it.date}?:emptyList()
 Column(Modifier.fillMaxSize()){ MiyarTopBar("طلبات الانضمام",back)
  if(reqs.isEmpty()) EmptyState(Icons.Default.GroupAdd,"لا طلبات","عندما يطلب موظف الانضمام برمز النشاط ستظهر طلباته هنا للمراجعة.")
  else LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
   items(reqs){r-> Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth()){ Column(Modifier.padding(14.dp)){ Row(verticalAlignment=Alignment.CenterVertically){ Icon(Icons.Default.PersonAdd,null,tint=Gold); Spacer(Modifier.width(8.dp)); Column(Modifier.weight(1f)){Text(r.name,fontWeight=FontWeight.Bold,fontSize=14.sp); Text("${r.phone} • الدور المطلوب: ${r.requestedRole}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}; AlertChip(r.status,if(r.status=="مقبول")SuccessGreen else if(r.status=="مرفوض")MaterialTheme.colorScheme.error else Gold) }; Text(fmtDateTime(r.date),fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
    if(r.status=="قيد الانتظار"){ Spacer(Modifier.height(10.dp)); Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ GoldButton("قبول وتفعيل",Icons.Default.Check,Modifier.weight(1f)){ vm.decideJoin(r.id,true) }; OutlinedButton(onClick={vm.decideJoin(r.id,false)},modifier=Modifier.weight(1f).height(50.dp),shape=RoundedCornerShape(14.dp)){Text("رفض",color=MaterialTheme.colorScheme.error)} } } } } }
   item{Spacer(Modifier.height(80.dp))}
  }
 }
}
@Composable fun PermissionsScreen(vm:MiyarViewModel,empId:String,back:()->Unit){
 val db by vm.db.collectAsState(); val e=db?.employees?.find{it.id==empId}
 Column(Modifier.fillMaxSize()){ MiyarTopBar("صلاحيات ${e?.name?:""}",back)
  if(e==null) EmptyState(Icons.Default.AdminPanelSettings,"الموظف غير موجود","")
  else Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)){
   Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){ Column(Modifier.padding(14.dp)){ Text("الدور الوظيفي",fontWeight=FontWeight.Bold); Spacer(Modifier.height(8.dp)); DropdownField("الدور",e.role,ROLES){vm.setEmployeeRole(e.id,it)}; Spacer(Modifier.height(10.dp)); Text("تخصيص الصلاحيات لكل عملية: عرض • إضافة • تعديل • حذف • اعتماد • إلغاء • تصدير • طباعة",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) } }
   Spacer(Modifier.height(10.dp))
   ALL_PERMISSIONS.forEach{p-> Row(Modifier.fillMaxWidth().padding(vertical=2.dp),verticalAlignment=Alignment.CenterVertically){ Text(p,Modifier.weight(1f),fontSize=13.sp); Switch(e.permissions.contains(p),{vm.togglePermission(e.id,p)}) } }
   Spacer(Modifier.height(20.dp)); OutlinedButton(onClick={vm.toggleEmployee(e.id)},modifier=Modifier.fillMaxWidth()){ Icon(if(e.active)Icons.Default.Block else Icons.Default.PlayCircle,null); Spacer(Modifier.width(8.dp)); Text(if(e.active)"إيقاف حساب الموظف" else "تفعيل حساب الموظف") }
   Spacer(Modifier.height(90.dp))
  }
 }
}
@Composable fun BranchesScreen(vm:MiyarViewModel,back:()->Unit,onVoice:()->Unit){
 val db by vm.db.collectAsState(); val branches=db?.branches?.filter{it.businessId==vm.bid()}?:emptyList()
 var showAdd by remember{mutableStateOf(false)}; var name by remember{mutableStateOf("")}; var manager by remember{mutableStateOf("")}; var address by remember{mutableStateOf("")}
 Column(Modifier.fillMaxSize()){ MiyarTopBar("الفروع",back,actions={ IconButton(onClick={showAdd=true}){Icon(Icons.Default.Add,null,tint=Gold)} })
  if(showAdd) Card(Modifier.padding(16.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){ Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){ Text("فرع جديد",fontWeight=FontWeight.Bold); MiyarTextField(name,{name=it},"اسم الفرع",icon=Icons.Default.Business); MiyarTextField(manager,{manager=it},"مدير الفرع",icon=Icons.Default.ManageAccounts); MiyarTextField(address,{address=it},"العنوان",icon=Icons.Default.LocationOn); Row{ GoldButton("حفظ",Icons.Default.Save,Modifier.weight(1f)){ if(name.isBlank())vm.showToast("أدخل اسم الفرع")else{ vm.addBranch(name.trim(),manager.trim(),address.trim()); showAdd=false;name="";manager="";address="" } }; Spacer(Modifier.width(8.dp)); OutlinedButton(onClick={showAdd=false},modifier=Modifier.weight(1f)){Text("إلغاء")} } } }
  LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
   items(branches){b-> Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=if(b.id==db?.currentBranchId)Gold.copy(alpha=0.1f) else MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth().clickable{vm.switchBranch(b.id); vm.showToast("تم التبديل إلى ${b.name}")}){ Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){ Icon(Icons.Default.Business,null,tint=Gold); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)){Text(b.name,fontWeight=FontWeight.Bold,fontSize=14.sp); Text("المدير: ${b.manager} • ${b.address}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}; if(b.id==db?.currentBranchId) AlertChip("نشط",SuccessGreen) } } }
   item{Spacer(Modifier.height(80.dp))}
  }
 }
}
@Composable fun BusinessesScreen(vm:MiyarViewModel,back:()->Unit,nav:(String)->Unit){
 val db by vm.db.collectAsState(); val list=db?.businesses?:emptyList()
 Column(Modifier.fillMaxSize()){ MiyarTopBar("الأنشطة التجارية",back)
  LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
   items(list){b-> Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=if(b.id==db?.currentBusinessId)Gold.copy(alpha=0.1f) else MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth().clickable{vm.switchBusiness(b.id); vm.showToast("تم التبديل إلى ${b.name}")}){ Column(Modifier.padding(14.dp)){ Row(verticalAlignment=Alignment.CenterVertically){ Icon(Icons.Default.Store,null,tint=Gold); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)){Text(b.name,fontWeight=FontWeight.Bold,fontSize=15.sp); Text(b.type,fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}; if(b.id==db?.currentBusinessId) AlertChip("نشط",SuccessGreen) }; Spacer(Modifier.height(8.dp)); Row{ Text("رمز الانضمام",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.width(8.dp)); Text(b.code,fontWeight=FontWeight.ExtraBold,color=Gold); Spacer(Modifier.weight(1f)); Text("الفروع: ${db?.branches?.count{it.businessId==b.id}?:0}",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) } } } }
   item{ Spacer(Modifier.height(10.dp)); OutlinedButton(onClick={vm.logout()},modifier=Modifier.fillMaxWidth()){Text("إنشاء نشاط تجاري جديد (تسجيل الخروج ثم إنشاء)")}; Spacer(Modifier.height(90.dp)) }
  }
 }
}
@Composable fun AiScreen(vm:MiyarViewModel,back:()->Unit,nav:(String)->Unit){
 val messages by vm.aiMessages.collectAsState(); val pending by vm.pendingAction.collectAsState(); val settings by remember{ mutableStateOf(vm.db.value?.settings) }
 var input by remember{mutableStateOf("")}; var listening by remember{mutableStateOf(false)}
 val ctx=LocalContext.current
 val launcher=rememberVoiceLauncher(onResult={ t-> input=t; vm.processAi(t,"MIYAR AI") }, onError={ vm.showToast(it) })
 LaunchedEffect(Unit){ if(vm.aiSearchQuery.isNotBlank()){ input=vm.aiSearchQuery; vm.aiSearchQuery="" } }
 Column(Modifier.fillMaxSize()){
  MiyarTopBar("MIYAR AI — مساعد مِعيار الذكي",back,actions={ IconButton(onClick={nav("voice_history")}){Icon(Icons.Default.History,null)} })
  Column(Modifier.padding(horizontal=16.dp)){ Card(shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=Gold.copy(alpha=0.09f))){ Row(Modifier.padding(11.dp),verticalAlignment=Alignment.CenterVertically){ Icon(Icons.Default.RecordVoiceOver,null,tint=Gold); Spacer(Modifier.width(8.dp)); Text("يفهم العربية واللهجة اليمنية • لا ينفذ أي عملية مالية دون تأكيد صريح",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) } } }
  LazyColumn(Modifier.weight(1f).padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
   items(messages){(isUser,text)-> Row(Modifier.fillMaxWidth(),horizontalArrangement=if(isUser)Arrangement.End else Arrangement.Start){ Box(Modifier.widthIn(max=280.dp).clip(RoundedCornerShape(16.dp)).background(if(isUser)Gold.copy(alpha=0.22f) else MaterialTheme.colorScheme.surfaceVariant).padding(12.dp)){ Text(text,fontSize=13.sp) } } }
   if(pending!=null){ item{ Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth()){ Column(Modifier.padding(14.dp)){ Row{Icon(Icons.Default.PriorityHigh,null,tint=MaterialTheme.colorScheme.error); Spacer(Modifier.width(6.dp)); Text("بانتظار تأكيدك",fontWeight=FontWeight.Bold,fontSize=14.sp,color=MaterialTheme.colorScheme.error)}; Spacer(Modifier.height(6.dp)); Text(pending!!.summary,fontSize=14.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.height(10.dp)); Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ GoldButton("تأكيد وتنفيذ",Icons.Default.CheckCircle,Modifier.weight(1f)){ vm.confirmPending() }; OutlinedButton(onClick={vm.cancelPending()},modifier=Modifier.weight(1f).height(50.dp),shape=RoundedCornerShape(14.dp)){Text("إلغاء")} } } } } }
   item{ Spacer(Modifier.height(6.dp)) }
  }
  Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(12.dp),verticalAlignment=Alignment.CenterVertically){
   OutlinedTextField(value=input,onValueChange={input=it},placeholder={Text("اكتب الأمر أو تحدث...")},modifier=Modifier.weight(1f),shape=RoundedCornerShape(24.dp),maxLines=3)
   Spacer(Modifier.width(8.dp))
   FilledIconButton(onClick={ if(listening){listening=false}else{listening=true; launcher()} },modifier=Modifier.size(52.dp),colors=IconButtonDefaults.filledIconButtonColors(containerColor=if(listening)MaterialTheme.colorScheme.error else Gold,contentColor=Color.Black)){ Icon(if(listening)Icons.Default.Stop else Icons.Default.Mic,null) }
   Spacer(Modifier.width(6.dp))
   FilledIconButton(onClick={ if(input.isNotBlank()){ vm.processAi(input,"MIYAR AI"); input="" } },modifier=Modifier.size(52.dp),colors=IconButtonDefaults.filledIconButtonColors(containerColor=Gold,contentColor=Color.Black)){ Icon(Icons.Default.Send,null) }
  }
 }
}
@Composable fun VoiceHistoryScreen(vm:MiyarViewModel,back:()->Unit){
 val db by vm.db.collectAsState(); val list=db?.voiceHistory?.filter{it.businessId==vm.bid()}?.reversed()?:emptyList()
 Column(Modifier.fillMaxSize()){ MiyarTopBar("سجل الأوامر الصوتية",back)
  if(list.isEmpty()) EmptyState(Icons.Default.History,"لا أوامر مسجلة","كل أمر صوتي أو نصي ينفذه MIYAR AI يُحفظ هنا للمراجعة.")
  else LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
   items(list){v-> Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth()){ Column(Modifier.padding(13.dp)){ Row{ Icon(Icons.Default.Mic,null,modifier=Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text(v.command,Modifier.weight(1f),fontWeight=FontWeight.Bold,fontSize=13.sp,color=Gold); AlertChip(if(v.executed)"نُفذ" else "لم يُنفذ",if(v.executed)SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant) }; Spacer(Modifier.height(5.dp)); Text(v.response,fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant); Text(fmtDateTime(v.date),fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) } } }
   item{Spacer(Modifier.height(80.dp))}
  }
 }
}
