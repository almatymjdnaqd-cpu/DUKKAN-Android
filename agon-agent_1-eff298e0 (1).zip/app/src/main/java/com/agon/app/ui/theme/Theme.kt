package com.agon.app.ui.theme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkScheme = darkColorScheme(
    primary = Gold, onPrimary = Color(0xFF1A1400), primaryContainer = Color(0xFF2A2210), onPrimaryContainer = Gold,
    secondary = GoldDark, onSecondary = Color.Black, tertiary = SuccessGreen,
    background = DarkBg, onBackground = Ivory, surface = CardDark, onSurface = Ivory,
    surfaceVariant = CardDark2, onSurfaceVariant = MutedDark, error = ErrorRed, onError = Color.White,
    outline = Color(0xFF2C3548)
)

private val LightScheme = lightColorScheme(
    primary = LightPrimary, onPrimary = Color.White, primaryContainer = Color(0xFFFFEFC2), onPrimaryContainer = Color(0xFF3A2E00),
    secondary = GoldDark, tertiary = SuccessGreen, background = LightBg, onBackground = Color(0xFF171D28),
    surface = LightCard, onSurface = Color(0xFF171D28), surfaceVariant = Color(0xFFEDE6D6), onSurfaceVariant = Color(0xFF5B6472),
    error = ErrorRed, outline = Color(0xFFD8CFB8)
)

@Composable
fun AgonAppTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkScheme else LightScheme,
        content = content
    )
}
