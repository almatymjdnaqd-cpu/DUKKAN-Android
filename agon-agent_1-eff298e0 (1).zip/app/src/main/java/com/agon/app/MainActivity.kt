package com.agon.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.agon.app.ui.components.*
import com.agon.app.ui.screens.*
import com.agon.app.ui.theme.Gold
import com.agon.app.ui.theme.SuccessGreen
import com.agon.app.viewmodel.MiyarViewModel
import com.agon.app.viewmodel.fmtMoney

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent { MiyarRoot() }
    }
}

@Composable fun MiyarRoot(vm: MiyarViewModel = viewModel()) {
    val db by vm.db.collectAsState()
    val settings = db?.settings
    com.agon.app.ui.theme.AgonAppTheme(darkTheme = settings?.darkMode ?: true) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            val d = db
            when {
                d == null -> SplashScreen()
                vm.locked.collectAsState().value -> LockScreen(vm)
                d.sessionUserId.isBlank() -> AuthFlow(vm)
                d.currentBusinessId.isBlank() -> CreateBusinessScreen(vm)
                else -> MainShell(vm)
            }
        }
    }
}

private val bottomRoutes = setOf("home", "pos", "products", "finance", "more")

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun MainShell(vm: MiyarViewModel) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route ?: "home"
    var showVoice by remember { mutableStateOf(false) }
    var voiceText by remember { mutableStateOf("") }
    var voiceResponse by remember { mutableStateOf("") }
    val pending by vm.pendingAction.collectAsState()
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val layoutDirection = LocalLayoutDirection.current

    val launcher = rememberVoiceLauncher(
        onResult = { text ->
            voiceText = text
            val res = vm.processAi(text, screenLabel(route))
            voiceResponse = res.message
            showVoice = true
        },
        onError = { vm.showToast(it) }
    )

    Scaffold(
        bottomBar = {
            if (route in bottomRoutes) {
                MiyarBottomBar(nav, route)
            }
        },
        floatingActionButton = {
            if (route !in setOf("ai")) {
                SmallFloatingActionButton(
                    onClick = { launcher() },
                    containerColor = Gold,
                    contentColor = Color.Black,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.padding(bottom = 6.dp)
                ) { Icon(Icons.Default.Mic, "مساعد صوتي") }
            }
        }
    ) { inner ->
        Box(Modifier.padding(inner)) {
            NavHost(nav, startDestination = "home") {
                composable("home") { DashboardScreen(vm, { r -> nav.go(r) }, { launcher() }) }
                composable("pos") { PosScreen(vm, { r -> nav.go(r) }, { launcher() }) }
                composable("products") { ProductsScreen(vm, { nav.popBackStack() }, { r -> nav.go(r) }, { launcher() }) }
                composable("finance") { FinanceScreen(vm, { r -> nav.go(r) }, { launcher() }) }
                composable("more") { MoreScreen(vm, { r -> nav.go(r) }) }
                composable("checkout") { CheckoutScreen(vm, { nav.popBackStack() }, { r -> nav.go(r) }) }
                composable("sales") { SalesScreen(vm, { nav.popBackStack() }, { r -> nav.go(r) }) }
                composable("invoice/{id}") { backStackEntry ->
                    val id = backStackEntry.arguments?.getString("id").orEmpty()
                    InvoiceScreen(vm, id, { nav.popBackStack() }, { r -> nav.go(r) })
                }
                composable("product_add") { ProductFormScreen(vm, null, { nav.popBackStack() }, { launcher() }) }
                composable("product_add/{id}") { backStackEntry ->
                    ProductFormScreen(vm, backStackEntry.arguments?.getString("id"), { nav.popBackStack() }, { launcher() })
                }
                composable("product_detail/{id}") { backStackEntry ->
                    ProductDetailScreen(vm, backStackEntry.arguments?.getString("id").orEmpty(), { nav.popBackStack() }, { r -> nav.go(r) }, { launcher() })
                }
                composable("categories") { CategoriesScreen(vm, { nav.popBackStack() }) }
                composable("inventory") { InventoryScreen(vm, { nav.popBackStack() }, { r -> nav.go(r) }, { launcher() }) }
                composable("purchases") { PurchasesScreen(vm, { nav.popBackStack() }, { r -> nav.go(r) }, { launcher() }) }
                composable("purchase_new") { PurchaseNewScreen(vm, { nav.popBackStack() }, { launcher() }) }
                composable("purchase_detail/{id}") { backStackEntry ->
                    PurchaseDetailScreen(vm, backStackEntry.arguments?.getString("id").orEmpty(), { nav.popBackStack() })
                }
                composable("suppliers") { SuppliersScreen(vm, { nav.popBackStack() }, { r -> nav.go(r) }, { launcher() }) }
                composable("supplier_detail/{id}") { backStackEntry ->
                    SupplierDetailScreen(vm, backStackEntry.arguments?.getString("id").orEmpty(), { nav.popBackStack() })
                }
                composable("customers") { CustomersScreen(vm, { nav.popBackStack() }, { r -> nav.go(r) }, { launcher() }) }
                composable("customer_detail/{id}") { backStackEntry ->
                    CustomerDetailScreen(vm, backStackEntry.arguments?.getString("id").orEmpty(), { nav.popBackStack() })
                }
                composable("expenses") { ExpensesScreen(vm, { nav.popBackStack() }, { launcher() }) }
                composable("cashbox") { CashboxScreen(vm, { nav.popBackStack() }, { launcher() }) }
                composable("shifts") { ShiftsScreen(vm, { nav.popBackStack() }, { launcher() }) }
                composable("reports") { ReportsScreen(vm, { nav.popBackStack() }, { r -> nav.go(r) }, { launcher() }) }
                composable("profitloss") { ReportsScreen(vm, { nav.popBackStack() }, { r -> nav.go(r) }, { launcher() }) }
                composable("employees") { EmployeesScreen(vm, { nav.popBackStack() }, { r -> nav.go(r) }) }
                composable("join_requests") { JoinRequestsScreen(vm, { nav.popBackStack() }) }
                composable("permissions/{id}") { backStackEntry ->
                    PermissionsScreen(vm, backStackEntry.arguments?.getString("id").orEmpty(), { nav.popBackStack() })
                }
                composable("branches") { BranchesScreen(vm, { nav.popBackStack() }, { launcher() }) }
                composable("businesses") { BusinessesScreen(vm, { nav.popBackStack() }, { r -> nav.go(r) }) }
                composable("ai") { AiScreen(vm, { nav.popBackStack() }, { r -> nav.go(r) }) }
                composable("voice_history") { VoiceHistoryScreen(vm, { nav.popBackStack() }) }
                composable("notifications") { NotificationsScreen(vm, { nav.popBackStack() }) }
                composable("backup") { BackupScreen(vm, { nav.popBackStack() }) }
                composable("settings") { SettingsScreen2(vm, { nav.popBackStack() }) }
                composable("profile") { ProfileScreen(vm, { nav.popBackStack() }, { r -> nav.go(r) }) }
                composable("about") { AboutScreen(vm, { nav.popBackStack() }) }
            }
        }
    }

    if (showVoice) {
        ModalBottomSheet(onDismissRequest = { showVoice = false }) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(40.dp).background(Gold.copy(alpha = 0.18f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.AutoAwesome, null, tint = Gold) }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("MIYAR AI", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        Text("فهمت الأمر التالي", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { showVoice = false }) { Icon(Icons.Default.Close, null) }
                }
                Spacer(Modifier.height(12.dp))
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(Modifier.padding(13.dp)) {
                        Text("ما فهمته:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(voiceText, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("الرد:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(voiceResponse, fontSize = 13.sp)
                    }
                }
                if (pending != null) {
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GoldButton("تأكيد وتنفيذ", Icons.Default.CheckCircle, Modifier.weight(1f)) {
                            vm.confirmPending(); showVoice = false
                        }
                        OutlinedButton(
                            onClick = { vm.cancelPending(); showVoice = false },
                            modifier = Modifier.weight(1f).height(50.dp),
                            shape = RoundedCornerShape(14.dp)
                        ) { Text("إلغاء") }
                    }
                } else {
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = { showVoice = false; nav.go("ai") },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) { Icon(Icons.Default.Forum, null, tint = Gold); Spacer(Modifier.width(8.dp)); Text("فتح المحادثة الكاملة") }
                }
                Spacer(Modifier.height(20.dp))
            }
        }
    }
}

fun NavHostController.go(route: String) {
    if (currentDestination?.route != route) {
        navigate(route) {
            launchSingleTop = true
            if (route !in bottomRoutes) popUpTo("home") { saveState = false }
        }
    }
}

fun screenLabel(route: String): String = when (route) {
    "pos", "checkout" -> "الكاشير"
    "products", "product_add", "product_detail" -> "المنتجات"
    "inventory", "stocktake" -> "المخزون"
    "purchases", "purchase_new" -> "المشتريات"
    "customers", "customer_detail" -> "العملاء"
    "suppliers" -> "الموردون"
    "expenses" -> "المصروفات"
    "finance", "cashbox", "shifts" -> "المالية"
    "reports" -> "التقارير"
    "employees" -> "الموظفون"
    else -> "الرئيسية"
}

@Composable
fun MiyarBottomBar(nav: NavHostController, current: String) {
    val items = listOf(
        Triple("home", "الرئيسية", Icons.Default.Dashboard),
        Triple("pos", "الكاشير", Icons.Default.PointOfSale),
        Triple("products", "المنتجات", Icons.Default.Inventory2),
        Triple("finance", "المالية", Icons.Default.AccountBalanceWallet),
        Triple("more", "المزيد", Icons.Default.GridView)
    )
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 6.dp) {
        items.forEach { (r, label, icon) ->
            NavigationBarItem(
                selected = current == r,
                onClick = {
                    if (current != r) {
                        nav.navigate(r) { popUpTo("home") { saveState = true }; launchSingleTop = true; restoreState = true }
                    }
                },
                icon = { Icon(icon, label) },
                label = { Text(label, fontSize = 11.sp, fontWeight = if (current == r) FontWeight.Bold else FontWeight.Normal) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Gold,
                    selectedTextColor = Gold,
                    indicatorColor = Gold.copy(alpha = 0.16f)
                )
            )
        }
    }
}
